const BASE = "/api";
const getToken = () => sessionStorage.getItem("ep_token");
const buildHeaders = (extra = {}) => ({ "Content-Type":"application/json", ...(getToken()?{Authorization:`Bearer ${getToken()}`}:{}), ...extra });
const handle = async (res) => { const data=await res.json(); if(!res.ok) throw new Error(data.error||`Request failed (${res.status})`); return data; };

// ── Auth ──────────────────────────────────────────────────────────────────────
export const apiLogin       = (email,password,role)  => fetch(`${BASE}/auth/login`,          {method:"POST",headers:buildHeaders(),body:JSON.stringify({email,password,role})}).then(handle);
export const apiRegister    = (body)                  => fetch(`${BASE}/auth/register`,        {method:"POST",headers:buildHeaders(),body:JSON.stringify(body)}).then(handle);
export const apiCheckEmail  = (email)                 => fetch(`${BASE}/auth/check-email`,     {method:"POST",headers:buildHeaders(),body:JSON.stringify({email})}).then(handle);
export const apiResetPass   = (email,newPassword)     => fetch(`${BASE}/auth/forgot-password`, {method:"POST",headers:buildHeaders(),body:JSON.stringify({email,newPassword})}).then(handle);

// ── Users ─────────────────────────────────────────────────────────────────────
export const apiGetUsers    = ()     => fetch(`${BASE}/users`,       {headers:buildHeaders()}).then(handle);
export const apiAddUser     = (body) => fetch(`${BASE}/users`,       {method:"POST",  headers:buildHeaders(),body:JSON.stringify(body)}).then(handle);
export const apiDeleteUser  = (id)   => fetch(`${BASE}/users/${id}`, {method:"DELETE",headers:buildHeaders()}).then(handle);

// ── Questions ─────────────────────────────────────────────────────────────────
export const apiGetQuestions   = ()          => fetch(`${BASE}/questions`,        {headers:buildHeaders()}).then(handle);
export const apiAddQuestion    = (body)      => fetch(`${BASE}/questions`,        {method:"POST",  headers:buildHeaders(),body:JSON.stringify(body)}).then(handle);
export const apiUpdateQuestion = (id,body)   => fetch(`${BASE}/questions/${id}`,  {method:"PUT",   headers:buildHeaders(),body:JSON.stringify(body)}).then(handle);
export const apiDeleteQuestion = (id)        => fetch(`${BASE}/questions/${id}`,  {method:"DELETE",headers:buildHeaders()}).then(handle);

// ── Exams ─────────────────────────────────────────────────────────────────────
export const apiGetExams       = ()          => fetch(`${BASE}/exams`,            {headers:buildHeaders()}).then(handle);
export const apiAddExam        = (body)      => fetch(`${BASE}/exams`,            {method:"POST",  headers:buildHeaders(),body:JSON.stringify(body)}).then(handle);
export const apiUpdateExam     = (id,body)   => fetch(`${BASE}/exams/${id}`,      {method:"PUT",   headers:buildHeaders(),body:JSON.stringify(body)}).then(handle);
export const apiDeleteExam     = (id)        => fetch(`${BASE}/exams/${id}`,      {method:"DELETE",headers:buildHeaders()}).then(handle);
export const apiCheckExamAccess= (id)        => fetch(`${BASE}/exams/${id}/access-check`, {headers:buildHeaders()}).then(handle);

// ── Results ───────────────────────────────────────────────────────────────────
export const apiGetResults   = ()     => fetch(`${BASE}/results`, {headers:buildHeaders()}).then(handle);
export const apiSubmitResult = (body) => fetch(`${BASE}/results`, {method:"POST",headers:buildHeaders(),body:JSON.stringify(body)}).then(handle);

// ── Adaptive ──────────────────────────────────────────────────────────────────
export const apiAdaptiveNext   = (body) => fetch(`${BASE}/adaptive/next`,   {method:"POST",headers:buildHeaders(),body:JSON.stringify(body)}).then(handle);
export const apiAdaptiveAnswer = (body) => fetch(`${BASE}/adaptive/answer`, {method:"POST",headers:buildHeaders(),body:JSON.stringify(body)}).then(handle);

// ── Gamification ──────────────────────────────────────────────────────────────
export const apiGetProfile     = ()     => fetch(`${BASE}/profile`,     {headers:buildHeaders()}).then(handle);
export const apiGetLeaderboard = ()     => fetch(`${BASE}/leaderboard`, {headers:buildHeaders()}).then(handle);

// ── Cheat Detection ───────────────────────────────────────────────────────────
export const apiLogCheat        = (body) => fetch(`${BASE}/cheat-log`,            {method:"POST",headers:buildHeaders(),body:JSON.stringify(body)}).then(handle);
export const apiGetCheatReports = ()     => fetch(`${BASE}/admin/cheat-reports`,  {headers:buildHeaders()}).then(handle);
