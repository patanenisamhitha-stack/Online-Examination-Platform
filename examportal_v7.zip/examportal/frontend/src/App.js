import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import {
  apiLogin, apiRegister, apiCheckEmail, apiResetPass,
  apiGetUsers, apiAddUser, apiDeleteUser,
  apiGetQuestions, apiAddQuestion, apiUpdateQuestion, apiDeleteQuestion,
  apiGetExams, apiAddExam, apiUpdateExam, apiDeleteExam,
  apiGetResults, apiSubmitResult,
  apiAdaptiveNext, apiAdaptiveAnswer,
  apiGetProfile, apiGetLeaderboard,
  apiCheckExamAccess, apiLogCheat, apiGetCheatReports,
} from "./api";

// ─── NOTE ─────────────────────────────────────────────────────────────────────
// All data is loaded from MongoDB via the Express backend (port 5000).
// Run `POST /api/seed` once to populate the database with sample data.
// ─────────────────────────────────────────────────────────────────────────────


// ─── SAMPLE DATA ─────────────────────────────────────────────────────────────
const INITIAL_QUESTIONS = [
  // ── JavaScript (1–20) ──
  { id: 1, subject: "JavaScript", text: "Which method is used to parse a JSON string?", options: ["JSON.stringify()", "JSON.parse()", "JSON.convert()", "JSON.decode()"], answer: 1 },
  { id: 2, subject: "JavaScript", text: "What does '===' check in JavaScript?", options: ["Value only", "Type only", "Value and Type", "Neither"], answer: 2 },
  { id: 3, subject: "JavaScript", text: "Which keyword declares a block-scoped variable in JavaScript?", options: ["var", "let", "both", "none"], answer: 1 },
  { id: 4, subject: "JavaScript", text: "What does 'typeof null' return in JavaScript?", options: ["null", "undefined", "object", "boolean"], answer: 2 },
  { id: 5, subject: "JavaScript", text: "Which array method creates a new array with filtered results?", options: ["map()", "forEach()", "filter()", "reduce()"], answer: 2 },
  { id: 6, subject: "JavaScript", text: "What is a closure in JavaScript?", options: ["A loop that never ends", "A function with access to its outer scope", "An error handler", "A CSS class"], answer: 1 },
  { id: 7, subject: "JavaScript", text: "Which method converts an object to a JSON string?", options: ["JSON.parse()", "JSON.stringify()", "JSON.encode()", "JSON.format()"], answer: 1 },
  { id: 8, subject: "JavaScript", text: "What does the spread operator (...) do?", options: ["Closes a function", "Expands iterables", "Declares variables", "Imports modules"], answer: 1 },
  { id: 9, subject: "JavaScript", text: "Which keyword is used to handle exceptions in JavaScript?", options: ["error", "catch", "handle", "except"], answer: 1 },
  { id: 10, subject: "JavaScript", text: "What is the output of '2' + 2 in JavaScript?", options: ["4", "22", "NaN", "Error"], answer: 1 },
  { id: 11, subject: "JavaScript", text: "Which method is used to add an element at the end of an array?", options: ["push()", "pop()", "shift()", "unshift()"], answer: 0 },
  { id: 12, subject: "JavaScript", text: "What does 'NaN' stand for?", options: ["Not any Number", "Not a Number", "Null and None", "New and Null"], answer: 1 },
  { id: 13, subject: "JavaScript", text: "How do you declare an arrow function?", options: ["function => {}", "() => {}", "=> function {}", "func() {}"], answer: 1 },
  { id: 14, subject: "JavaScript", text: "Which built-in method returns the length of a string?", options: [".size()", ".count()", ".length", ".len()"], answer: 2 },
  { id: 15, subject: "JavaScript", text: "What is the purpose of 'use strict' in JavaScript?", options: ["Enables strict type checking", "Prevents use of undeclared variables", "Speeds up code", "Enables ES6 features"], answer: 1 },
  { id: 16, subject: "JavaScript", text: "Which method removes the last element from an array?", options: ["push()", "pop()", "shift()", "splice()"], answer: 1 },
  { id: 17, subject: "JavaScript", text: "What does 'async/await' help with in JavaScript?", options: ["CSS animations", "Handling asynchronous operations", "DOM manipulation", "Variable scoping"], answer: 1 },
  { id: 18, subject: "JavaScript", text: "What is the DOM in JavaScript?", options: ["Document Object Model", "Data Object Method", "Dynamic Object Manager", "Display Object Module"], answer: 0 },
  { id: 19, subject: "JavaScript", text: "Which method is used to select an HTML element by its ID?", options: ["querySelector()", "getElement()", "getElementById()", "selectById()"], answer: 2 },
  { id: 20, subject: "JavaScript", text: "What does the 'this' keyword refer to in a method?", options: ["The global object", "The current object", "The parent class", "undefined"], answer: 1 },

  // ── React (21–40) ──
  { id: 21, subject: "React", text: "What hook is used to manage state in functional components?", options: ["useEffect", "useContext", "useState", "useRef"], answer: 2 },
  { id: 22, subject: "React", text: "What does useEffect with an empty dependency array do?", options: ["Runs on every render", "Runs only once on mount", "Runs on unmount", "Never runs"], answer: 1 },
  { id: 23, subject: "React", text: "What is JSX in React?", options: ["A JavaScript library", "A syntax extension for JavaScript", "A CSS framework", "A database query language"], answer: 1 },
  { id: 24, subject: "React", text: "How do you pass data from parent to child in React?", options: ["State", "Props", "Context", "Redux"], answer: 1 },
  { id: 25, subject: "React", text: "What is the virtual DOM?", options: ["A real DOM copy in memory", "A lightweight copy of the real DOM", "A server-side DOM", "A CSS structure"], answer: 1 },
  { id: 26, subject: "React", text: "Which hook is used for side effects in React?", options: ["useState", "useEffect", "useContext", "useReducer"], answer: 1 },
  { id: 27, subject: "React", text: "What does React.Fragment do?", options: ["Creates a new component", "Wraps elements without adding extra DOM nodes", "Deletes a component", "Imports a module"], answer: 1 },
  { id: 28, subject: "React", text: "What is the key prop used for in lists?", options: ["Styling elements", "Helping React identify which items changed", "Creating unique IDs", "Passing data"], answer: 1 },
  { id: 29, subject: "React", text: "What is a controlled component in React?", options: ["A component with internal state", "A component where form data is handled by React state", "A stateless component", "A pure component"], answer: 1 },
  { id: 30, subject: "React", text: "What does useContext provide?", options: ["Local state management", "A way to consume context without prop drilling", "DOM manipulation", "API calls"], answer: 1 },
  { id: 31, subject: "React", text: "Which lifecycle method is equivalent to componentDidMount using hooks?", options: ["useEffect with no dependencies", "useState", "useEffect with empty array", "useCallback"], answer: 2 },
  { id: 32, subject: "React", text: "What is prop drilling?", options: ["Passing props through many layers of components", "A React optimization technique", "A state management pattern", "A CSS method"], answer: 0 },
  { id: 33, subject: "React", text: "What does useMemo do in React?", options: ["Stores a reference to a DOM element", "Memoizes a computed value", "Manages component state", "Handles side effects"], answer: 1 },
  { id: 34, subject: "React", text: "What is the purpose of React Router?", options: ["Manage component state", "Handle navigation between pages", "Fetch API data", "Style components"], answer: 1 },
  { id: 35, subject: "React", text: "What is a higher-order component (HOC)?", options: ["A component that renders another component", "A function that takes a component and returns a new one", "A class component", "A styled component"], answer: 1 },
  { id: 36, subject: "React", text: "What is the default behaviour when a React component's state changes?", options: ["Only that component re-renders", "The entire app re-renders", "The component and its children re-render", "Nothing re-renders"], answer: 2 },
  { id: 37, subject: "React", text: "Which hook returns a mutable ref object?", options: ["useState", "useEffect", "useRef", "useMemo"], answer: 2 },
  { id: 38, subject: "React", text: "What does 'lifting state up' mean in React?", options: ["Moving state to a child component", "Moving state to a common ancestor component", "Deleting component state", "Using Redux instead of state"], answer: 1 },
  { id: 39, subject: "React", text: "What is lazy loading in React?", options: ["Loading components only when needed", "Preloading all components at startup", "Disabling component rendering", "Caching API responses"], answer: 0 },
  { id: 40, subject: "React", text: "What does React.StrictMode do?", options: ["Prevents all errors", "Highlights potential problems in development", "Makes the app run faster", "Disables warnings"], answer: 1 },

  // ── MongoDB (41–60) ──
  { id: 41, subject: "MongoDB", text: "MongoDB stores data in which format?", options: ["Tables", "BSON documents", "XML files", "CSV rows"], answer: 1 },
  { id: 42, subject: "MongoDB", text: "Which command inserts a document in MongoDB?", options: ["db.insert()", "db.collection.insertOne()", "db.add()", "db.push()"], answer: 1 },
  { id: 43, subject: "MongoDB", text: "What type of database is MongoDB?", options: ["Relational", "NoSQL", "Graph", "Columnar"], answer: 1 },
  { id: 44, subject: "MongoDB", text: "What is a collection in MongoDB?", options: ["A group of databases", "A group of documents", "A group of fields", "A group of indexes"], answer: 1 },
  { id: 45, subject: "MongoDB", text: "Which operator is used to find documents where a field is greater than a value?", options: ["$gt", "$lt", "$eq", "$ne"], answer: 0 },
  { id: 46, subject: "MongoDB", text: "What does the find() method return in MongoDB?", options: ["A single document", "A cursor to matching documents", "An array of all documents", "A count of documents"], answer: 1 },
  { id: 47, subject: "MongoDB", text: "Which command deletes a single document in MongoDB?", options: ["db.collection.delete()", "db.collection.deleteOne()", "db.collection.remove()", "db.collection.drop()"], answer: 1 },
  { id: 48, subject: "MongoDB", text: "What is the default field MongoDB adds to every document?", options: ["id", "_id", "docId", "objectId"], answer: 1 },
  { id: 49, subject: "MongoDB", text: "Which method updates a document in MongoDB?", options: ["db.collection.change()", "db.collection.updateOne()", "db.collection.modify()", "db.collection.set()"], answer: 1 },
  { id: 50, subject: "MongoDB", text: "What does the $set operator do in MongoDB?", options: ["Deletes a field", "Creates a new collection", "Updates the value of a field", "Indexes a field"], answer: 2 },
  { id: 51, subject: "MongoDB", text: "Which MongoDB command shows all collections in a database?", options: ["show tables", "show collections", "list collections", "db.list()"], answer: 1 },
  { id: 52, subject: "MongoDB", text: "What is Mongoose in the context of MongoDB?", options: ["A MongoDB GUI tool", "An ODM library for MongoDB and Node.js", "A MongoDB cloud service", "A query language"], answer: 1 },
  { id: 53, subject: "MongoDB", text: "Which operator matches any value in an array?", options: ["$in", "$any", "$match", "$exists"], answer: 0 },
  { id: 54, subject: "MongoDB", text: "What is MongoDB Atlas?", options: ["A local MongoDB server", "A MongoDB command-line tool", "A cloud-hosted MongoDB service", "A MongoDB GUI"], answer: 2 },
  { id: 55, subject: "MongoDB", text: "Which aggregation stage filters documents in a pipeline?", options: ["$group", "$match", "$sort", "$project"], answer: 1 },
  { id: 56, subject: "MongoDB", text: "What does db.collection.drop() do?", options: ["Deletes one document", "Removes the entire collection", "Drops an index", "Disconnects from the database"], answer: 1 },
  { id: 57, subject: "MongoDB", text: "What is a replica set in MongoDB?", options: ["A set of indexes", "A group of MongoDB servers maintaining the same data", "A backup file", "A sharding strategy"], answer: 1 },
  { id: 58, subject: "MongoDB", text: "Which operator checks if a field exists in a document?", options: ["$has", "$exists", "$contains", "$field"], answer: 1 },
  { id: 59, subject: "MongoDB", text: "What does the limit() method do in MongoDB?", options: ["Limits database size", "Limits the number of documents returned", "Limits user access", "Limits field values"], answer: 1 },
  { id: 60, subject: "MongoDB", text: "What is sharding in MongoDB?", options: ["Splitting data across multiple servers", "Encrypting data", "Creating indexes", "Backing up data"], answer: 0 },

  // ── Node.js (61–80) ──
  { id: 61, subject: "Node.js", text: "Which module is used to create an HTTP server in Node.js?", options: ["fs", "path", "http", "os"], answer: 2 },
  { id: 62, subject: "Node.js", text: "What is npm?", options: ["Node Package Manager", "New Project Module", "Node Process Monitor", "None of these"], answer: 0 },
  { id: 63, subject: "Node.js", text: "Which function is used to read a file asynchronously in Node.js?", options: ["fs.readFile()", "fs.read()", "fs.open()", "fs.load()"], answer: 0 },
  { id: 64, subject: "Node.js", text: "What is the event loop in Node.js?", options: ["A loop for DOM events", "A mechanism to handle asynchronous callbacks", "A module for timers", "A database connection pool"], answer: 1 },
  { id: 65, subject: "Node.js", text: "Which command initializes a new Node.js project?", options: ["npm start", "npm init", "node init", "npm create"], answer: 1 },
  { id: 66, subject: "Node.js", text: "What is the 'require' function used for in Node.js?", options: ["To export modules", "To import modules", "To install packages", "To define variables"], answer: 1 },
  { id: 67, subject: "Node.js", text: "Which object provides information about the current process in Node.js?", options: ["system", "process", "runtime", "global"], answer: 1 },
  { id: 68, subject: "Node.js", text: "What is a callback function in Node.js?", options: ["A function that calls itself", "A function passed as an argument to be executed later", "A built-in Node function", "A synchronous function"], answer: 1 },
  { id: 69, subject: "Node.js", text: "Which module handles file paths in Node.js?", options: ["fs", "path", "url", "os"], answer: 1 },
  { id: 70, subject: "Node.js", text: "What does 'module.exports' do in Node.js?", options: ["Imports external packages", "Exports code from a module", "Runs a module", "Deletes a module"], answer: 1 },
  { id: 71, subject: "Node.js", text: "What is the purpose of package.json?", options: ["To store database credentials", "To manage project metadata and dependencies", "To configure the web server", "To store environment variables"], answer: 1 },
  { id: 72, subject: "Node.js", text: "Which method sends a response in a Node.js HTTP server?", options: ["res.write()", "res.send()", "res.end()", "res.respond()"], answer: 2 },
  { id: 73, subject: "Node.js", text: "What is Node.js primarily used for?", options: ["Frontend development", "Mobile app development", "Server-side JavaScript execution", "Database management"], answer: 2 },
  { id: 74, subject: "Node.js", text: "Which of the following is true about Node.js?", options: ["It is multi-threaded", "It uses blocking I/O", "It is single-threaded with non-blocking I/O", "It runs in a browser"], answer: 2 },
  { id: 75, subject: "Node.js", text: "What does the 'os' module provide in Node.js?", options: ["Operating system information", "File operations", "Network utilities", "Database access"], answer: 0 },
  { id: 76, subject: "Node.js", text: "Which command installs a package globally in npm?", options: ["npm install pkg", "npm install -g pkg", "npm global pkg", "npm add -g pkg"], answer: 1 },
  { id: 77, subject: "Node.js", text: "What is a stream in Node.js?", options: ["A real-time data channel", "A sequence of data read or written asynchronously", "A type of variable", "A database connection"], answer: 1 },
  { id: 78, subject: "Node.js", text: "What is the difference between process.nextTick() and setImmediate()?", options: ["They are identical", "nextTick fires before I/O events, setImmediate fires after", "setImmediate fires before nextTick", "Only setImmediate is asynchronous"], answer: 1 },
  { id: 79, subject: "Node.js", text: "What does the 'cluster' module do in Node.js?", options: ["Manages databases", "Allows creating child processes to share server ports", "Handles HTTP routing", "Manages file systems"], answer: 1 },
  { id: 80, subject: "Node.js", text: "Which file is automatically executed when you run 'node .'?", options: ["app.js", "server.js", "index.js", "main.js"], answer: 2 },

  // ── Express.js (81–100) ──
  { id: 81, subject: "Express.js", text: "Which method defines a GET route in Express?", options: ["app.post()", "app.get()", "app.put()", "app.route()"], answer: 1 },
  { id: 82, subject: "Express.js", text: "What does middleware do in Express?", options: ["Renders HTML", "Connects to database", "Processes requests between server and route", "Creates routes"], answer: 2 },
  { id: 83, subject: "Express.js", text: "How do you install Express in a Node.js project?", options: ["node install express", "npm install express", "npm add express --save", "install express"], answer: 1 },
  { id: 84, subject: "Express.js", text: "Which method is used to parse JSON request bodies in Express?", options: ["express.text()", "express.urlencoded()", "express.json()", "express.body()"], answer: 2 },
  { id: 85, subject: "Express.js", text: "What is the purpose of res.json() in Express?", options: ["Reads JSON from a file", "Sends a JSON response", "Parses incoming JSON", "Converts objects to JSON"], answer: 1 },
  { id: 86, subject: "Express.js", text: "What is the correct way to define a URL parameter in Express?", options: ["/user/{id}", "/user/:id", "/user/[id]", "/user/<id>"], answer: 1 },
  { id: 87, subject: "Express.js", text: "Which object contains data sent in the request body?", options: ["req.params", "req.query", "req.body", "req.data"], answer: 2 },
  { id: 88, subject: "Express.js", text: "What does app.use() do in Express?", options: ["Mounts middleware at a path", "Creates a new route", "Starts the server", "Connects to database"], answer: 0 },
  { id: 89, subject: "Express.js", text: "Which HTTP status code represents 'Not Found'?", options: ["200", "401", "404", "500"], answer: 2 },
  { id: 90, subject: "Express.js", text: "What is Express Router used for?", options: ["Database routing", "Modularizing routes into separate files", "Styling responses", "Session management"], answer: 1 },
  { id: 91, subject: "Express.js", text: "How do you start an Express server on port 3000?", options: ["app.run(3000)", "app.start(3000)", "app.listen(3000)", "app.open(3000)"], answer: 2 },
  { id: 92, subject: "Express.js", text: "What is CORS in the context of Express?", options: ["A type of middleware", "Cross-Origin Resource Sharing policy", "A database connector", "A routing technique"], answer: 1 },
  { id: 93, subject: "Express.js", text: "What does res.status(201).json() do?", options: ["Sends a 201 error", "Sends a response with status 201 and JSON body", "Creates a new route", "Parses the request"], answer: 1 },
  { id: 94, subject: "Express.js", text: "Which middleware serves static files in Express?", options: ["express.static()", "express.serve()", "express.files()", "express.public()"], answer: 0 },
  { id: 95, subject: "Express.js", text: "What is the purpose of the 'next' parameter in Express middleware?", options: ["Goes to next iteration of a loop", "Passes control to the next middleware", "Ends the response", "Redirects to another route"], answer: 1 },
  { id: 96, subject: "Express.js", text: "Which property contains URL query parameters in Express?", options: ["req.body", "req.params", "req.query", "req.url"], answer: 2 },
  { id: 97, subject: "Express.js", text: "What does app.delete() define in Express?", options: ["Removes the app", "Defines a DELETE route handler", "Clears the session", "Drops the database"], answer: 1 },
  { id: 98, subject: "Express.js", text: "Which HTTP method is typically used to update a resource partially?", options: ["PUT", "POST", "PATCH", "DELETE"], answer: 2 },
  { id: 99, subject: "Express.js", text: "What is JWT commonly used for in Express apps?", options: ["Database queries", "Authentication and authorization", "Static file serving", "Template rendering"], answer: 1 },
  { id: 100, subject: "Express.js", text: "What does the 'helmet' middleware do in Express?", options: ["Compresses responses", "Adds security-related HTTP headers", "Handles file uploads", "Manages sessions"], answer: 1 },

  // ── Java (101–120) ──
  { id: 101, subject: "Java", text: "Which keyword is used to create an object in Java?", options: ["create", "new", "object", "make"], answer: 1 },
  { id: 102, subject: "Java", text: "What is the default value of an int variable in Java?", options: ["null", "undefined", "0", "-1"], answer: 2 },
  { id: 103, subject: "Java", text: "Which concept allows a class to inherit from another class in Java?", options: ["Polymorphism", "Encapsulation", "Inheritance", "Abstraction"], answer: 2 },
  { id: 104, subject: "Java", text: "What does JVM stand for?", options: ["Java Virtual Machine", "Java Variable Method", "Java Verified Module", "Java Value Manager"], answer: 0 },
  { id: 105, subject: "Java", text: "Which method is the entry point of a Java program?", options: ["start()", "run()", "init()", "main()"], answer: 3 },
  { id: 106, subject: "Java", text: "Which of these is NOT a primitive data type in Java?", options: ["int", "boolean", "String", "char"], answer: 2 },
  { id: 107, subject: "Java", text: "What is the correct way to declare an array in Java?", options: ["int arr[]", "array int[]", "int[] arr", "Both A and C"], answer: 3 },
  { id: 108, subject: "Java", text: "Which keyword prevents a class from being subclassed in Java?", options: ["static", "final", "private", "abstract"], answer: 1 },
  { id: 109, subject: "Java", text: "What is an interface in Java?", options: ["A class with only static methods", "A blueprint with abstract methods and constants", "A concrete class", "An enum type"], answer: 1 },
  { id: 110, subject: "Java", text: "Which keyword is used to implement an interface?", options: ["extends", "implements", "inherits", "uses"], answer: 1 },
  { id: 111, subject: "Java", text: "What is method overloading in Java?", options: ["Redefining a parent class method", "Multiple methods with the same name but different parameters", "Hiding a method", "Calling a method recursively"], answer: 1 },
  { id: 112, subject: "Java", text: "Which exception is thrown when dividing by zero in Java?", options: ["NullPointerException", "ArithmeticException", "ArrayIndexOutOfBoundsException", "NumberFormatException"], answer: 1 },
  { id: 113, subject: "Java", text: "What does the 'static' keyword mean in Java?", options: ["The variable changes at runtime", "Belongs to the class rather than instances", "The method is private", "The class cannot be inherited"], answer: 1 },
  { id: 114, subject: "Java", text: "Which collection class in Java maintains insertion order?", options: ["HashSet", "TreeSet", "LinkedList", "HashMap"], answer: 2 },
  { id: 115, subject: "Java", text: "What is the output of 10 % 3 in Java?", options: ["3", "1", "0", "2"], answer: 1 },
  { id: 116, subject: "Java", text: "Which access modifier makes a member accessible only within its class?", options: ["public", "protected", "default", "private"], answer: 3 },
  { id: 117, subject: "Java", text: "What is autoboxing in Java?", options: ["Automatic memory allocation", "Automatic conversion between primitives and wrapper classes", "Automatic garbage collection", "Automatic type casting"], answer: 1 },
  { id: 118, subject: "Java", text: "Which keyword is used to call a parent class constructor?", options: ["this()", "parent()", "super()", "base()"], answer: 2 },
  { id: 119, subject: "Java", text: "What is a Java package?", options: ["A compressed archive of classes", "A namespace to organise classes", "A type of variable", "A build tool"], answer: 1 },
  { id: 120, subject: "Java", text: "What does the 'finally' block do in Java exception handling?", options: ["Runs only when an exception occurs", "Runs only when no exception occurs", "Always runs regardless of exception", "Skips execution on error"], answer: 2 },

  // ── Python (121–140) ──
  { id: 121, subject: "Python", text: "Which symbol is used for single-line comments in Python?", options: ["//", "/*", "#", "--"], answer: 2 },
  { id: 122, subject: "Python", text: "What is the output of type(3.14) in Python?", options: ["<class 'int'>", "<class 'float'>", "<class 'double'>", "<class 'number'>"], answer: 1 },
  { id: 123, subject: "Python", text: "Which function is used to get the length of a list in Python?", options: ["size()", "count()", "len()", "length()"], answer: 2 },
  { id: 124, subject: "Python", text: "How do you create a dictionary in Python?", options: ["[]", "()", "{}", "<>"], answer: 2 },
  { id: 125, subject: "Python", text: "Which keyword is used to define a function in Python?", options: ["function", "def", "func", "define"], answer: 1 },
  { id: 126, subject: "Python", text: "What does the 'append()' method do to a Python list?", options: ["Removes last element", "Adds element at beginning", "Adds element at end", "Sorts the list"], answer: 2 },
  { id: 127, subject: "Python", text: "Which of these is used for string formatting in Python?", options: ["f-string", "format()", "% operator", "All of the above"], answer: 3 },
  { id: 128, subject: "Python", text: "What is the output of bool(0) in Python?", options: ["True", "False", "0", "None"], answer: 1 },
  { id: 129, subject: "Python", text: "Which keyword is used for inheritance in Python?", options: ["extends", "inherits", "class Child(Parent):", "implements"], answer: 2 },
  { id: 130, subject: "Python", text: "What does 'self' refer to in a Python class?", options: ["The class itself", "The current instance of the class", "The parent class", "A global variable"], answer: 1 },
  { id: 131, subject: "Python", text: "Which data structure in Python is immutable?", options: ["List", "Dictionary", "Set", "Tuple"], answer: 3 },
  { id: 132, subject: "Python", text: "What does the 'range(5)' function generate?", options: ["[1,2,3,4,5]", "[0,1,2,3,4]", "[0,1,2,3,4,5]", "[1,2,3,4]"], answer: 1 },
  { id: 133, subject: "Python", text: "Which Python keyword is used to handle exceptions?", options: ["catch", "error", "except", "handle"], answer: 2 },
  { id: 134, subject: "Python", text: "What is a lambda function in Python?", options: ["A recursive function", "An anonymous single-expression function", "A class method", "An imported function"], answer: 1 },
  { id: 135, subject: "Python", text: "Which module is used to generate random numbers in Python?", options: ["math", "random", "numpy", "statistics"], answer: 1 },
  { id: 136, subject: "Python", text: "What is list comprehension in Python?", options: ["A way to sort lists", "A compact way to create lists using a for loop", "A method to copy lists", "A recursive list function"], answer: 1 },
  { id: 137, subject: "Python", text: "What does 'pip' stand for in Python?", options: ["Python Import Package", "Pip Installs Packages", "Python Integrated Platform", "Package Index Pip"], answer: 1 },
  { id: 138, subject: "Python", text: "What is the output of 'Hello'[::-1] in Python?", options: ["Hello", "olleH", "H", "Error"], answer: 1 },
  { id: 139, subject: "Python", text: "Which method is used to remove whitespace from both ends of a string?", options: ["strip()", "trim()", "clean()", "remove()"], answer: 0 },
  { id: 140, subject: "Python", text: "What is a virtual environment in Python?", options: ["An online Python editor", "An isolated Python environment for project dependencies", "A Python simulator", "A cloud hosting service"], answer: 1 },

  // ── C (141–160) ──
  { id: 141, subject: "C", text: "Which header file is required for printf() and scanf() in C?", options: ["<stdlib.h>", "<string.h>", "<stdio.h>", "<math.h>"], answer: 2 },
  { id: 142, subject: "C", text: "What is the correct syntax to declare a pointer in C?", options: ["int &p", "int *p", "pointer int p", "int ptr p"], answer: 1 },
  { id: 143, subject: "C", text: "What does the 'sizeof' operator return in C?", options: ["Value of variable", "Address of variable", "Size in bytes", "Number of elements"], answer: 2 },
  { id: 144, subject: "C", text: "Which loop is guaranteed to execute at least once in C?", options: ["for", "while", "do-while", "foreach"], answer: 2 },
  { id: 145, subject: "C", text: "What is the return type of main() in C?", options: ["void", "int", "char", "float"], answer: 1 },
  { id: 146, subject: "C", text: "Which function is used to dynamically allocate memory in C?", options: ["new()", "alloc()", "malloc()", "create()"], answer: 2 },
  { id: 147, subject: "C", text: "What does '\\n' represent in a C string?", options: ["Null character", "New line", "Tab space", "Backslash"], answer: 1 },
  { id: 148, subject: "C", text: "Which operator is used to access members of a structure through a pointer?", options: [".", "->", "::", "*"], answer: 1 },
  { id: 149, subject: "C", text: "What is a structure in C?", options: ["A collection of functions", "A user-defined data type grouping variables", "A type of loop", "A memory allocation technique"], answer: 1 },
  { id: 150, subject: "C", text: "Which function frees dynamically allocated memory in C?", options: ["delete()", "free()", "release()", "dealloc()"], answer: 1 },
  { id: 151, subject: "C", text: "What is the use of the 'break' statement in C?", options: ["Pauses program execution", "Exits the current loop or switch", "Skips to the next iteration", "Terminates the program"], answer: 1 },
  { id: 152, subject: "C", text: "What does the address-of operator & do in C?", options: ["Dereferences a pointer", "Returns the address of a variable", "Performs bitwise AND", "Declares a reference"], answer: 1 },
  { id: 153, subject: "C", text: "Which function copies a string in C?", options: ["strdup()", "strcpy()", "strcat()", "strlen()"], answer: 1 },
  { id: 154, subject: "C", text: "What is a NULL pointer in C?", options: ["A pointer to address 0", "An uninitialised pointer", "A pointer that stores strings", "A pointer to a function"], answer: 0 },
  { id: 155, subject: "C", text: "What is the difference between '==' and '=' in C?", options: ["No difference", "'==' assigns, '=' compares", "'=' assigns, '==' compares", "Both assign values"], answer: 2 },
  { id: 156, subject: "C", text: "What does #define do in C?", options: ["Declares a variable", "Creates a macro/constant", "Defines a function", "Includes a header file"], answer: 1 },
  { id: 157, subject: "C", text: "Which storage class is used for a variable visible only within its function?", options: ["extern", "static", "register", "auto"], answer: 3 },
  { id: 158, subject: "C", text: "What is a recursive function in C?", options: ["A function called by another function", "A function that calls itself", "A function with no return value", "A library function"], answer: 1 },
  { id: 159, subject: "C", text: "Which operator is used for bitwise AND in C?", options: ["&&", "&", "AND", "//"], answer: 1 },
  { id: 160, subject: "C", text: "What is the purpose of the 'continue' statement in C?", options: ["Exits the loop", "Skips the current iteration and continues the loop", "Terminates the program", "Goes to a label"], answer: 1 },

  // ── C++ (161–180) ──
  { id: 161, subject: "C++", text: "Which concept of OOP allows the same function name with different parameters?", options: ["Inheritance", "Encapsulation", "Polymorphism", "Function Overloading"], answer: 3 },
  { id: 162, subject: "C++", text: "What is the correct way to declare a class in C++?", options: ["class MyClass {}", "Class MyClass {}", "object MyClass {}", "struct MyClass {}"], answer: 0 },
  { id: 163, subject: "C++", text: "Which operator is used to access class members in C++?", options: ["->", "::", ".", "Both . and ->"], answer: 3 },
  { id: 164, subject: "C++", text: "What is a constructor in C++?", options: ["A function that destroys objects", "A function called automatically when object is created", "A static method", "A virtual function"], answer: 1 },
  { id: 165, subject: "C++", text: "Which header file is required for cout and cin in C++?", options: ["<stdio.h>", "<conio.h>", "<iostream>", "<stream.h>"], answer: 2 },
  { id: 166, subject: "C++", text: "What is the scope resolution operator in C++?", options: [".", "->", "::", "#"], answer: 2 },
  { id: 167, subject: "C++", text: "Which keyword is used to prevent a function from being overridden in C++?", options: ["static", "const", "final", "override"], answer: 2 },
  { id: 168, subject: "C++", text: "What does STL stand for in C++?", options: ["Standard Type Library", "Standard Template Library", "System Template Library", "Static Type List"], answer: 1 },
  { id: 169, subject: "C++", text: "What is a destructor in C++?", options: ["A function that creates objects", "A function called when an object is destroyed", "A virtual constructor", "A copy function"], answer: 1 },
  { id: 170, subject: "C++", text: "Which C++ feature allows a function to work with different data types?", options: ["Inheritance", "Overloading", "Templates", "Polymorphism"], answer: 2 },
  { id: 171, subject: "C++", text: "What is operator overloading in C++?", options: ["Redefining built-in operators for user-defined types", "Calling an operator multiple times", "A type of inheritance", "Creating new operators"], answer: 0 },
  { id: 172, subject: "C++", text: "Which keyword is used for dynamic memory allocation in C++?", options: ["malloc()", "alloc()", "new", "create"], answer: 2 },
  { id: 173, subject: "C++", text: "What is a virtual function in C++?", options: ["A function declared but not defined", "A function overridden in derived classes using runtime polymorphism", "A static member function", "A template function"], answer: 1 },
  { id: 174, subject: "C++", text: "What is multiple inheritance in C++?", options: ["A class inheriting from more than one base class", "Inheriting a class multiple times", "Overriding multiple methods", "Using multiple constructors"], answer: 0 },
  { id: 175, subject: "C++", text: "Which STL container provides FIFO behaviour?", options: ["stack", "queue", "vector", "map"], answer: 1 },
  { id: 176, subject: "C++", text: "What does 'delete' keyword do in C++?", options: ["Removes a class", "Deallocates memory allocated by 'new'", "Destroys a file", "Removes a method"], answer: 1 },
  { id: 177, subject: "C++", text: "What is encapsulation in C++?", options: ["Breaking a class into multiple files", "Hiding internal details and exposing only necessary parts", "Using multiple inheritance", "Overloading functions"], answer: 1 },
  { id: 178, subject: "C++", text: "Which type of constructor copies another object?", options: ["Default constructor", "Parameterised constructor", "Copy constructor", "Move constructor"], answer: 2 },
  { id: 179, subject: "C++", text: "What is an abstract class in C++?", options: ["A class with no methods", "A class with at least one pure virtual function", "A class that cannot have objects but has all methods defined", "A final class"], answer: 1 },
  { id: 180, subject: "C++", text: "Which access specifier makes members accessible in derived classes but not outside?", options: ["public", "private", "protected", "internal"], answer: 2 },
];

const INITIAL_EXAMS = [
  { id: 1, title: "MERN Stack Fundamentals", duration: 20, timePerQuestion: 30, questionIds: [1,2,3,4,5,21,22,23,41,42,43,61,62,63,81,82,83,84,85,86], createdAt: "2025-01-10" },
  { id: 2, title: "JavaScript Mastery", duration: 25, timePerQuestion: 30, questionIds: [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20], createdAt: "2025-01-12" },
  { id: 3, title: "React Deep Dive", duration: 25, timePerQuestion: 30, questionIds: [21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40], createdAt: "2025-01-13" },
  { id: 4, title: "MongoDB Complete", duration: 25, timePerQuestion: 30, questionIds: [41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60], createdAt: "2025-01-14" },
  { id: 5, title: "Node.js & Express.js", duration: 25, timePerQuestion: 30, questionIds: [61,62,63,64,65,66,67,68,69,70,81,82,83,84,85,86,87,88,89,90], createdAt: "2025-01-15" },
  { id: 6, title: "Java Programming", duration: 25, timePerQuestion: 30, questionIds: [101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120], createdAt: "2025-01-16" },
  { id: 7, title: "Python Essentials", duration: 25, timePerQuestion: 30, questionIds: [121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140], createdAt: "2025-01-17" },
  { id: 8, title: "C Programming", duration: 25, timePerQuestion: 30, questionIds: [141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160], createdAt: "2025-01-18" },
  { id: 9, title: "C++ OOP", duration: 25, timePerQuestion: 30, questionIds: [161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180], createdAt: "2025-01-19" },
];

const INITIAL_USERS = [
  { id: 1, name: "Admin User", email: "admin@exam.com", password: "admin123", role: "admin" },
  { id: 2, name: "Mani Samhitha", email: "mani@student.com", password: "student123", role: "student" },
  { id: 3, name: "Abdul Waseef", email: "waseef@student.com", password: "student123", role: "student" },
];

// ─── STYLES ───────────────────────────────────────────────────────────────────
const STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500;600&display=swap');
  
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  
  :root {
    --bg: #0a0e1a;
    --surface: #111827;
    --surface2: #1a2235;
    --border: #1e2d45;
    --accent: #00d4ff;
    --accent2: #7c3aed;
    --accent3: #10b981;
    --danger: #ef4444;
    --warning: #f59e0b;
    --text: #e2e8f0;
    --text-muted: #64748b;
    --text-dim: #94a3b8;
    --radius: 12px;
    --glow: 0 0 20px rgba(0,212,255,0.15);
    --shadow: 0 4px 24px rgba(0,0,0,0.4);
  }

  body { background: var(--bg); color: var(--text); font-family: 'DM Sans', sans-serif; min-height: 100vh; }

  .app { min-height: 100vh; display: flex; flex-direction: column; }

  /* NAV */
  .nav { background: rgba(17,24,39,0.95); backdrop-filter: blur(12px); border-bottom: 1px solid var(--border); padding: 0 2rem; display: flex; align-items: center; justify-content: space-between; height: 64px; position: sticky; top: 0; z-index: 100; }
  .nav-brand { font-family: 'Syne', sans-serif; font-weight: 800; font-size: 1.25rem; color: var(--accent); letter-spacing: -0.5px; display: flex; align-items: center; gap: 10px; }
  .nav-brand span { color: var(--text); }
  .nav-dot { width: 8px; height: 8px; background: var(--accent); border-radius: 50%; box-shadow: 0 0 12px var(--accent); animation: pulse 2s infinite; }
  @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.6;transform:scale(1.3)} }
  .nav-right { display: flex; align-items: center; gap: 1rem; }
  .nav-user { font-size: 0.875rem; color: var(--text-dim); }
  .nav-badge { background: var(--accent2); color: white; padding: 2px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; }

  /* BUTTONS */
  .btn { border: none; cursor: pointer; border-radius: var(--radius); font-family: 'DM Sans', sans-serif; font-weight: 500; transition: all 0.2s; display: inline-flex; align-items: center; gap: 6px; }
  .btn-primary { background: var(--accent); color: #000; padding: 10px 20px; font-size: 0.9rem; font-weight: 600; }
  .btn-primary:hover { background: #33deff; box-shadow: var(--glow); transform: translateY(-1px); }
  .btn-secondary { background: var(--surface2); color: var(--text); padding: 10px 20px; border: 1px solid var(--border); font-size: 0.9rem; }
  .btn-secondary:hover { border-color: var(--accent); color: var(--accent); }
  .btn-danger { background: var(--danger); color: white; padding: 8px 16px; font-size: 0.875rem; }
  .btn-danger:hover { background: #dc2626; }
  .btn-success { background: var(--accent3); color: #000; padding: 10px 20px; font-size: 0.9rem; font-weight: 600; }
  .btn-success:hover { background: #34d399; }
  .btn-sm { padding: 6px 12px; font-size: 0.8rem; }
  .btn-lg { padding: 14px 28px; font-size: 1rem; font-weight: 600; }
  .btn:disabled { opacity: 0.5; cursor: not-allowed; transform: none!important; }

  /* CARDS */
  .card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.5rem; transition: border-color 0.2s, box-shadow 0.2s; }
  .card:hover { border-color: #2d3f5f; box-shadow: var(--shadow); }
  .card-accent { border-left: 3px solid var(--accent); }
  .card-success { border-left: 3px solid var(--accent3); }
  .card-purple { border-left: 3px solid var(--accent2); }
  .card-warning { border-left: 3px solid var(--warning); }

  /* FORMS */
  .form-group { margin-bottom: 1.25rem; }
  .form-label { display: block; font-size: 0.8rem; font-weight: 600; color: var(--text-dim); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; }
  .form-input { width: 100%; background: var(--surface2); border: 1px solid var(--border); border-radius: 8px; padding: 10px 14px; color: var(--text); font-family: 'DM Sans', sans-serif; font-size: 0.9rem; outline: none; transition: border-color 0.2s; }
  .form-input:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(0,212,255,0.1); }
  .form-select { appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2364748b' d='M6 8L1 3h10z'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 12px center; }

  /* LAYOUT */
  .container { max-width: 1200px; margin: 0 auto; padding: 2rem; }
  .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
  .grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; }
  .grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; }
  @media(max-width:768px){ .grid-2,.grid-3,.grid-4{grid-template-columns:1fr;} }
  .flex { display: flex; }
  .flex-center { display: flex; align-items: center; justify-content: center; }
  .flex-between { display: flex; align-items: center; justify-content: space-between; }
  .gap-1 { gap: 0.5rem; } .gap-2 { gap: 1rem; } .gap-3 { gap: 1.5rem; }
  .mt-1 { margin-top: 0.5rem; } .mt-2 { margin-top: 1rem; } .mt-3 { margin-top: 1.5rem; } .mt-4 { margin-top: 2rem; }
  .mb-2 { margin-bottom: 1rem; } .mb-3 { margin-bottom: 1.5rem; }
  .w-full { width: 100%; }
  .text-center { text-align: center; }
  .text-muted { color: var(--text-muted); font-size: 0.875rem; }
  .text-accent { color: var(--accent); }
  .text-success { color: var(--accent3); }
  .text-danger { color: var(--danger); }
  .text-sm { font-size: 0.875rem; }

  /* PAGE TITLES */
  .page-title { font-family: 'Syne', sans-serif; font-size: 1.75rem; font-weight: 800; margin-bottom: 0.25rem; }
  .page-subtitle { color: var(--text-muted); font-size: 0.9rem; margin-bottom: 2rem; }

  /* STAT CARDS */
  .stat-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.5rem; }
  .stat-value { font-family: 'Syne', sans-serif; font-size: 2.5rem; font-weight: 800; line-height: 1; }
  .stat-label { color: var(--text-muted); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 6px; }
  .stat-icon { font-size: 1.5rem; margin-bottom: 0.5rem; }

  /* LOGIN */
  .login-bg { min-height: 100vh; background: var(--bg); display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden; }
  .login-glow { position: absolute; width: 600px; height: 600px; background: radial-gradient(circle, rgba(0,212,255,0.05) 0%, transparent 70%); pointer-events: none; top: 50%; left: 50%; transform: translate(-50%,-50%); }
  .login-card { background: var(--surface); border: 1px solid var(--border); border-radius: 20px; padding: 2.5rem; width: 100%; max-width: 440px; position: relative; z-index: 1; box-shadow: 0 20px 60px rgba(0,0,0,0.5); }
  .login-logo { font-family: 'Syne', sans-serif; font-size: 1.5rem; font-weight: 800; color: var(--accent); text-align: center; margin-bottom: 0.5rem; }
  .login-sub { text-align: center; color: var(--text-muted); font-size: 0.875rem; margin-bottom: 2rem; }
  .login-tabs { display: flex; gap: 0; background: var(--surface2); border-radius: 8px; padding: 4px; margin-bottom: 2rem; }
  .login-tab { flex: 1; padding: 8px; text-align: center; font-size: 0.875rem; font-weight: 500; border-radius: 6px; cursor: pointer; transition: all 0.2s; color: var(--text-muted); }
  .login-tab.active { background: var(--accent); color: #000; font-weight: 600; }

  /* SIDEBAR */
  .layout { display: flex; min-height: calc(100vh - 64px); }
  .sidebar { width: 240px; background: var(--surface); border-right: 1px solid var(--border); padding: 1.5rem 0; flex-shrink: 0; }
  .sidebar-item { display: flex; align-items: center; gap: 10px; padding: 10px 1.5rem; cursor: pointer; font-size: 0.9rem; color: var(--text-muted); transition: all 0.2s; border-left: 3px solid transparent; }
  .sidebar-item:hover { background: var(--surface2); color: var(--text); }
  .sidebar-item.active { background: rgba(0,212,255,0.08); color: var(--accent); border-left-color: var(--accent); }
  .sidebar-icon { font-size: 1.1rem; }
  .main-content { flex: 1; overflow-y: auto; }

  /* TABLES */
  .table-wrap { overflow-x: auto; border-radius: var(--radius); border: 1px solid var(--border); }
  table { width: 100%; border-collapse: collapse; }
  th { background: var(--surface2); padding: 12px 16px; text-align: left; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-muted); font-weight: 600; }
  td { padding: 12px 16px; font-size: 0.875rem; border-top: 1px solid var(--border); }
  tr:hover td { background: var(--surface2); }

  /* BADGES */
  .badge { display: inline-flex; align-items: center; padding: 3px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 600; }
  .badge-blue { background: rgba(0,212,255,0.1); color: var(--accent); }
  .badge-green { background: rgba(16,185,129,0.1); color: var(--accent3); }
  .badge-purple { background: rgba(124,58,237,0.1); color: #a78bfa; }
  .badge-yellow { background: rgba(245,158,11,0.1); color: var(--warning); }
  .badge-red { background: rgba(239,68,68,0.1); color: var(--danger); }

  /* EXAM */
  .exam-header { background: var(--surface); border-bottom: 1px solid var(--border); padding: 1rem 2rem; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 64px; z-index: 50; }
  .timer { font-family: 'Syne', sans-serif; font-size: 1.5rem; font-weight: 800; }
  .timer.warning { color: var(--warning); animation: blink 1s infinite; }
  .timer.danger { color: var(--danger); animation: blink 0.5s infinite; }
  @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.5} }
  .progress-bar-wrap { background: var(--surface2); border-radius: 4px; height: 6px; flex: 1; margin: 0 1rem; }
  .progress-bar { height: 100%; border-radius: 4px; background: var(--accent); transition: width 0.5s; }

  /* PER-QUESTION TIMER */
  .q-timer-ring-wrap { display: flex; flex-direction: column; align-items: center; gap: 6px; flex-shrink: 0; }
  .q-timer-ring { position: relative; width: 64px; height: 64px; }
  .q-timer-ring svg { transform: rotate(-90deg); }
  .q-timer-ring-text { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; font-family: 'Syne', sans-serif; font-size: 1rem; font-weight: 800; }
  .q-timer-label { font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
  .q-timer-bar-wrap { width: 100%; height: 5px; background: var(--surface2); border-radius: 3px; margin-bottom: 1.25rem; overflow: hidden; }
  .q-timer-bar { height: 100%; border-radius: 3px; transition: width 1s linear, background 0.5s; }
  .q-skipped { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(239,68,68,0.08); border-radius: var(--radius); display: flex; align-items: center; justify-content: center; font-size: 0.85rem; color: var(--danger); font-weight: 600; pointer-events: none; }
  .q-nav { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 1.5rem; }
  .q-num { width: 36px; height: 36px; border-radius: 8px; border: 1px solid var(--border); display: flex; align-items: center; justify-content: center; font-size: 0.8rem; cursor: pointer; font-weight: 600; transition: all 0.2s; }
  .q-num.answered { background: rgba(0,212,255,0.15); border-color: var(--accent); color: var(--accent); }
  .q-num.current { background: var(--accent); color: #000; border-color: var(--accent); }
  .q-num:hover { border-color: var(--accent); }
  .option-btn { width: 100%; text-align: left; padding: 14px 18px; border-radius: 10px; border: 1px solid var(--border); background: var(--surface2); color: var(--text); cursor: pointer; font-size: 0.9rem; font-family: 'DM Sans', sans-serif; transition: all 0.2s; display: flex; align-items: center; gap: 12px; margin-bottom: 10px; }
  .option-btn:hover { border-color: var(--accent); background: rgba(0,212,255,0.05); }
  .option-btn.selected { border-color: var(--accent); background: rgba(0,212,255,0.1); color: var(--accent); }
  .option-btn.correct { border-color: var(--accent3); background: rgba(16,185,129,0.1); color: var(--accent3); }
  .option-btn.wrong { border-color: var(--danger); background: rgba(239,68,68,0.1); color: var(--danger); }
  .option-letter { width: 28px; height: 28px; border-radius: 6px; background: var(--surface); display: flex; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: 700; flex-shrink: 0; }

  /* RESULTS */
  .score-ring { width: 160px; height: 160px; border-radius: 50%; background: conic-gradient(var(--accent) calc(var(--pct) * 1%), var(--surface2) 0); display: flex; align-items: center; justify-content: center; position: relative; margin: 0 auto 1.5rem; }
  .score-ring::before { content: ''; position: absolute; width: 120px; height: 120px; border-radius: 50%; background: var(--surface); }
  .score-ring-inner { position: relative; z-index: 1; text-align: center; }
  .score-pct { font-family: 'Syne', sans-serif; font-size: 1.75rem; font-weight: 800; }

  /* MODAL */
  .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.7); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: 1rem; }
  .modal { background: var(--surface); border: 1px solid var(--border); border-radius: 16px; padding: 2rem; width: 100%; max-width: 540px; max-height: 90vh; overflow-y: auto; }
  .modal-title { font-family: 'Syne', sans-serif; font-size: 1.25rem; font-weight: 700; margin-bottom: 1.5rem; }

  /* TOAST */
  .toast { position: fixed; bottom: 2rem; right: 2rem; background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 12px 20px; z-index: 9999; font-size: 0.875rem; box-shadow: var(--shadow); transform: translateX(200%); transition: transform 0.3s; }
  .toast.show { transform: translateX(0); }
  .toast.success { border-left: 3px solid var(--accent3); }
  .toast.error { border-left: 3px solid var(--danger); }

  /* EMPTY */
  .empty { text-align: center; padding: 4rem 2rem; color: var(--text-muted); }
  .empty-icon { font-size: 3rem; margin-bottom: 1rem; }

  /* RESULT REVIEW */
  .review-card { background: var(--surface2); border-radius: 10px; padding: 1.25rem; margin-bottom: 1rem; border: 1px solid var(--border); }
  .review-card.correct-card { border-left: 3px solid var(--accent3); }
  .review-card.wrong-card { border-left: 3px solid var(--danger); }

  /* CERTIFICATE */
  .cert-wrapper { background: linear-gradient(135deg, #0a0e1a 0%, #0f1f3d 100%); border: 2px solid var(--accent); border-radius: 20px; padding: 3rem; text-align: center; position: relative; overflow: hidden; max-width: 700px; margin: 0 auto; }
  .cert-wrapper::before { content: ''; position: absolute; inset: 8px; border: 1px solid rgba(0,212,255,0.2); border-radius: 14px; pointer-events: none; }
  .cert-corner { position: absolute; width: 60px; height: 60px; border-color: var(--accent); border-style: solid; opacity: 0.5; }
  .cert-corner.tl { top: 16px; left: 16px; border-width: 2px 0 0 2px; border-radius: 4px 0 0 0; }
  .cert-corner.tr { top: 16px; right: 16px; border-width: 2px 2px 0 0; border-radius: 0 4px 0 0; }
  .cert-corner.bl { bottom: 16px; left: 16px; border-width: 0 0 2px 2px; border-radius: 0 0 0 4px; }
  .cert-corner.br { bottom: 16px; right: 16px; border-width: 0 2px 2px 0; border-radius: 0 0 4px 0; }
  .cert-logo { font-family: 'Syne', sans-serif; font-size: 1.1rem; font-weight: 800; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; margin-bottom: 0.5rem; }
  .cert-title { font-family: 'Syne', sans-serif; font-size: 0.75rem; color: var(--text-muted); letter-spacing: 4px; text-transform: uppercase; margin-bottom: 1.5rem; }
  .cert-headline { font-family: 'Syne', sans-serif; font-size: 0.8rem; color: var(--text-dim); letter-spacing: 2px; text-transform: uppercase; margin-bottom: 0.5rem; }
  .cert-name { font-family: 'Syne', sans-serif; font-size: 2.2rem; font-weight: 800; color: var(--accent); margin-bottom: 1rem; text-shadow: 0 0 30px rgba(0,212,255,0.3); }
  .cert-body { color: var(--text-dim); font-size: 0.9rem; line-height: 1.8; margin-bottom: 1.5rem; }
  .cert-exam { font-family: 'Syne', sans-serif; font-size: 1.2rem; font-weight: 700; color: var(--text); }
  .cert-divider { width: 80px; height: 2px; background: linear-gradient(90deg, transparent, var(--accent), transparent); margin: 1.5rem auto; }
  .cert-meta { display: flex; justify-content: space-around; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid var(--border); }
  .cert-meta-item { text-align: center; }
  .cert-meta-value { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1.1rem; color: var(--accent3); }
  .cert-meta-label { font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; margin-top: 2px; }
  .cert-seal { width: 70px; height: 70px; border-radius: 50%; border: 2px solid var(--accent); display: flex; align-items: center; justify-content: center; margin: 1.5rem auto 0; font-size: 1.8rem; background: rgba(0,212,255,0.05); }
  .cert-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.5rem; cursor: pointer; transition: all 0.2s; }
  .cert-card:hover { border-color: var(--accent); box-shadow: var(--glow); transform: translateY(-2px); }
  .cert-card-title { font-family: 'Syne', sans-serif; font-weight: 700; margin-bottom: 0.5rem; }
  @media print { .no-print { display: none !important; } body { background: white; } }

  /* FORGOT PASSWORD */
  .forgot-link { font-size: 0.8rem; color: var(--accent); cursor: pointer; text-decoration: underline; text-align: right; display: block; margin-top: -0.75rem; margin-bottom: 1rem; }
  .forgot-link:hover { color: #33deff; }

  /* REGISTRATION */
  .auth-switch { text-align: center; margin-top: 1rem; font-size: 0.85rem; color: var(--text-muted); }
  .auth-switch span { color: var(--accent); cursor: pointer; font-weight: 600; }
  .auth-switch span:hover { color: #33deff; }

  /* ── SMART DIFFICULTY CALIBRATION ── */
  .adaptive-badge { display: inline-flex; align-items: center; gap: 6px; background: linear-gradient(135deg, rgba(124,58,237,0.2), rgba(0,212,255,0.15)); border: 1px solid rgba(124,58,237,0.4); border-radius: 20px; padding: 4px 12px; font-size: 0.78rem; font-weight: 600; color: #a78bfa; letter-spacing: 0.5px; }
  .difficulty-bar { display: flex; gap: 3px; align-items: center; }
  .difficulty-pip { width: 10px; height: 10px; border-radius: 2px; transition: background 0.4s, transform 0.2s; }
  .difficulty-pip.active { transform: scaleY(1.2); }
  .ability-orb { width: 80px; height: 80px; border-radius: 50%; display: flex; flex-direction: column; align-items: center; justify-content: center; font-family: 'Syne', sans-serif; font-weight: 800; font-size: 1.1rem; border: 3px solid; box-shadow: 0 0 24px; }
  .theta-track { width: 100%; height: 8px; background: var(--surface2); border-radius: 4px; overflow: hidden; position: relative; }
  .theta-fill { height: 100%; border-radius: 4px; transition: width 0.6s cubic-bezier(0.34, 1.56, 0.64, 1); }
  .hint-box { background: rgba(245,158,11,0.08); border: 1px solid rgba(245,158,11,0.25); border-radius: 8px; padding: 10px 14px; font-size: 0.85rem; color: var(--warning); margin-top: 0.75rem; display: flex; gap: 8px; align-items: flex-start; }
  .adaptive-q-enter { animation: adaptiveIn 0.35s cubic-bezier(0.34, 1.56, 0.64, 1); }
  @keyframes adaptiveIn { from { opacity: 0; transform: translateX(30px) scale(0.97); } to { opacity: 1; transform: translateX(0) scale(1); } }
  .diff-up   { animation: diffUp 0.5s forwards; }
  .diff-down { animation: diffDown 0.5s forwards; }
  @keyframes diffUp   { 0%{background:rgba(16,185,129,0.3)} 100%{background:transparent} }
  @keyframes diffDown { 0%{background:rgba(239,68,68,0.3)}  100%{background:transparent} }
  .adaptive-result-card { background: linear-gradient(135deg, rgba(124,58,237,0.12), rgba(0,212,255,0.08)); border: 1px solid rgba(124,58,237,0.3); border-radius: 16px; padding: 2rem; text-align: center; }
  .ability-timeline { display: flex; align-items: flex-end; gap: 4px; height: 80px; padding: 8px 0; }
  .ability-bar-item { flex: 1; border-radius: 3px 3px 0 0; min-width: 12px; transition: height 0.5s; position: relative; }
  .ability-bar-item:hover::after { content: attr(data-label); position: absolute; top: -24px; left: 50%; transform: translateX(-50%); font-size: 0.65rem; color: var(--text-dim); white-space: nowrap; }

  /* ── ANSWER EXPLANATIONS ── */
  .explanation-box { background: rgba(0,212,255,0.06); border: 1px solid rgba(0,212,255,0.2); border-radius: 8px; padding: 12px 16px; margin-top: 10px; font-size: 0.84rem; color: var(--text-dim); line-height: 1.6; }
  .explanation-box strong { color: var(--accent); display: block; margin-bottom: 4px; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px; }

  /* ── GAMIFICATION ── */
  .xp-bar-track { width: 100%; height: 10px; background: var(--surface2); border-radius: 5px; overflow: hidden; }
  .xp-bar-fill  { height: 100%; border-radius: 5px; background: linear-gradient(90deg, #7c3aed, #00d4ff); transition: width 1s cubic-bezier(0.34,1.56,0.64,1); }
  .level-badge  { display: inline-flex; align-items: center; justify-content: center; width: 36px; height: 36px; border-radius: 50%; background: linear-gradient(135deg,#7c3aed,#00d4ff); color: #fff; font-family:'Syne',sans-serif; font-weight:800; font-size:0.9rem; box-shadow:0 0 16px rgba(124,58,237,0.5); }
  .badge-grid   { display: flex; flex-wrap: wrap; gap: 10px; }
  .badge-chip   { display: flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 20px; font-size: 0.78rem; font-weight: 600; border: 1px solid; transition: transform 0.15s; cursor: default; }
  .badge-chip:hover { transform: translateY(-2px); }
  .badge-chip.earned   { background: rgba(124,58,237,0.15); border-color: rgba(124,58,237,0.4); color: #c4b5fd; }
  .badge-chip.unearned { background: var(--surface2); border-color: var(--border); color: var(--text-muted); opacity: 0.5; filter: grayscale(1); }
  .leaderboard-row { display: grid; grid-template-columns: 40px 1fr auto auto; gap: 12px; align-items: center; padding: 10px 12px; border-radius: 8px; margin-bottom: 6px; transition: background 0.15s; }
  .leaderboard-row:hover { background: var(--surface2); }
  .leaderboard-row.me { background: rgba(0,212,255,0.07); border: 1px solid rgba(0,212,255,0.2); }
  .rank-num { font-family:'Syne',sans-serif; font-weight:800; font-size:1rem; text-align:center; }
  .rank-1 { color: #fbbf24; } .rank-2 { color: #94a3b8; } .rank-3 { color: #b45309; }
  /* XP Celebration popup */
  .xp-popup-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.7); display:flex; align-items:center; justify-content:center; z-index:2000; animation:fadeIn 0.2s; }
  @keyframes fadeIn { from{opacity:0} to{opacity:1} }
  .xp-popup { background: var(--surface); border: 1px solid rgba(124,58,237,0.4); border-radius:20px; padding:2.5rem; text-align:center; max-width:420px; width:90%; position:relative; box-shadow:0 0 60px rgba(124,58,237,0.3); }
  .xp-popup-ring { width:100px; height:100px; border-radius:50%; background:linear-gradient(135deg,#7c3aed,#00d4ff); display:flex; align-items:center; justify-content:center; margin:0 auto 1rem; font-size:2.5rem; box-shadow:0 0 40px rgba(124,58,237,0.6); animation:popIn 0.5s cubic-bezier(0.34,1.56,0.64,1); }
  @keyframes popIn { from{transform:scale(0) rotate(-20deg)} to{transform:scale(1) rotate(0)} }
  .xp-number { font-family:'Syne',sans-serif; font-weight:800; font-size:2.5rem; background:linear-gradient(135deg,#a78bfa,#00d4ff); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
  .new-badge-list { display:flex; flex-wrap:wrap; gap:8px; justify-content:center; margin-top:1rem; }
  /* Streak fire */
  .streak-pill { display:inline-flex; align-items:center; gap:5px; background:rgba(245,158,11,0.12); border:1px solid rgba(245,158,11,0.3); border-radius:20px; padding:3px 10px; font-size:0.78rem; font-weight:600; color:var(--warning); }
  /* Achievement notification */
  @keyframes slideInRight { from{transform:translateX(120%);opacity:0} to{transform:translateX(0);opacity:1} }
  .achievement-toast { position:fixed; bottom:5rem; right:2rem; background:linear-gradient(135deg,rgba(124,58,237,0.95),rgba(0,212,255,0.9)); border-radius:14px; padding:14px 18px; z-index:3000; max-width:280px; box-shadow:0 8px 32px rgba(124,58,237,0.5); animation:slideInRight 0.4s cubic-bezier(0.34,1.56,0.64,1); }

  /* ── TIME-LOCK GATE ── */
  .time-lock-card { background:linear-gradient(135deg,rgba(239,68,68,0.12),rgba(245,158,11,0.08)); border:1px solid rgba(239,68,68,0.3); border-radius:16px; padding:2.5rem; text-align:center; }
  .time-lock-countdown { font-family:'Syne',sans-serif; font-size:2.5rem; font-weight:800; color:var(--accent); letter-spacing:2px; margin:1rem 0; }
  .time-window-pill { display:inline-flex; align-items:center; gap:6px; background:rgba(0,212,255,0.1); border:1px solid rgba(0,212,255,0.25); border-radius:20px; padding:4px 14px; font-size:0.8rem; color:var(--accent); font-weight:600; }

  /* ── STREAK MULTIPLIER ── */
  .multiplier-badge { display:inline-flex; align-items:center; gap:5px; background:linear-gradient(135deg,rgba(245,158,11,0.2),rgba(239,68,68,0.15)); border:1px solid rgba(245,158,11,0.4); border-radius:20px; padding:3px 10px; font-size:0.78rem; font-weight:700; color:var(--warning); }
  .multiplier-badge.x2 { background:linear-gradient(135deg,rgba(124,58,237,0.25),rgba(239,68,68,0.15)); border-color:rgba(124,58,237,0.5); color:#c4b5fd; }

  /* ── CHEAT DETECTOR ── */
  .cheat-warn-banner { position:fixed; top:0; left:0; right:0; z-index:9000; background:linear-gradient(90deg,rgba(239,68,68,0.95),rgba(245,158,11,0.9)); color:#fff; padding:8px 20px; font-size:0.82rem; font-weight:600; display:flex; align-items:center; gap:10px; box-shadow:0 2px 20px rgba(239,68,68,0.5); animation:slideDown 0.3s; }
  @keyframes slideDown { from{transform:translateY(-100%)} to{transform:translateY(0)} }
  .cheat-flag-badge { display:inline-flex; align-items:center; gap:4px; border-radius:12px; padding:2px 8px; font-size:0.72rem; font-weight:700; }
  .cheat-flag-none   { background:rgba(16,185,129,0.15); color:var(--accent3); }
  .cheat-flag-low    { background:rgba(245,158,11,0.15); color:var(--warning); }
  .cheat-flag-medium { background:rgba(239,68,68,0.15); color:var(--danger); }
  .cheat-flag-high   { background:rgba(239,68,68,0.25); color:#ff6b6b; border:1px solid rgba(239,68,68,0.4); }

  /* ── SHUFFLE INDICATOR ── */
  .shuffle-pill { display:inline-flex; align-items:center; gap:4px; background:rgba(16,185,129,0.1); border:1px solid rgba(16,185,129,0.25); border-radius:20px; padding:2px 9px; font-size:0.72rem; color:var(--accent3); font-weight:600; }

  /* ── POINTS PAGE ── */
  .points-hero { background:linear-gradient(135deg,rgba(0,212,255,0.12),rgba(124,58,237,0.1)); border:1px solid rgba(0,212,255,0.2); border-radius:16px; padding:2rem; }
  .points-big { font-family:'Syne',sans-serif; font-weight:800; font-size:3rem; background:linear-gradient(135deg,#00d4ff,#a78bfa); -webkit-background-clip:text; -webkit-text-fill-color:transparent; line-height:1; }
  .points-history-bar { display:flex; align-items:flex-end; gap:4px; height:100px; }
  .points-bar-item { flex:1; border-radius:4px 4px 0 0; min-width:10px; position:relative; cursor:default; transition:opacity 0.2s; }
  .points-bar-item:hover { opacity:0.85; }
  .points-bar-item:hover::after { content:attr(data-tip); position:absolute; bottom:calc(100% + 4px); left:50%; transform:translateX(-50%); background:var(--surface); border:1px solid var(--border); border-radius:6px; padding:3px 8px; font-size:0.68rem; color:var(--text); white-space:nowrap; z-index:10; }
  .points-row { display:flex; align-items:center; gap:12px; padding:10px 12px; border-radius:8px; margin-bottom:6px; transition:background 0.15s; }
  .points-row:hover { background:var(--surface2); }

  /* ── BADGE DOWNLOAD ── */
  .badge-download-btn { display:inline-flex; align-items:center; gap:5px; background:rgba(0,212,255,0.1); border:1px solid rgba(0,212,255,0.25); border-radius:20px; padding:3px 10px; font-size:0.72rem; color:var(--accent); font-weight:600; cursor:pointer; transition:all 0.15s; }
  .badge-download-btn:hover { background:rgba(0,212,255,0.2); transform:translateY(-1px); }
  .badge-card-preview { width:300px; padding:24px 20px; border-radius:16px; text-align:center; position:relative; margin:0 auto; }
`;

// ─── APP ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser]           = useState(null);
  const [users, setUsers]         = useState([]);
  const [questions, setQuestions] = useState([]);
  const [exams, setExams]         = useState([]);
  const [results, setResults]     = useState([]);
  const [view, setView]           = useState("dashboard");
  const [activeExam, setActiveExam] = useState(null);
  const [toast, setToast]         = useState(null);
  const [loading, setLoading]     = useState(false);
  const [lastResult, setLastResult] = useState(null);
  // ── Gamification ────────────────────────────────────────────────────────────
  const [gamification, setGamification] = useState(null); // full profile from /api/profile
  const [xpPopup, setXpPopup]           = useState(null); // { xpEarned, pointsEarned, newBadges, newLevel }
  const [leaderboard, setLeaderboard]   = useState([]);

  const showToast = useCallback((msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  }, []);

  // Normalise MongoDB _id → id for compatibility throughout the app
  const norm = (doc) => ({ ...doc, id: doc._id || doc.id });

  const loadData = useCallback(async (role) => {
    setLoading(true);
    try {
      const [qs, exs, res] = await Promise.all([
        apiGetQuestions(),
        apiGetExams(),
        apiGetResults(),
      ]);
      setQuestions(qs.map(norm));
      setExams(exs.map(e => ({
        ...norm(e),
        questionIds: (e.questionIds || []).map(q => (typeof q === "object" ? q._id : q)),
      })));
      setResults(res.map(norm));
      if (role === "admin") {
        const us = await apiGetUsers();
        setUsers(us.map(norm));
      }
      if (role === "student") {
        try { const profile = await apiGetProfile(); setGamification(profile); } catch {}
      }
    } catch (err) {
      showToast("Failed to load data: " + err.message, "error");
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  // Restore session on refresh
  useEffect(() => {
    const saved  = sessionStorage.getItem("ep_user");
    const token  = sessionStorage.getItem("ep_token");
    if (saved && token) {
      const u = JSON.parse(saved);
      setUser(u);
      loadData(u.role);
    }
  }, [loadData]);

  const handleLogin = (loginUser, token) => {
    sessionStorage.setItem("ep_token", token);
    sessionStorage.setItem("ep_user", JSON.stringify(loginUser));
    setUser(loginUser);
    setView("dashboard");
    loadData(loginUser.role);
  };

  const handleLogout = () => {
    sessionStorage.removeItem("ep_token");
    sessionStorage.removeItem("ep_user");
    setUser(null); setView("dashboard"); setActiveExam(null);
    setQuestions([]); setExams([]); setResults([]); setUsers([]);
  };

  const [timeLockMsg, setTimeLockMsg] = useState(null);

  const startExam = (exam) => {
    // Client-side time-of-day lock check
    if (exam.availableFrom || exam.availableTo) {
      const now = new Date();
      const cur = now.getHours() * 60 + now.getMinutes();
      const [fH, fM] = (exam.availableFrom || "00:00").split(":").map(Number);
      const [tH, tM] = (exam.availableTo   || "23:59").split(":").map(Number);
      const from = fH * 60 + fM;
      const to   = tH * 60 + tM;
      const ok   = from <= to ? (cur >= from && cur <= to) : (cur >= from || cur <= to);
      if (!ok) {
        setTimeLockMsg({ examTitle: exam.title, availableFrom: exam.availableFrom, availableTo: exam.availableTo });
        return;
      }
    }
    setActiveExam(exam);
    setView("exam");
  };

  const finishExam = async (result) => {
    try {
      const payload = {
        examId:        result.examId,
        examTitle:     result.examTitle,
        correct:       result.correct,
        total:         result.total,
        percentage:    result.percentage,
        answers:       result.answers,
        autoSubmitted: result.autoSubmitted || false,
        completedAt:   new Date().toLocaleString(),
        adaptive:       result.adaptive      || false,
        finalAbility:   result.finalAbility  ?? null,
        abilityLabel:   result.abilityLabel  || null,
        difficultyPath: result.difficultyPath|| [],
        responseTimes:  result.responseTimes || [],
        hintUsed:       result.hintUsed      || [],
        cheatData:      result.cheatData     || {},  // { tabSwitches, copyPasteCount }
      };
      const saved = await apiSubmitResult(payload);
      const normalized = norm(saved);
      setResults(prev => [...prev, normalized]);
      setLastResult({ ...result, id: saved._id, cheatFlags: saved.cheatFlags });
      setActiveExam(null);
      setView("result");
      // Refresh gamification profile and show XP popup
      if (user?.role === "student") {
        try {
          const profile = await apiGetProfile();
          setGamification(profile);
          if ((saved.xpEarned || 0) > 0) {
            setXpPopup({
              xpEarned:     saved.xpEarned     || 0,
              xpBase:       saved.xpBase        || saved.xpEarned || 0,
              xpMultiplier: saved.xpMultiplier  || 1,
              pointsEarned: saved.pointsEarned  || 0,
              newBadges:    saved.newBadges      || [],
              newLevel:     profile.level,
              streak:       profile.streak,
              percentage:   result.percentage,
            });
          }
        } catch {}
      }
    } catch (err) {
      showToast("Failed to save result: " + err.message, "error");
      setActiveExam(null);
      setView("exams");
    }
  };

  const handleRegister = async (body) => {
    await apiRegister(body);
  };

  if (loading && !user) return (
    <>
      <style>{STYLES}</style>
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "var(--bg)", color: "var(--text-muted)", fontFamily: "Syne, sans-serif", fontSize: "1.2rem" }}>
        ⚡ Loading ExamPortal...
      </div>
    </>
  );

  return (
    <>
      <style>{STYLES}</style>
      <div className="app">
        {!user ? (
          <LoginPage onLogin={handleLogin} onRegister={handleRegister} />
        ) : view === "exam" && activeExam?.adaptive ? (
          <AdaptiveExamView exam={activeExam} user={user} onFinish={finishExam} onExit={() => { setActiveExam(null); setView("exams"); }} />
        ) : view === "exam" ? (
          <ExamView exam={activeExam} questions={questions} user={user} gamification={gamification} onFinish={finishExam} onExit={() => { setActiveExam(null); setView("exams"); }} />
        ) : (
          <>
            <Nav user={user} onLogout={handleLogout} gamification={gamification} />
            <div className="layout">
              <Sidebar user={user} view={view} setView={setView} />
              <div className="main-content">
                {view === "dashboard"    && <Dashboard user={user} exams={exams} questions={questions} results={results} users={users} gamification={gamification} setView={setView} />}
                {view === "exams"        && <ExamsPage user={user} exams={exams} setExams={setExams} questions={questions} results={results} onStart={startExam} showToast={showToast} />}
                {view === "questions"    && user.role === "admin" && <QuestionsPage questions={questions} setQuestions={setQuestions} showToast={showToast} />}
                {view === "results"      && <ResultsPage results={results} user={user} exams={exams} questions={questions} />}
                {view === "users"        && user.role === "admin" && <UsersPage users={users} setUsers={setUsers} showToast={showToast} />}
                {view === "certificates" && user.role === "student" && <CertificatesPage results={results} user={user} />}
                {view === "result"       && <LastResultPage result={lastResult} user={user} questions={questions} setView={setView} />}
                {view === "achievements" && user.role === "student" && <GamificationPage gamification={gamification} results={results} user={user} />}
                {view === "points"       && user.role === "student" && <PointsPage gamification={gamification} results={results} user={user} />}
                {view === "leaderboard"  && <LeaderboardPage user={user} leaderboard={leaderboard} setLeaderboard={setLeaderboard} />}
              </div>
            </div>
          </>
        )}
        {toast && <div className={`toast ${toast.type} show`}>{toast.type === "success" ? "✅" : "❌"} {toast.msg}</div>}
        {xpPopup && <XpCelebrationPopup popup={xpPopup} onClose={() => setXpPopup(null)} />}
        {timeLockMsg && <TimeLockOverlay msg={timeLockMsg} onClose={() => setTimeLockMsg(null)} />}
      </div>
    </>
  );
}

// ─── LOGIN PAGE ───────────────────────────────────────────────────────────────
function LoginPage({ onLogin, onRegister }) {
  const [screen, setScreen] = useState("login");
  const [tab, setTab] = useState("student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setError(""); setLoading(true);
    try {
      const data = await apiLogin(email, password, tab);
      onLogin(data.user, data.token);
    } catch (err) {
      setError(err.message || "Invalid credentials. Please try again.");
    } finally { setLoading(false); }
  };

  const fillDemo = () => {
    if (tab === "admin") { setEmail("admin@exam.com"); setPassword("admin123"); }
    else { setEmail("mani@student.com"); setPassword("student123"); }
  };

  const reset = () => { setEmail(""); setPassword(""); setError(""); };

  if (screen === "register") return <RegisterPage onRegister={onRegister} onBack={() => { setScreen("login"); reset(); }} tab={tab} />;
  if (screen === "forgot")   return <ForgotPasswordPage onBack={() => { setScreen("login"); reset(); }} />;

  return (
    <div className="login-bg">
      <div className="login-glow" />
      <div className="login-card">
        <div className="login-logo">⚡ ExamPortal</div>
        <div className="login-sub">MERN Stack Online Examination Platform</div>
        <div className="login-tabs">
          {["student", "admin"].map(t => (
            <div key={t} className={`login-tab ${tab === t ? "active" : ""}`} onClick={() => { setTab(t); reset(); }}>
              {t === "student" ? "👨‍🎓 Student" : "🛡️ Admin"}
            </div>
          ))}
        </div>
        <div className="form-group">
          <label className="form-label">Email Address</label>
          <input className="form-input" type="email" placeholder={tab === "admin" ? "admin@exam.com" : "mani@student.com"} value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key === "Enter" && handleLogin()} />
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <input className="form-input" type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} onKeyDown={e => e.key === "Enter" && handleLogin()} />
        </div>
        <div style={{ textAlign: "right", marginTop: "-0.75rem", marginBottom: "1.25rem" }}>
          <span className="forgot-link" style={{ fontSize: "0.82rem" }} onClick={() => { setScreen("forgot"); reset(); }}>Forgot Password?</span>
        </div>
        {error && <div className="text-danger text-sm mt-1 mb-2">⚠️ {error}</div>}
        <button className="btn btn-primary w-full btn-lg" onClick={handleLogin} disabled={loading}>
          {loading ? "Signing in..." : "Sign In →"}
        </button>
        <div className="text-center mt-2">
          <span className="text-muted text-sm" style={{ cursor: "pointer", textDecoration: "underline" }} onClick={fillDemo}>Use demo credentials</span>
        </div>
        <div className="auth-switch">
          Don't have an account? <span onClick={() => { setScreen("register"); reset(); }}>Register here</span>
        </div>
        <div className="mt-3" style={{ background: "var(--surface2)", borderRadius: 8, padding: "12px", fontSize: "0.8rem", color: "var(--text-muted)" }}>
          <strong style={{ color: "var(--text-dim)" }}>Demo:</strong> admin@exam.com / admin123 &nbsp;|&nbsp; mani@student.com / student123
        </div>
      </div>
    </div>
  );
}

// ─── REGISTER PAGE ────────────────────────────────────────────────────────────
function RegisterPage({ onRegister, onBack, tab }) {
  const [role, setRole] = useState(tab || "student");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [rollNo, setRollNo] = useState("");
  const [dept, setDept] = useState("");
  const [adminCode, setAdminCode] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleRegister = async () => {
    setError("");
    if (!name || !email || !password || !confirm) return setError("All fields are required.");
    if (password !== confirm) return setError("Passwords do not match.");
    if (password.length < 6) return setError("Password must be at least 6 characters.");
    setLoading(true);
    try {
      await apiRegister({ name, email, password, role, rollNo: rollNo || null, dept: dept || null, adminCode });
      setSuccess(true);
    } catch (err) {
      setError(err.message);
    } finally { setLoading(false); }
  };

  if (success) return (
    <div className="login-bg">
      <div className="login-glow" />
      <div className="login-card" style={{ textAlign: "center" }}>
        <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>🎉</div>
        <div className="login-logo">Registration Successful!</div>
        <p className="login-sub" style={{ marginBottom: "1.5rem" }}>Welcome, <strong>{name}</strong>! Your account has been created.</p>
        <button className="btn btn-primary w-full btn-lg" onClick={onBack}>Go to Login →</button>
      </div>
    </div>
  );

  return (
    <div className="login-bg">
      <div className="login-glow" />
      <div className="login-card" style={{ maxWidth: 480 }}>
        <div className="login-logo">⚡ ExamPortal</div>
        <div className="login-sub">Create your account</div>
        <div className="login-tabs">
          {["student", "admin"].map(t => (
            <div key={t} className={`login-tab ${role === t ? "active" : ""}`} onClick={() => { setRole(t); setError(""); }}>
              {t === "student" ? "👨‍🎓 Student" : "🛡️ Admin"}
            </div>
          ))}
        </div>
        <div className="form-group">
          <label className="form-label">Full Name</label>
          <input className="form-input" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. John Doe" />
        </div>
        <div className="form-group">
          <label className="form-label">Email Address</label>
          <input className="form-input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" />
        </div>
        {role === "student" && <>
          <div className="form-group">
            <label className="form-label">Roll Number</label>
            <input className="form-input" value={rollNo} onChange={e => setRollNo(e.target.value)} placeholder="e.g. 24B11IT099" />
          </div>
          <div className="form-group">
            <label className="form-label">Department</label>
            <input className="form-input" value={dept} onChange={e => setDept(e.target.value)} placeholder="e.g. Information Technology" />
          </div>
        </>}
        {role === "admin" && (
          <div className="form-group">
            <label className="form-label">Admin Registration Code</label>
            <input className="form-input" type="password" value={adminCode} onChange={e => setAdminCode(e.target.value)} placeholder="Enter secret code" />
            <div style={{ fontSize: "0.75rem", color: "var(--text-muted)", marginTop: 4 }}>💡 Demo code: <strong style={{ color: "var(--accent)" }}>ADMIN2024</strong></div>
          </div>
        )}
        <div className="form-group">
          <label className="form-label">Password</label>
          <input className="form-input" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Min 6 characters" />
        </div>
        <div className="form-group">
          <label className="form-label">Confirm Password</label>
          <input className="form-input" type="password" value={confirm} onChange={e => setConfirm(e.target.value)} placeholder="Re-enter password" onKeyDown={e => e.key === "Enter" && handleRegister()} />
        </div>
        {error && <div className="text-danger text-sm mt-1 mb-2">⚠️ {error}</div>}
        <button className="btn btn-primary w-full btn-lg" disabled={loading || !name || !email || !password || !confirm} onClick={handleRegister}>
          {loading ? "Creating..." : "Create Account →"}
        </button>
        <div className="auth-switch">Already have an account? <span onClick={onBack}>Sign in</span></div>
      </div>
    </div>
  );
}

// ─── FORGOT PASSWORD PAGE ─────────────────────────────────────────────────────
function ForgotPasswordPage({ onBack }) {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState("");
  const [newPass, setNewPass] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [foundName, setFoundName] = useState("");
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleFind = async () => {
    setError(""); setLoading(true);
    try {
      const data = await apiCheckEmail(email);
      setFoundName(data.name);
      setStep(2);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  };

  const handleReset = async () => {
    setError("");
    if (!newPass || newPass.length < 6) return setError("Password must be at least 6 characters.");
    if (newPass !== confirm) return setError("Passwords do not match.");
    setLoading(true);
    try {
      await apiResetPass(email, newPass);
      setDone(true);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  };

  if (done) return (
    <div className="login-bg">
      <div className="login-glow" />
      <div className="login-card" style={{ textAlign: "center" }}>
        <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>✅</div>
        <div className="login-logo">Password Reset!</div>
        <p className="login-sub" style={{ marginBottom: "1.5rem" }}>Your password has been updated successfully.</p>
        <button className="btn btn-primary w-full btn-lg" onClick={onBack}>Back to Login →</button>
      </div>
    </div>
  );

  return (
    <div className="login-bg">
      <div className="login-glow" />
      <div className="login-card">
        <div className="login-logo">⚡ ExamPortal</div>
        <div className="login-sub">{step === 1 ? "Reset your password" : `Reset password for ${foundName}`}</div>

        {/* Step indicator */}
        <div className="flex gap-2 mb-3" style={{ justifyContent: "center" }}>
          {[1, 2].map(s => (
            <div key={s} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <div style={{ width: 28, height: 28, borderRadius: "50%", background: step >= s ? "var(--accent)" : "var(--surface2)", border: `1px solid ${step >= s ? "var(--accent)" : "var(--border)"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 700, color: step >= s ? "#000" : "var(--text-muted)" }}>{s}</div>
              {s < 2 && <div style={{ width: 40, height: 2, background: step > s ? "var(--accent)" : "var(--border)" }} />}
            </div>
          ))}
        </div>

        {step === 1 && <>
          <div className="form-group">
            <label className="form-label">Registered Email Address</label>
            <input className="form-input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" onKeyDown={e => e.key === "Enter" && handleFind()} />
          </div>
          {error && <div className="text-danger text-sm mt-1 mb-2">⚠️ {error}</div>}
          <button className="btn btn-primary w-full btn-lg" disabled={!email || loading} onClick={handleFind}>{loading ? "Checking..." : "Find Account →"}</button>
        </>}

        {step === 2 && <>
          <div className="form-group">
            <label className="form-label">New Password</label>
            <input className="form-input" type="password" value={newPass} onChange={e => setNewPass(e.target.value)} placeholder="Min 6 characters" />
          </div>
          <div className="form-group">
            <label className="form-label">Confirm New Password</label>
            <input className="form-input" type="password" value={confirm} onChange={e => setConfirm(e.target.value)} placeholder="Re-enter password" onKeyDown={e => e.key === "Enter" && handleReset()} />
          </div>
          {error && <div className="text-danger text-sm mt-1 mb-2">⚠️ {error}</div>}
          <button className="btn btn-primary w-full btn-lg" disabled={!newPass || !confirm || loading} onClick={handleReset}>{loading ? "Resetting..." : "Reset Password ✓"}</button>
        </>}

        <div className="auth-switch">Remember your password? <span onClick={onBack}>Back to Login</span></div>
      </div>
    </div>
  );
}

// ─── NAV ───────────────────────────────────────────────────────────────────────
function Nav({ user, onLogout }) {
  return (
    <nav className="nav">
      <div className="nav-brand">
        <div className="nav-dot" />
        Exam<span>Portal</span>
      </div>
      <div className="nav-right">
        <span className="nav-user">👤 {user.name}</span>
        <span className="nav-badge">{user.role}</span>
        <button className="btn btn-secondary btn-sm" onClick={onLogout}>Logout</button>
      </div>
    </nav>
  );
}

// ─── SIDEBAR ──────────────────────────────────────────────────────────────────
function Sidebar({ user, view, setView }) {
  const adminItems = [
    { id: "dashboard",    icon: "📊", label: "Dashboard" },
    { id: "exams",        icon: "📋", label: "Exams" },
    { id: "questions",    icon: "❓", label: "Questions" },
    { id: "results",      icon: "📈", label: "Results" },
    { id: "users",        icon: "👥", label: "Users" },
    { id: "leaderboard",  icon: "🏅", label: "Leaderboard" },
    { id: "cheatreports", icon: "🕵️", label: "Cheat Reports" },
  ];
  const studentItems = [
    { id: "dashboard",   icon: "🏠",  label: "Home" },
    { id: "exams",       icon: "📋",  label: "My Exams" },
    { id: "results",     icon: "📈",  label: "My Results" },
    { id: "points",      icon: "💰",  label: "My Points" },
    { id: "achievements",icon: "🎮",  label: "Achievements" },
    { id: "leaderboard", icon: "🏅",  label: "Leaderboard" },
    { id: "certificates",icon: "🎓",  label: "Certificates" },
  ];
  const items = user.role === "admin" ? adminItems : studentItems;
  const activeViews = ["result"];
  return (
    <div className="sidebar">
      {items.map(item => (
        <div key={item.id}
          className={`sidebar-item ${view === item.id || (activeViews.includes(view) && item.id === "results") ? "active" : ""}`}
          onClick={() => setView(item.id)}
        >
          <span className="sidebar-icon">{item.icon}</span>
          {item.label}
        </div>
      ))}
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
const LEVEL_XP = [0,100,250,500,900,1400,2100,3000,4200,5600,7500];
const ALL_BADGES_META = {
  first_blood:   { name:"First Blood",    icon:"🩸", desc:"Complete your first exam" },
  perfect_score: { name:"Perfect Score",  icon:"💯", desc:"Score 100% on any exam" },
  speed_demon:   { name:"Speed Demon",    icon:"⚡", desc:"Finish exam in under half the time" },
  scholar:       { name:"Scholar",        icon:"🎓", desc:"Pass 5 exams" },
  expert:        { name:"Expert",         icon:"🏆", desc:"Pass 10 exams" },
  streak_3:      { name:"On Fire",        icon:"🔥", desc:"3-day study streak" },
  streak_7:      { name:"Weekly Warrior", icon:"📅", desc:"7-day study streak" },
  high_scorer:   { name:"High Scorer",    icon:"⭐", desc:"Score 90%+ on any exam" },
  persistent:    { name:"Persistent",     icon:"💪", desc:"Attempt same exam 3 times" },
  adaptive_ace:  { name:"Adaptive Ace",   icon:"🧠", desc:"Complete an adaptive exam" },
  subject_master:{ name:"Subject Master", icon:"📚", desc:"Pass all exams in one subject" },
  night_owl:     { name:"Night Owl",      icon:"🦉", desc:"Complete an exam after midnight" },
  level_5:       { name:"Rising Star",    icon:"🌟", desc:"Reach Level 5" },
  level_10:      { name:"Legend",         icon:"👑", desc:"Reach Level 10" },
};

function Dashboard({ user, exams, questions, results, users, gamification, setView }) {
  const userResults = user.role === "admin" ? results : results.filter(r => r.userId === user.id);
  const avgScore = userResults.length ? Math.round(userResults.reduce((a, r) => a + r.percentage, 0) / userResults.length) : 0;
  const isAdmin = user.role === "admin";

  const subjectStats = questions.reduce((acc, q) => {
    acc[q.subject] = (acc[q.subject] || 0) + 1; return acc;
  }, {});

  // Gamification helpers
  const gam = gamification || {};
  const level = gam.level || 1;
  const xp = gam.xp || 0;
  const nextXp = LEVEL_XP[Math.min(level, 9)] || 7500;
  const prevXp = LEVEL_XP[Math.max(level - 1, 0)] || 0;
  const xpPct = Math.min(100, Math.round(((xp - prevXp) / (nextXp - prevXp)) * 100));
  const earnedBadges = gam.badges || [];

  return (
    <div className="container">
      <div className="page-title">👋 Welcome, {user.name}</div>
      <div className="page-subtitle">{isAdmin ? "Manage your examination platform" : "Ready to test your knowledge?"}</div>

      <div className="grid-4 mb-3">
        {isAdmin ? <>
          <StatCard icon="📋" value={exams.length}                                    label="Total Exams"  color="var(--accent)" />
          <StatCard icon="❓" value={questions.length}                                label="Questions"    color="var(--accent2)" />
          <StatCard icon="👥" value={users.filter(u => u.role === "student").length}  label="Students"     color="var(--accent3)" />
          <StatCard icon="📝" value={results.length}                                  label="Submissions"  color="var(--warning)" />
        </> : <>
          <StatCard icon="📋" value={exams.length}                                                  label="Available Exams" color="var(--accent)" />
          <StatCard icon="✅" value={userResults.length}                                            label="Completed"       color="var(--accent3)" />
          <StatCard icon="📊" value={`${avgScore}%`}                                               label="Avg Score"       color="var(--accent2)" />
          <StatCard icon="🏆" value={userResults.filter(r => r.percentage >= 60).length}           label="Passed"          color="var(--warning)" />
        </>}
      </div>

      {/* ── Gamification banner for students ── */}
      {!isAdmin && (
        <div className="card mb-3" style={{ background: "linear-gradient(135deg, rgba(124,58,237,0.12), rgba(0,212,255,0.08))", border: "1px solid rgba(124,58,237,0.3)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "1.5rem", flexWrap: "wrap" }}>
            {/* Level ring */}
            <div style={{ textAlign: "center", minWidth: 64 }}>
              <div className="level-badge" style={{ width: 56, height: 56, fontSize: "1.3rem", margin: "0 auto 4px" }}>
                {level}
              </div>
              <div style={{ fontSize: "0.68rem", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px" }}>Level</div>
            </div>
            {/* XP bar */}
            <div style={{ flex: 1, minWidth: 160 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ fontSize: "0.78rem", fontWeight: 600, color: "#c4b5fd" }}>⭐ {xp.toLocaleString()} XP</span>
                <span style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>
                  {level < 10 ? `${nextXp.toLocaleString()} XP to level ${level + 1}` : "MAX LEVEL"}
                </span>
              </div>
              <div className="xp-bar-track">
                <div className="xp-bar-fill" style={{ width: `${xpPct}%` }} />
              </div>
            </div>
            {/* Points */}
            <div style={{ textAlign: "center", minWidth: 64 }}>
              <div style={{ fontFamily: "Syne", fontWeight: 800, fontSize: "1.25rem", color: "var(--accent)" }}>
                {(gam.totalPoints || 0).toLocaleString()}
              </div>
              <div style={{ fontSize: "0.68rem", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px" }}>Points</div>
            </div>
            {/* Streak */}
            <div style={{ textAlign: "center", minWidth: 64 }}>
              <div className="streak-pill" style={{ justifyContent: "center" }}>
                🔥 {gam.streak || 0}
              </div>
              <div style={{ fontSize: "0.68rem", color: "var(--text-muted)", marginTop: 4, textTransform: "uppercase", letterSpacing: "0.5px" }}>Day Streak</div>
            </div>
            {/* Badges mini */}
            <div style={{ display: "flex", gap: 4, flexWrap: "wrap", maxWidth: 180 }}>
              {earnedBadges.slice(0, 6).map(b => (
                <span key={b} title={ALL_BADGES_META[b]?.name || b}
                  style={{ fontSize: "1.25rem", cursor: "default" }}>
                  {ALL_BADGES_META[b]?.icon || "🏅"}
                </span>
              ))}
              {earnedBadges.length > 6 && <span style={{ fontSize: "0.75rem", color: "var(--text-muted)", alignSelf: "center" }}>+{earnedBadges.length - 6}</span>}
              {earnedBadges.length === 0 && <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>Complete exams to earn badges!</span>}
            </div>
            <button className="btn btn-secondary btn-sm" onClick={() => setView("achievements")}>View All →</button>
          </div>
        </div>
      )}

      <div className="grid-2">
        <div className="card">
          <h3 style={{ fontFamily: "Syne", fontWeight: 700, marginBottom: "1rem" }}>
            {isAdmin ? "📚 Questions by Subject" : "📋 Available Exams"}
          </h3>
          {isAdmin ? (
            Object.entries(subjectStats).map(([sub, cnt]) => (
              <div key={sub} className="flex-between mb-2">
                <span className="text-sm">{sub}</span>
                <div className="flex gap-1" style={{ alignItems: "center" }}>
                  <div style={{ width: 120, height: 6, background: "var(--surface2)", borderRadius: 3, overflow: "hidden" }}>
                    <div style={{ width: `${(cnt / questions.length) * 100}%`, height: "100%", background: "var(--accent)", borderRadius: 3 }} />
                  </div>
                  <span className="text-sm text-muted">{cnt}</span>
                </div>
              </div>
            ))
          ) : (
            exams.slice(0, 5).map(e => (
              <div key={e.id} className="flex-between mb-2">
                <span className="text-sm">{e.title}</span>
                <span className="badge badge-blue">{e.adaptive ? "⚡ Adaptive" : `${e.questionIds.length} Qs`}</span>
              </div>
            ))
          )}
        </div>
        <div className="card">
          <h3 style={{ fontFamily: "Syne", fontWeight: 700, marginBottom: "1rem" }}>
            {isAdmin ? "🏆 Recent Submissions" : "🏆 My Recent Results"}
          </h3>
          {userResults.length === 0 ? (
            <div className="text-muted text-sm text-center" style={{ padding: "2rem 0" }}>No results yet</div>
          ) : userResults.slice(-5).reverse().map(r => (
            <div key={r.id} className="flex-between mb-2">
              <div>
                <div className="text-sm">{r.examTitle}</div>
                {isAdmin && <div className="text-muted" style={{ fontSize: "0.75rem" }}>{r.userName}</div>}
              </div>
              <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                {r.xpEarned > 0 && <span style={{ fontSize: "0.7rem", color: "#c4b5fd" }}>+{r.xpEarned}XP</span>}
                <span className={`badge ${r.percentage >= 60 ? "badge-green" : "badge-red"}`}>{r.percentage}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, value, label, color }) {
  return (
    <div className="stat-card">
      <div className="stat-icon">{icon}</div>
      <div className="stat-value" style={{ color }}>{value}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}

// ─── EXAMS PAGE ───────────────────────────────────────────────────────────────
function ExamsPage({ user, exams, setExams, questions, results, onStart, showToast }) {
  const [showModal, setShowModal] = useState(false);
  const [editExam, setEditExam] = useState(null);
  const isAdmin = user.role === "admin";

  const handleDelete = async (id) => {
    try {
      await apiDeleteExam(id);
      setExams(prev => prev.filter(e => e.id !== id && e._id !== id));
      showToast("Exam deleted");
    } catch (err) { showToast("Delete failed: " + err.message, "error"); }
  };

  const handleSave = async (e) => {
    try {
      if (editExam) {
        const updated = await apiUpdateExam(editExam.id || editExam._id, e);
        setExams(prev => prev.map(x => (x.id === updated._id || x._id === updated._id) ? { ...updated, id: updated._id, questionIds: (updated.questionIds || []).map(q => typeof q === "object" ? q._id : q) } : x));
        showToast("Exam updated!");
      } else {
        const created = await apiAddExam(e);
        setExams(prev => [...prev, { ...created, id: created._id, questionIds: (created.questionIds || []).map(q => typeof q === "object" ? q._id : q) }]);
        showToast("Exam created!");
      }
      setShowModal(false);
    } catch (err) { showToast("Save failed: " + err.message, "error"); }
  };

  return (
    <div className="container">
      <div className="flex-between mb-3">
        <div>
          <div className="page-title">{isAdmin ? "📋 Manage Exams" : "📋 Available Exams"}</div>
          <div className="page-subtitle">{isAdmin ? "Create and manage exams" : "Select an exam to begin"}</div>
        </div>
        {isAdmin && <button className="btn btn-primary" onClick={() => { setEditExam(null); setShowModal(true); }}>+ New Exam</button>}
      </div>
      <div className="grid-2">
        {exams.map(exam => {
          const userResult = results.find(r => r.userId === user.id && r.examId === exam.id);
          const examQs = questions.filter(q => exam.questionIds.includes(q.id));
          const isAdaptive = exam.adaptive;
          return (
            <div key={exam.id} className={`card ${isAdaptive ? "card-purple" : "card-accent"}`}>
              <div className="flex-between mb-2">
                <h3 style={{ fontFamily: "Syne", fontWeight: 700 }}>{exam.title}</h3>
                <span className="badge badge-blue">{exam.duration} min</span>
              </div>
              <div className="text-muted text-sm mb-2">📅 Created: {exam.createdAt}</div>
              <div className="flex gap-2 mb-3" style={{ flexWrap: "wrap" }}>
                {isAdaptive
                  ? <span className="adaptive-badge">⚡ Smart Difficulty · {exam.adaptiveCount || 10} Qs</span>
                  : <span className="badge badge-purple">❓ {exam.questionIds.length} Questions</span>}
                <span className="badge badge-yellow">⏱ {exam.timePerQuestion || 30}s / question</span>
                {exam.shuffleQuestions && <span className="shuffle-pill">🔀 Shuffled</span>}
                {exam.shuffleOptions   && <span className="shuffle-pill">🔀 Options shuffled</span>}
                {(exam.availableFrom || exam.availableTo) && (
                  <span className="time-window-pill">
                    🔒 {exam.availableFrom || "00:00"} – {exam.availableTo || "23:59"}
                  </span>
                )}
                {userResult && (
                  <span className="badge badge-green">
                    ✅ {userResult.adaptive ? `${userResult.abilityLabel || "Done"}` : `Score: ${userResult.percentage}%`}
                  </span>
                )}
              </div>
              <div style={{ marginBottom: "1rem", display: "flex", flexWrap: "wrap", gap: "4px" }}>
                {[...new Set(examQs.map(q => q.subject))].map(s => <span key={s} className="badge badge-yellow">{s}</span>)}
              </div>
              {isAdaptive && !isAdmin && (
                <div style={{ background: "rgba(124,58,237,0.08)", border: "1px solid rgba(124,58,237,0.2)", borderRadius: 8, padding: "8px 12px", fontSize: "0.78rem", color: "#a78bfa", marginBottom: "0.75rem" }}>
                  🧠 Questions adapt to your skill level in real-time. Starts Medium, gets harder or easier based on your answers.
                </div>
              )}
              <div className="flex gap-2">
                {!isAdmin && <button className="btn btn-primary btn-sm" onClick={() => onStart(exam)}>
                  {userResult ? (isAdaptive ? "Retake Adaptive →" : "Retake Exam") : (isAdaptive ? "Start Adaptive →" : "Start Exam →")}
                </button>}
                {isAdmin && <>
                  <button className="btn btn-secondary btn-sm" onClick={() => { setEditExam(exam); setShowModal(true); }}>Edit</button>
                  <button className="btn btn-danger btn-sm" onClick={() => handleDelete(exam.id)}>Delete</button>
                </>}
              </div>
            </div>
          );
        })}
        {exams.length === 0 && <div className="empty" style={{ gridColumn: "span 2" }}><div className="empty-icon">📭</div><div>No exams created yet</div></div>}
      </div>
      {showModal && <ExamModal exam={editExam} questions={questions} onClose={() => setShowModal(false)} onSave={handleSave} />}
    </div>
  );
}

function ExamModal({ exam, questions, onClose, onSave }) {
  const [title,            setTitle]           = useState(exam?.title || "");
  const [duration,         setDuration]        = useState(exam?.duration || 10);
  const [timePerQuestion,  setTimePerQuestion] = useState(exam?.timePerQuestion || 30);
  const [selectedQs,       setSelectedQs]      = useState(new Set(exam?.questionIds || []));
  const [shuffleQuestions, setShuffleQuestions]= useState(exam?.shuffleQuestions || false);
  const [shuffleOptions,   setShuffleOptions]  = useState(exam?.shuffleOptions   || false);
  const [availableFrom,    setAvailableFrom]   = useState(exam?.availableFrom || "");
  const [availableTo,      setAvailableTo]     = useState(exam?.availableTo   || "");

  const toggle = (id) => setSelectedQs(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });

  const handleSave = () => {
    onSave({
      id: exam?.id,
      title, duration, timePerQuestion,
      questionIds: [...selectedQs],
      createdAt: exam?.createdAt || new Date().toISOString().split("T")[0],
      shuffleQuestions,
      shuffleOptions,
      availableFrom: availableFrom || null,
      availableTo:   availableTo   || null,
    });
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-title">{exam ? "✏️ Edit Exam" : "➕ New Exam"}</div>

        <div className="form-group">
          <label className="form-label">Exam Title</label>
          <input className="form-input" value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. MERN Stack Fundamentals" />
        </div>

        <div className="grid-2" style={{ gap: "1rem" }}>
          <div className="form-group">
            <label className="form-label">Total Duration (minutes)</label>
            <input className="form-input" type="number" value={duration} onChange={e => setDuration(Number(e.target.value))} min="1" />
          </div>
          <div className="form-group">
            <label className="form-label">Time Per Question (seconds)</label>
            <input className="form-input" type="number" value={timePerQuestion} onChange={e => setTimePerQuestion(Number(e.target.value))} min="5" max="300" />
          </div>
        </div>

        {/* ── Time-of-day lock ── */}
        <div className="grid-2" style={{ gap: "1rem" }}>
          <div className="form-group">
            <label className="form-label">🔒 Available From (HH:MM)</label>
            <input className="form-input" type="time" value={availableFrom} onChange={e => setAvailableFrom(e.target.value)} placeholder="e.g. 09:00" />
            <div style={{ fontSize: "0.72rem", color: "var(--text-muted)", marginTop: 3 }}>Leave blank = always available</div>
          </div>
          <div className="form-group">
            <label className="form-label">🔓 Available Until (HH:MM)</label>
            <input className="form-input" type="time" value={availableTo} onChange={e => setAvailableTo(e.target.value)} placeholder="e.g. 17:00" />
          </div>
        </div>

        {/* ── Shuffle toggles ── */}
        <div className="form-group">
          <label className="form-label">🔀 Randomization</label>
          <div style={{ display: "flex", gap: "1.5rem", flexWrap: "wrap" }}>
            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: "0.88rem" }}>
              <input type="checkbox" checked={shuffleQuestions} onChange={e => setShuffleQuestions(e.target.checked)} />
              Shuffle question order per student
            </label>
            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: "0.88rem" }}>
              <input type="checkbox" checked={shuffleOptions} onChange={e => setShuffleOptions(e.target.checked)} />
              Shuffle answer options per question
            </label>
          </div>
        </div>

        <div className="form-group">
          <label className="form-label">Select Questions ({selectedQs.size} selected)</label>
          <div style={{ maxHeight: 240, overflowY: "auto", background: "var(--surface2)", borderRadius: 8, padding: "8px" }}>
            {questions.map(q => (
              <label key={q.id} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "8px", cursor: "pointer", borderRadius: 6, background: selectedQs.has(q.id) ? "rgba(0,212,255,0.08)" : "transparent" }}>
                <input type="checkbox" checked={selectedQs.has(q.id)} onChange={() => toggle(q.id)} style={{ marginTop: 3 }} />
                <span style={{ fontSize: "0.85rem" }}>
                  <span className="badge badge-blue" style={{ marginRight: 6 }}>{q.subject}</span>
                  {q.text}
                </span>
              </label>
            ))}
          </div>
        </div>

        <div className="flex gap-2">
          <button className="btn btn-primary" disabled={!title || selectedQs.size === 0} onClick={handleSave}>
            {exam ? "Update Exam" : "Create Exam"}
          </button>
          <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}

// ─── QUESTIONS PAGE ───────────────────────────────────────────────────────────
function QuestionsPage({ questions, setQuestions, showToast }) {
  const [showModal, setShowModal] = useState(false);
  const [editQ, setEditQ] = useState(null);
  const [filter, setFilter] = useState("All");
  const subjects = ["All", ...new Set(questions.map(q => q.subject))];

  const handleDelete = async (id) => {
    try {
      await apiDeleteQuestion(id);
      setQuestions(prev => prev.filter(q => q.id !== id && q._id !== id));
      showToast("Question deleted");
    } catch (err) { showToast("Delete failed: " + err.message, "error"); }
  };

  const handleSave = async (q) => {
    try {
      if (editQ) {
        const updated = await apiUpdateQuestion(editQ.id || editQ._id, q);
        setQuestions(prev => prev.map(x => (x.id === updated._id || x._id === updated._id) ? { ...updated, id: updated._id } : x));
        showToast("Question updated!");
      } else {
        const created = await apiAddQuestion(q);
        setQuestions(prev => [...prev, { ...created, id: created._id }]);
        showToast("Question added!");
      }
      setShowModal(false);
    } catch (err) { showToast("Save failed: " + err.message, "error"); }
  };

  const filtered = filter === "All" ? questions : questions.filter(q => q.subject === filter);

  return (
    <div className="container">
      <div className="flex-between mb-3">
        <div>
          <div className="page-title">❓ Question Bank</div>
          <div className="page-subtitle">{questions.length} questions across {subjects.length - 1} subjects</div>
        </div>
        <button className="btn btn-primary" onClick={() => { setEditQ(null); setShowModal(true); }}>+ Add Question</button>
      </div>
      <div className="flex gap-2 mb-3" style={{ flexWrap: "wrap" }}>
        {subjects.map(s => <button key={s} className={`btn ${filter === s ? "btn-primary" : "btn-secondary"} btn-sm`} onClick={() => setFilter(s)}>{s}</button>)}
      </div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>#</th><th>Subject</th><th>Question</th><th>Options</th><th>Actions</th></tr></thead>
          <tbody>
            {filtered.map((q, i) => (
              <tr key={q.id}>
                <td style={{ color: "var(--text-muted)" }}>{i + 1}</td>
                <td><span className="badge badge-blue">{q.subject}</span></td>
                <td style={{ maxWidth: 300 }}>{q.text}</td>
                <td style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>{q.options.map((o, idx) => <div key={idx} style={{ color: idx === q.answer ? "var(--accent3)" : undefined }}>{["A","B","C","D"][idx]}. {o}</div>)}</td>
                <td>
                  <div className="flex gap-1">
                    <button className="btn btn-secondary btn-sm" onClick={() => { setEditQ(q); setShowModal(true); }}>Edit</button>
                    <button className="btn btn-danger btn-sm" onClick={() => handleDelete(q.id || q._id)}>Del</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showModal && <QuestionModal q={editQ} onClose={() => setShowModal(false)} onSave={handleSave} />}
    </div>
  );
}

function QuestionModal({ q, onClose, onSave }) {
  const [text, setText] = useState(q?.text || "");
  const [subject, setSubject] = useState(q?.subject || "JavaScript");
  const [options, setOptions] = useState(q?.options || ["", "", "", ""]);
  const [answer, setAnswer] = useState(q?.answer ?? 0);

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-title">{q ? "✏️ Edit Question" : "➕ New Question"}</div>
        <div className="form-group">
          <label className="form-label">Subject</label>
          <input className="form-input" value={subject} onChange={e => setSubject(e.target.value)} placeholder="e.g. JavaScript" />
        </div>
        <div className="form-group">
          <label className="form-label">Question Text</label>
          <textarea className="form-input" rows={3} value={text} onChange={e => setText(e.target.value)} placeholder="Enter question..." style={{ resize: "vertical" }} />
        </div>
        <div className="form-group">
          <label className="form-label">Options (select correct answer)</label>
          {options.map((opt, i) => (
            <div key={i} className="flex gap-2 mb-2" style={{ alignItems: "center" }}>
              <input type="radio" name="ans" checked={answer === i} onChange={() => setAnswer(i)} />
              <span style={{ color: "var(--text-muted)", fontSize: "0.85rem", width: 20 }}>{["A","B","C","D"][i]}.</span>
              <input className="form-input" style={{ flex: 1 }} value={opt} onChange={e => setOptions(prev => prev.map((o, j) => j === i ? e.target.value : o))} placeholder={`Option ${["A","B","C","D"][i]}`} />
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <button className="btn btn-primary" disabled={!text || options.some(o => !o)} onClick={() => onSave({ id: q?.id, text, subject, options, answer })}>
            {q ? "Update" : "Add Question"}
          </button>
          <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}

// ─── EXAM VIEW ────────────────────────────────────────────────────────────────
// Features: Randomised Q+Option order, Cheat detection, Streak multiplier display
function ExamView({ exam, questions, user, onFinish, onExit, gamification }) {
  // ── Seed-based shuffle using user ID for reproducibility per-student per-exam ─
  function seededShuffle(arr, seed) {
    const a = [...arr];
    let s = seed;
    for (let i = a.length - 1; i > 0; i--) {
      s = (s * 1664525 + 1013904223) & 0xffffffff;
      const j = Math.abs(s) % (i + 1);
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  // Build deterministic seed from userId + examId
  const shuffleSeed = useMemo(() => {
    const str = (user?.id || "x") + (exam?.id || "y");
    let h = 0;
    for (let i = 0; i < str.length; i++) { h = (Math.imul(31, h) + str.charCodeAt(i)) | 0; }
    return Math.abs(h);
  }, [user?.id, exam?.id]);

  // Shuffled questions (order stable for this student+exam combo)
  const rawQs = questions.filter(q => exam.questionIds.includes(q.id));
  const examQs = useMemo(() => {
    if (!exam.shuffleQuestions) return rawQs;
    return seededShuffle(rawQs, shuffleSeed);
  }, [shuffleSeed, exam.shuffleQuestions]); // eslint-disable-line

  // Per-question option shuffling: { qId → [shuffledOptIndex...] }
  // optionMaps[qId][displayIdx] = originalIdx
  const optionMaps = useMemo(() => {
    const maps = {};
    examQs.forEach(q => {
      if (!exam.shuffleOptions) {
        maps[q.id] = [0, 1, 2, 3];
      } else {
        const s = shuffleSeed + parseInt((q.id || "0").slice(-4), 16);
        maps[q.id] = seededShuffle([0, 1, 2, 3], s);
      }
    });
    return maps;
  }, [examQs, exam.shuffleOptions, shuffleSeed]);

  const timePerQ = exam.timePerQuestion || 30;
  // Overall exam duration in seconds (duration is stored in minutes)
  const totalExamSecs = (exam.duration || 30) * 60;

  const [current, setCurrent]       = useState(0);
  const [answers, setAnswers]       = useState({}); // { qId: originalOptionIndex }
  const [qTimeLeft, setQTimeLeft]   = useState(timePerQ);
  const [examTimeLeft, setExamTimeLeft] = useState(totalExamSecs); // ← overall countdown
  const [skipped, setSkipped]       = useState(new Set());
  const [submitted, setSubmitted]   = useState(false);
  const [confirmExit, setConfirmExit] = useState(false);
  const [flash, setFlash]           = useState(false);

  // ── Per-question response time tracking ──────────────────────────────────────
  const qStartTime    = useRef(Date.now());
  const responseTimes = useRef([]);  // ms per question (in question order)

  useEffect(() => { qStartTime.current = Date.now(); }, [current]);

  // ── Cheat Detection state ─────────────────────────────────────────────────────
  const cheatData = useRef({ tabSwitches: 0, copyPasteCount: 0 });
  const [cheatWarning, setCheatWarning] = useState(null);

  useEffect(() => {
    if (submitted) return;
    const onVisChange = () => {
      if (document.hidden) {
        cheatData.current.tabSwitches++;
        const n = cheatData.current.tabSwitches;
        setCheatWarning(`⚠️ Tab switch detected! (${n} time${n > 1 ? "s" : ""}) — this is recorded.`);
        setTimeout(() => setCheatWarning(null), 4000);
      }
    };
    const onCopyPaste = () => {
      cheatData.current.copyPasteCount++;
      setCheatWarning("⚠️ Copy/paste detected — this exam does not allow it.");
      setTimeout(() => setCheatWarning(null), 3000);
    };
    document.addEventListener("visibilitychange", onVisChange);
    document.addEventListener("copy",  onCopyPaste);
    document.addEventListener("paste", onCopyPaste);
    return () => {
      document.removeEventListener("visibilitychange", onVisChange);
      document.removeEventListener("copy",  onCopyPaste);
      document.removeEventListener("paste", onCopyPaste);
    };
  }, [submitted]);

  const answered = Object.keys(answers).length;
  const isLastQ  = current === examQs.length - 1;

  const recordResponseTime = useCallback(() => {
    const ms = Date.now() - qStartTime.current;
    responseTimes.current[current] = ms;
  }, [current]);

  const submit = useCallback((auto = false) => {
    if (submitted) return;
    setSubmitted(true);
    let correct = 0;
    examQs.forEach(q => { if (answers[q.id] === q.answer) correct++; });
    const percentage = Math.round((correct / examQs.length) * 100);
    setTimeout(() => onFinish({
      examId: exam.id, examTitle: exam.title,
      correct, total: examQs.length, percentage,
      answers, questions: examQs,
      autoSubmitted: auto,
      responseTimes: responseTimes.current,
      cheatData: { ...cheatData.current },
    }), 400);
  }, [answers, examQs, exam, onFinish, submitted]);

  const advanceQuestion = useCallback((autoSkip = false) => {
    if (submitted) return;
    recordResponseTime();
    const currentQ = examQs[current];
    if (autoSkip && answers[currentQ.id] === undefined) {
      setSkipped(prev => new Set([...prev, currentQ.id]));
      responseTimes.current[current] = timePerQ * 1000; // full time = timed out
      setFlash(true);
      setTimeout(() => setFlash(false), 600);
    }
    if (isLastQ) { submit(autoSkip); }
    else { setCurrent(p => p + 1); setQTimeLeft(timePerQ); }
  }, [current, examQs, answers, isLastQ, submit, submitted, timePerQ, recordResponseTime]);

  useEffect(() => {
    if (submitted) return;
    if (qTimeLeft <= 0) { advanceQuestion(true); return; }
    const t = setTimeout(() => setQTimeLeft(p => p - 1), 1000);
    return () => clearTimeout(t);
  }, [qTimeLeft, advanceQuestion, submitted]);

  // ── Overall exam duration countdown — auto-submits when total time is up ──────
  useEffect(() => {
    if (submitted) return;
    if (examTimeLeft <= 0) { submit(true); return; }
    const t = setTimeout(() => setExamTimeLeft(p => p - 1), 1000);
    return () => clearTimeout(t);
  }, [examTimeLeft, submit, submitted]);

  useEffect(() => { setQTimeLeft(timePerQ); }, [current, timePerQ]);

  const pct           = qTimeLeft / timePerQ;
  const circumference = 2 * Math.PI * 26;
  const strokeDash    = circumference * pct;
  const ringColor     = pct > 0.5 ? "var(--accent)" : pct > 0.25 ? "var(--warning)" : "var(--danger)";
  const barColor      = ringColor;
  const currentQId    = examQs[current]?.id;
  const isSkipped     = skipped.has(currentQId);
  const currentQ      = examQs[current];
  const displayOpts   = optionMaps[currentQ?.id] || [0,1,2,3];

  // Streak multiplier display
  const streak = gamification?.streak || 0;
  const multiplier = streak >= 30 ? 2.0 : streak >= 14 ? 1.75 : streak >= 7 ? 1.5 : streak >= 3 ? 1.25 : 1.0;

  return (
    <div style={{ minHeight: "100vh", background: flash ? "rgba(239,68,68,0.04)" : "var(--bg)", transition: "background 0.3s" }}>
      <style>{STYLES}</style>

      {/* ── Cheat warning banner ── */}
      {cheatWarning && (
        <div className="cheat-warn-banner">
          {cheatWarning}
          <span style={{ marginLeft: "auto", opacity: 0.8, fontSize: "0.75rem" }}>This activity is logged.</span>
        </div>
      )}

      <div className="exam-header" style={{ marginTop: cheatWarning ? 42 : 0 }}>
        <div>
          <div style={{ fontFamily: "Syne", fontWeight: 700 }}>{exam.title}</div>
          <div className="text-muted text-sm">{answered}/{examQs.length} answered · {skipped.size} skipped</div>
        </div>
        <div className="flex gap-2" style={{ alignItems: "center", flex: 1, margin: "0 2rem" }}>
          <div className="progress-bar-wrap">
            <div className="progress-bar" style={{ width: `${(answered / examQs.length) * 100}%` }} />
          </div>
        </div>
        {/* ── Overall exam time remaining ── */}
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {/* Overall time pill */}
            <div style={{
              display: "flex", alignItems: "center", gap: 5,
              background: examTimeLeft <= 60 ? "rgba(239,68,68,0.15)" : examTimeLeft <= 300 ? "rgba(245,158,11,0.12)" : "rgba(0,212,255,0.08)",
              border: `1px solid ${examTimeLeft <= 60 ? "rgba(239,68,68,0.4)" : examTimeLeft <= 300 ? "rgba(245,158,11,0.35)" : "rgba(0,212,255,0.2)"}`,
              borderRadius: 20, padding: "4px 12px",
              color: examTimeLeft <= 60 ? "var(--danger)" : examTimeLeft <= 300 ? "var(--warning)" : "var(--accent)",
              fontFamily: "Syne", fontWeight: 700, fontSize: "0.92rem",
              animation: examTimeLeft <= 30 ? "pulse 0.8s infinite" : "none",
            }}>
              ⏱ {Math.floor(examTimeLeft / 60)}:{String(examTimeLeft % 60).padStart(2, "0")}
            </div>
          </div>
          <div style={{ fontFamily: "Syne", fontWeight: 700, color: "var(--text-dim)", fontSize: "0.8rem" }}>Q {current + 1}/{examQs.length}</div>
          {multiplier > 1 && (
            <div className={`multiplier-badge ${multiplier >= 2 ? "x2" : ""}`}>
              🔥 {multiplier}x XP · {streak}-day streak
            </div>
          )}
          {exam.shuffleQuestions && <div className="shuffle-pill">🔀 Shuffled</div>}
        </div>
      </div>

      <div className="container" style={{ maxWidth: 800 }}>
        <div className="card mt-3" style={{ position: "relative" }}>

          {/* Question navigation dots */}
          <div className="q-nav">
            {examQs.map((q, i) => (
              <div key={q.id}
                className={`q-num ${i === current ? "current" : answers[q.id] !== undefined ? "answered" : ""}`}
                style={skipped.has(q.id) && i !== current ? { background: "rgba(239,68,68,0.12)", borderColor: "var(--danger)", color: "var(--danger)" } : {}}
                onClick={() => { if (!submitted) { recordResponseTime(); setCurrent(i); setQTimeLeft(timePerQ); } }}
                title={skipped.has(q.id) ? "Time expired" : answers[q.id] !== undefined ? "Answered" : "Unanswered"}
              >{i + 1}</div>
            ))}
          </div>

          <div className="q-timer-bar-wrap">
            <div className="q-timer-bar" style={{ width: `${(qTimeLeft / timePerQ) * 100}%`, background: barColor }} />
          </div>

          <div className="flex-between" style={{ marginBottom: "1rem", alignItems: "flex-start" }}>
            <div>
              <span className="badge badge-blue">{currentQ.subject}</span>
              <span className="text-muted text-sm" style={{ marginLeft: "0.5rem" }}>Question {current + 1} of {examQs.length}</span>
            </div>
            <div className="q-timer-ring-wrap">
              <div className="q-timer-ring">
                <svg width="64" height="64" viewBox="0 0 64 64">
                  <circle cx="32" cy="32" r="26" fill="none" stroke="var(--surface2)" strokeWidth="5" />
                  <circle cx="32" cy="32" r="26" fill="none" stroke={ringColor} strokeWidth="5"
                    strokeDasharray={`${strokeDash} ${circumference}`} strokeLinecap="round"
                    style={{ transition: "stroke-dasharray 1s linear, stroke 0.5s" }} />
                </svg>
                <div className="q-timer-ring-text" style={{ color: pct > 0.5 ? "var(--text)" : pct > 0.25 ? "var(--warning)" : "var(--danger)" }}>{qTimeLeft}</div>
              </div>
              <div className="q-timer-label">seconds</div>
            </div>
          </div>

          <h2 style={{ fontFamily: "Syne", fontWeight: 700, fontSize: "1.1rem", marginBottom: "1.5rem", lineHeight: 1.5 }}>
            {currentQ.text}
          </h2>

          {/* Shuffled options — displayOpts[i] = original option index */}
          {displayOpts.map((origIdx, displayIdx) => (
            <button
              key={displayIdx}
              className={`option-btn ${answers[currentQ.id] === origIdx ? "selected" : ""}`}
              onClick={() => {
                if (isSkipped) return;
                setAnswers(prev => ({ ...prev, [currentQ.id]: origIdx }));
              }}
              disabled={isSkipped}
            >
              <span className="option-letter">{["A","B","C","D"][displayIdx]}</span>
              {currentQ.options[origIdx]}
            </button>
          ))}

          {isSkipped && (
            <div style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.3)", borderRadius: 8, padding: "10px 14px", fontSize: "0.85rem", color: "var(--danger)", marginTop: "0.5rem" }}>
              ⏰ Time expired for this question — no answer recorded
            </div>
          )}

          <div className="flex-between mt-3">
            <button className="btn btn-secondary" disabled={current === 0} onClick={() => { recordResponseTime(); setCurrent(p => p - 1); setQTimeLeft(timePerQ); }}>← Previous</button>
            <div className="flex gap-2">
              {!isLastQ
                ? <button className="btn btn-primary" onClick={() => advanceQuestion(false)}>Next →</button>
                : <button className="btn btn-success" onClick={() => submit(false)}>Submit Exam ✓</button>
              }
            </div>
            <button className="btn btn-secondary" onClick={() => setConfirmExit(true)}>Exit</button>
          </div>
        </div>

        <div className="flex gap-3 mt-2" style={{ flexWrap: "wrap", fontSize: "0.78rem", color: "var(--text-muted)" }}>
          <span>🟦 Current</span>
          <span style={{ color: "var(--accent)" }}>● Answered</span>
          <span style={{ color: "var(--danger)" }}>● Time Expired</span>
          <span>○ Unanswered</span>
          {cheatData.current.tabSwitches > 0 && <span style={{ color: "var(--warning)" }}>⚠️ {cheatData.current.tabSwitches} tab switch{cheatData.current.tabSwitches > 1 ? "es" : ""} recorded</span>}
        </div>
      </div>

      {confirmExit && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 380 }}>
            <div className="modal-title">⚠️ Exit Exam?</div>
            <p className="text-muted mb-3">Your progress will be lost. Are you sure?</p>
            <div className="flex gap-2">
              <button className="btn btn-danger" onClick={onExit}>Yes, Exit</button>
              <button className="btn btn-secondary" onClick={() => setConfirmExit(false)}>Continue Exam</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── ADAPTIVE EXAM VIEW ───────────────────────────────────────────────────────
// Smart Difficulty Calibration: uses IRT to pick questions matching student ability.
// Ability (θ) starts at 0. Each answer updates θ and selects the next question.
function AdaptiveExamView({ exam, user, onFinish, onExit }) {
  const timePerQ     = exam.timePerQuestion || 45;
  const totalCount   = exam.adaptiveCount   || 10;

  // ── Engine state ──────────────────────────────────────────────────────────
  const [theta,        setTheta]       = useState(0);
  const [abilityLabel, setAbilityLabel]= useState("Intermediate");
  const [targetDiff,   setTargetDiff]  = useState(3);
  const [question,     setQuestion]    = useState(null);
  const [seenIds,      setSeenIds]     = useState([]);
  const [selected,     setSelected]    = useState(null);
  const [loading,      setLoading]     = useState(true);
  const [submitting,   setSubmitting]  = useState(false);
  const [confirmExit,  setConfirmExit] = useState(false);
  const [hintVisible,  setHintVisible] = useState(false);
  const [answered,     setAnswered]    = useState(false); // locked after selection

  // ── Per-question timer ────────────────────────────────────────────────────
  const [qTimeLeft, setQTimeLeft] = useState(timePerQ);
  const questionStartMs = useRef(Date.now());

  // ── Running log of answers ─────────────────────────────────────────────────
  const answersLog    = useRef({});   // { questionId: selectedIndex }
  const diffPath      = useRef([]);   // difficulty of each question asked
  const respTimes     = useRef([]);   // ms taken per question
  const hintLog       = useRef([]);   // boolean per question
  const correctCount  = useRef(0);
  const questionIndex = useRef(0);    // how many questions shown so far
  const currentTheta  = useRef(0);    // keep ref in sync for timeout callback

  // ── Fetch next question from server ───────────────────────────────────────
  const fetchNext = useCallback(async (latestTheta, latestSeenIds) => {
    setLoading(true);
    setSelected(null);
    setAnswered(false);
    setHintVisible(false);
    try {
      const res = await apiAdaptiveNext({
        examId:          exam.id || exam._id,
        seenIds:         latestSeenIds,
        theta:           latestTheta,
        timePerQuestion: timePerQ,
      });
      if (res.done || !res.question) {
        // No more questions — auto-finish
        finishSession(latestTheta);
        return;
      }
      setQuestion(res.question);
      setTargetDiff(res.targetDifficulty);
      setAbilityLabel(res.abilityLabel);
      setQTimeLeft(timePerQ);
      questionStartMs.current = Date.now();
    } catch (err) {
      console.error("Adaptive next error:", err);
    } finally {
      setLoading(false);
    }
  }, [exam, timePerQ]); // eslint-disable-line

  // Mount: fetch first question
  useEffect(() => { fetchNext(0, []); }, []); // eslint-disable-line

  // ── Per-question countdown ─────────────────────────────────────────────────
  useEffect(() => {
    if (loading || answered || submitting) return;
    if (qTimeLeft <= 0) {
      // Time expired — treat as wrong, no answer
      handleAnswer(null, true);
      return;
    }
    const t = setTimeout(() => setQTimeLeft(p => p - 1), 1000);
    return () => clearTimeout(t);
  }, [qTimeLeft, loading, answered, submitting]); // eslint-disable-line

  // ── Process answer ─────────────────────────────────────────────────────────
  const handleAnswer = useCallback(async (selectedIndex, autoSkipped = false) => {
    if (answered || loading || submitting) return;
    setAnswered(true);

    const responseMs   = Date.now() - questionStartMs.current;
    const isCorrect    = !autoSkipped && selectedIndex === question.answer;
    const usedHint     = hintVisible;

    if (!autoSkipped) setSelected(selectedIndex);
    if (isCorrect) correctCount.current++;

    // Log
    answersLog.current[question._id || question.id] = autoSkipped ? -1 : selectedIndex;
    diffPath.current.push(question.difficulty);
    respTimes.current.push(responseMs);
    hintLog.current.push(usedHint);
    questionIndex.current++;

    // Update theta via server
    try {
      const res = await apiAdaptiveAnswer({
        questionId:      question._id || question.id,
        isCorrect,
        responseMs,
        theta:           currentTheta.current,
        timePerQuestion: timePerQ,
      });
      currentTheta.current = res.newTheta;
      setTheta(res.newTheta);
      setAbilityLabel(res.abilityLabel);
      setTargetDiff(res.targetDifficulty);
    } catch (err) {
      console.error("Adaptive answer error:", err);
    }

    // Pause to show feedback, then advance
    setTimeout(() => {
      if (questionIndex.current >= totalCount) {
        finishSession(currentTheta.current);
      } else {
        const newSeenIds = [...seenIds, question._id || question.id];
        setSeenIds(newSeenIds);
        fetchNext(currentTheta.current, newSeenIds);
      }
    }, autoSkipped ? 600 : 1200);
  }, [answered, loading, submitting, question, hintVisible, seenIds, timePerQ, totalCount, fetchNext]); // eslint-disable-line

  // ── Build final result and submit ──────────────────────────────────────────
  const finishSession = useCallback((finalTheta) => {
    setSubmitting(true);
    const total      = questionIndex.current;
    const correct    = correctCount.current;
    const percentage = total > 0 ? Math.round((correct / total) * 100) : 0;
    const label      = thetaToLabel(finalTheta);

    onFinish({
      examId:        exam.id || exam._id,
      examTitle:     exam.title,
      correct,
      total,
      percentage,
      answers:       answersLog.current,
      autoSubmitted: false,
      adaptive:      true,
      finalAbility:  finalTheta,
      abilityLabel:  label,
      difficultyPath:diffPath.current,
      responseTimes: respTimes.current,
      hintUsed:      hintLog.current,
    });
  }, [exam, onFinish]);

  // ── IRT helpers (client-side display only) ─────────────────────────────────
  function thetaToLabel(t) {
    if (t < -1.5) return "Beginner";
    if (t < -0.5) return "Elementary";
    if (t < 0.5)  return "Intermediate";
    if (t < 1.5)  return "Advanced";
    return "Expert";
  }

  function thetaFillPct(t) { return Math.round(((t + 3) / 6) * 100); }

  const ABILITY_COLORS = {
    Beginner:     { color: "#ef4444", glow: "rgba(239,68,68,0.4)" },
    Elementary:   { color: "#f59e0b", glow: "rgba(245,158,11,0.4)" },
    Intermediate: { color: "#00d4ff", glow: "rgba(0,212,255,0.4)" },
    Advanced:     { color: "#8b5cf6", glow: "rgba(139,92,246,0.4)" },
    Expert:       { color: "#10b981", glow: "rgba(16,185,129,0.4)" },
  };

  const DIFF_COLORS = ["#ef4444", "#f59e0b", "#00d4ff", "#8b5cf6", "#10b981"];

  const abilityStyle = ABILITY_COLORS[abilityLabel] || ABILITY_COLORS["Intermediate"];
  const fillPct      = thetaFillPct(theta);
  const pct          = qTimeLeft / timePerQ;
  const circumference = 2 * Math.PI * 26;
  const strokeDash    = circumference * pct;
  const ringColor     = pct > 0.5 ? "var(--accent)" : pct > 0.25 ? "var(--warning)" : "var(--danger)";

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg)" }}>
      <style>{STYLES}</style>

      {/* ── Adaptive Header ── */}
      <div className="exam-header" style={{ gap: "1.5rem" }}>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontFamily: "Syne", fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
            {exam.title}
          </div>
          <div style={{ marginTop: 4 }}>
            <span className="adaptive-badge">⚡ Smart Difficulty</span>
          </div>
        </div>

        {/* Ability meter */}
        <div style={{ flex: 1, maxWidth: 260 }}>
          <div className="flex-between" style={{ marginBottom: 4 }}>
            <span style={{ fontSize: "0.72rem", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px" }}>Ability</span>
            <span style={{ fontSize: "0.8rem", fontWeight: 700, color: abilityStyle.color }}>{abilityLabel}</span>
          </div>
          <div className="theta-track">
            <div className="theta-fill" style={{ width: `${fillPct}%`, background: `linear-gradient(90deg, ${abilityStyle.color}88, ${abilityStyle.color})` }} />
          </div>
          <div className="flex-between mt-1" style={{ fontSize: "0.68rem", color: "var(--text-muted)" }}>
            <span>Beginner</span><span>Expert</span>
          </div>
        </div>

        {/* Difficulty pips */}
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: "0.68rem", color: "var(--text-muted)", marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.5px" }}>Target Difficulty</div>
          <div className="difficulty-bar" style={{ justifyContent: "center" }}>
            {[1,2,3,4,5].map(d => (
              <div key={d} className={`difficulty-pip ${d <= targetDiff ? "active" : ""}`}
                style={{ background: d <= targetDiff ? DIFF_COLORS[targetDiff - 1] : "var(--surface2)", opacity: d <= targetDiff ? 1 : 0.3 }} />
            ))}
          </div>
          <div style={{ fontSize: "0.68rem", color: "var(--text-muted)", marginTop: 2 }}>
            {["","Beginner","Easy","Medium","Hard","Expert"][targetDiff]}
          </div>
        </div>

        {/* Progress */}
        <div style={{ textAlign: "right", whiteSpace: "nowrap" }}>
          <div style={{ fontFamily: "Syne", fontWeight: 700, color: "var(--text-dim)" }}>
            {questionIndex.current + (loading ? 0 : 1)}/{totalCount}
          </div>
          <div style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>{correctCount.current} correct</div>
        </div>
      </div>

      {/* ── Question card ── */}
      <div className="container" style={{ maxWidth: 800 }}>
        {loading ? (
          <div className="card mt-3 flex-center" style={{ minHeight: 320, flexDirection: "column", gap: 16 }}>
            <div style={{ width: 40, height: 40, border: "3px solid var(--border)", borderTop: "3px solid var(--accent)", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
            <div style={{ color: "var(--text-muted)", fontSize: "0.9rem" }}>Calibrating next question…</div>
            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
          </div>
        ) : question ? (
          <div key={question._id} className="card mt-3 adaptive-q-enter" style={{ position: "relative" }}>

            {/* Top row: subject + difficulty badge + timer */}
            <div className="flex-between" style={{ marginBottom: "1rem", alignItems: "flex-start" }}>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                  <span className="badge badge-blue">{question.subject}</span>
                  <span style={{
                    background: `${DIFF_COLORS[question.difficulty - 1]}22`,
                    border: `1px solid ${DIFF_COLORS[question.difficulty - 1]}55`,
                    color: DIFF_COLORS[question.difficulty - 1],
                    padding: "2px 10px", borderRadius: 20, fontSize: "0.73rem", fontWeight: 600,
                  }}>
                    {"★".repeat(question.difficulty)}{"☆".repeat(5 - question.difficulty)} {["","Beginner","Easy","Medium","Hard","Expert"][question.difficulty]}
                  </span>
                </div>
                <div style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>
                  Question {questionIndex.current + 1} of {totalCount}
                </div>
              </div>

              {/* Circular timer */}
              <div className="q-timer-ring-wrap">
                <div className="q-timer-ring">
                  <svg width="64" height="64" viewBox="0 0 64 64">
                    <circle cx="32" cy="32" r="26" fill="none" stroke="var(--surface2)" strokeWidth="5" />
                    <circle cx="32" cy="32" r="26" fill="none" stroke={ringColor} strokeWidth="5"
                      strokeDasharray={`${strokeDash} ${circumference}`} strokeLinecap="round"
                      style={{ transition: "stroke-dasharray 1s linear, stroke 0.5s" }} />
                  </svg>
                  <div className="q-timer-ring-text" style={{ color: pct > 0.5 ? "var(--text)" : pct > 0.25 ? "var(--warning)" : "var(--danger)" }}>{qTimeLeft}</div>
                </div>
                <div className="q-timer-label">seconds</div>
              </div>
            </div>

            {/* Timer progress bar */}
            <div className="q-timer-bar-wrap" style={{ marginBottom: "1.25rem" }}>
              <div className="q-timer-bar" style={{ width: `${(qTimeLeft / timePerQ) * 100}%`, background: ringColor }} />
            </div>

            <h2 style={{ fontFamily: "Syne", fontWeight: 700, fontSize: "1.1rem", marginBottom: "1.5rem", lineHeight: 1.6 }}>
              {question.text}
            </h2>

            {/* Options */}
            {question.options.map((opt, i) => {
              let style = {};
              if (answered) {
                if (i === question.answer)  style = { background: "rgba(16,185,129,0.15)", borderColor: "var(--accent3)", color: "var(--accent3)" };
                else if (i === selected)    style = { background: "rgba(239,68,68,0.12)", borderColor: "var(--danger)", color: "var(--danger)" };
              }
              return (
                <button
                  key={i}
                  className={`option-btn ${!answered && selected === i ? "selected" : ""}`}
                  style={style}
                  disabled={answered}
                  onClick={() => !answered && handleAnswer(i)}
                >
                  <span className="option-letter">{["A","B","C","D"][i]}</span>
                  {opt}
                  {answered && i === question.answer && <span style={{ marginLeft: "auto", fontSize: "0.8rem" }}>✓ Correct</span>}
                  {answered && i === selected && i !== question.answer && <span style={{ marginLeft: "auto", fontSize: "0.8rem" }}>✗ Wrong</span>}
                </button>
              );
            })}

            {/* Hint */}
            {question.hint && (
              <div style={{ marginTop: "0.75rem" }}>
                {!hintVisible ? (
                  <button
                    className="btn btn-secondary btn-sm"
                    style={{ fontSize: "0.78rem", color: "var(--warning)", borderColor: "rgba(245,158,11,0.3)" }}
                    onClick={() => setHintVisible(true)}
                    disabled={answered}
                  >
                    💡 Show Hint
                  </button>
                ) : (
                  <div className="hint-box">
                    <span>💡</span>
                    <span>{question.hint}</span>
                  </div>
                )}
              </div>
            )}

            {/* Feedback after answer */}
            {answered && (
              <div style={{
                marginTop: "1rem", padding: "10px 14px", borderRadius: 8, fontSize: "0.85rem",
                background: selected === question.answer ? "rgba(16,185,129,0.08)" : "rgba(239,68,68,0.08)",
                border: `1px solid ${selected === question.answer ? "rgba(16,185,129,0.25)" : "rgba(239,68,68,0.25)"}`,
                color: selected === question.answer ? "var(--accent3)" : "var(--danger)",
                display: "flex", alignItems: "center", gap: 8,
              }}>
                {selected === question.answer
                  ? "✅ Correct! Difficulty will increase."
                  : selected === -1
                    ? "⏰ Time expired — no answer recorded."
                    : "❌ Incorrect. Let's try an easier question."}
                <span style={{ marginLeft: "auto", color: "var(--text-muted)", fontSize: "0.78rem" }}>
                  Next question in a moment…
                </span>
              </div>
            )}

            {/* Exit button */}
            <div style={{ marginTop: "1.5rem", textAlign: "right" }}>
              <button className="btn btn-secondary btn-sm" onClick={() => setConfirmExit(true)}>Exit Exam</button>
            </div>
          </div>
        ) : null}

        {/* Ability journey so far */}
        {diffPath.current.length > 0 && (
          <div className="card mt-2" style={{ padding: "1rem 1.25rem" }}>
            <div style={{ fontSize: "0.75rem", color: "var(--text-muted)", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.5px" }}>
              Difficulty Journey
            </div>
            <div className="ability-timeline">
              {diffPath.current.map((d, i) => (
                <div key={i} className="ability-bar-item"
                  data-label={["","Beginner","Easy","Medium","Hard","Expert"][d]}
                  style={{ height: `${(d / 5) * 100}%`, background: DIFF_COLORS[d - 1], opacity: 0.8 }} />
              ))}
              {/* Current (in progress) */}
              {question && !loading && (
                <div className="ability-bar-item"
                  style={{ height: `${(targetDiff / 5) * 100}%`, background: DIFF_COLORS[targetDiff - 1], opacity: 0.4, border: "1px dashed #fff3" }} />
              )}
            </div>
            <div style={{ fontSize: "0.68rem", color: "var(--text-muted)", marginTop: 4 }}>
              Each bar = difficulty of that question. Taller = harder.
            </div>
          </div>
        )}
      </div>

      {/* Exit confirm modal */}
      {confirmExit && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 380 }}>
            <div className="modal-title">⚠️ Exit Adaptive Exam?</div>
            <p className="text-muted mb-3">Your progress so far ({questionIndex.current} questions) will be submitted as a partial result.</p>
            <div className="flex gap-2">
              <button className="btn btn-danger" onClick={() => finishSession(currentTheta.current)}>Submit & Exit</button>
              <button className="btn btn-secondary" onClick={() => setConfirmExit(false)}>Continue</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── LAST RESULT PAGE ─────────────────────────────────────────────────────────
function LastResultPage({ result, user, questions, setView }) {
  if (!result) return <div className="container"><div className="empty"><div className="empty-icon">🏆</div><div>No results yet</div></div></div>;

  if (result.adaptive) return <AdaptiveResultPage result={result} setView={setView} />;

  const pct = result.percentage;
  const grade = pct >= 90 ? "A+" : pct >= 80 ? "A" : pct >= 70 ? "B" : pct >= 60 ? "C" : "F";
  const passed = pct >= 60;

  return (
    <div className="container" style={{ maxWidth: 720 }}>
      <div className="card text-center mt-3" style={{ padding: "2.5rem" }}>
        <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>{passed ? "🎉" : "📚"}</div>
        <h2 style={{ fontFamily: "Syne", fontWeight: 800, fontSize: "1.5rem", marginBottom: "0.5rem" }}>
          {passed ? "Congratulations!" : "Keep Practicing!"}
        </h2>
        <p className="text-muted mb-3">{result.examTitle}</p>

        <div className="score-ring" style={{ "--pct": pct }}>
          <div className="score-ring-inner">
            <div className="score-pct" style={{ color: passed ? "var(--accent3)" : "var(--danger)" }}>{pct}%</div>
            <div style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>Score</div>
          </div>
        </div>

        <div className="grid-3 mb-3">
          <div className="stat-card"><div className="stat-value text-accent">{result.correct}</div><div className="stat-label">Correct</div></div>
          <div className="stat-card"><div className="stat-value text-danger">{result.total - result.correct}</div><div className="stat-label">Wrong</div></div>
          <div className="stat-card"><div className="stat-value" style={{ color: passed ? "var(--accent3)" : "var(--danger)" }}>{grade}</div><div className="stat-label">Grade</div></div>
        </div>

        <div className="flex gap-2" style={{ justifyContent: "center", marginBottom: "2rem" }}>
          <button className="btn btn-primary" onClick={() => setView("exams")}>Take Another Exam →</button>
          <button className="btn btn-secondary" onClick={() => setView("results")}>View All Results</button>
        </div>
      </div>

      {result.questions && (
        <div className="card mt-3">
          <h3 style={{ fontFamily: "Syne", fontWeight: 700, marginBottom: "1rem" }}>📝 Answer Review</h3>
          {result.questions.map((q, i) => {
            const userAns = result.answers[q.id];
            const isCorrect = userAns === q.answer;
            return (
              <div key={q.id} className={`review-card ${isCorrect ? "correct-card" : "wrong-card"}`}>
                <div className="flex-between mb-2">
                  <div style={{ display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                    <span className="badge badge-blue">{q.subject}</span>
                    {q.difficulty && <span style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>{"★".repeat(q.difficulty)}{"☆".repeat(5-q.difficulty)}</span>}
                  </div>
                  <span className={isCorrect ? "badge badge-green" : "badge badge-red"}>{isCorrect ? "✅ Correct" : "❌ Wrong"}</span>
                </div>
                <p style={{ fontWeight: 500, marginBottom: "0.75rem" }}>Q{i + 1}. {q.text}</p>
                {q.options.map((opt, idx) => (
                  <div key={idx} style={{ fontSize: "0.875rem", padding: "6px 10px", borderRadius: 6, marginBottom: 4,
                    background: idx === q.answer ? "rgba(16,185,129,0.1)" : idx === userAns && !isCorrect ? "rgba(239,68,68,0.1)" : "transparent",
                    color: idx === q.answer ? "var(--accent3)" : idx === userAns && !isCorrect ? "var(--danger)" : "var(--text-muted)" }}>
                    {["A","B","C","D"][idx]}. {opt}
                    {idx === q.answer && <span style={{ marginLeft: 6, fontWeight: 700 }}>✓ Correct answer</span>}
                    {idx === userAns && !isCorrect && <span style={{ marginLeft: 6 }}>✗ Your answer</span>}
                  </div>
                ))}
                {/* ── Explanation shown when answer is wrong ── */}
                {!isCorrect && q.explanation && (
                  <div className="explanation-box">
                    <strong>💡 Explanation</strong>
                    {q.explanation}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── ADAPTIVE RESULT PAGE ─────────────────────────────────────────────────────
function AdaptiveResultPage({ result, setView }) {
  const ABILITY_COLORS = {
    Beginner:     "#ef4444",
    Elementary:   "#f59e0b",
    Intermediate: "#00d4ff",
    Advanced:     "#8b5cf6",
    Expert:       "#10b981",
  };
  const DIFF_COLORS = ["#ef4444","#f59e0b","#00d4ff","#8b5cf6","#10b981"];

  const label   = result.abilityLabel  || "Intermediate";
  const theta   = result.finalAbility  ?? 0;
  const color   = ABILITY_COLORS[label] || "#00d4ff";
  const fillPct = Math.round(((theta + 3) / 6) * 100);
  const avgResp = result.responseTimes?.length
    ? Math.round(result.responseTimes.reduce((a, b) => a + b, 0) / result.responseTimes.length / 1000)
    : null;
  const maxDiff = result.difficultyPath?.length ? Math.max(...result.difficultyPath) : 0;
  const hintsUsed = result.hintUsed?.filter(Boolean).length || 0;

  const ABILITY_EMOJI = { Beginner: "🌱", Elementary: "📖", Intermediate: "⚡", Advanced: "🔥", Expert: "🏆" };

  return (
    <div className="container" style={{ maxWidth: 720 }}>

      {/* Hero card */}
      <div className="adaptive-result-card mt-3">
        <div style={{ fontSize: "3rem", marginBottom: "0.5rem" }}>{ABILITY_EMOJI[label] || "⚡"}</div>
        <div className="adaptive-badge" style={{ margin: "0 auto 1rem", width: "fit-content" }}>⚡ Adaptive Exam Complete</div>
        <h2 style={{ fontFamily: "Syne", fontWeight: 800, fontSize: "1.75rem", color }}>
          {label}
        </h2>
        <p className="text-muted mb-3">{result.examTitle}</p>

        {/* θ meter */}
        <div style={{ maxWidth: 340, margin: "0 auto 1.5rem" }}>
          <div className="flex-between" style={{ marginBottom: 6, fontSize: "0.8rem" }}>
            <span style={{ color: "var(--text-muted)" }}>Beginner</span>
            <span style={{ color, fontWeight: 700 }}>θ = {theta.toFixed(2)}</span>
            <span style={{ color: "var(--text-muted)" }}>Expert</span>
          </div>
          <div className="theta-track" style={{ height: 12, borderRadius: 6 }}>
            <div className="theta-fill" style={{ width: `${fillPct}%`, background: `linear-gradient(90deg, ${color}66, ${color})`, borderRadius: 6 }} />
          </div>
          <div style={{ textAlign: "center", marginTop: 6, fontSize: "0.78rem", color: "var(--text-muted)" }}>
            Estimated ability level (Item Response Theory)
          </div>
        </div>

        {/* Stats grid */}
        <div className="grid-4 mb-2" style={{ gap: "0.75rem" }}>
          <div className="stat-card">
            <div className="stat-value text-accent">{result.correct}</div>
            <div className="stat-label">Correct</div>
          </div>
          <div className="stat-card">
            <div className="stat-value text-danger">{result.total - result.correct}</div>
            <div className="stat-label">Wrong</div>
          </div>
          <div className="stat-card">
            <div className="stat-value" style={{ color }}>{result.percentage}%</div>
            <div className="stat-label">Score</div>
          </div>
          <div className="stat-card">
            <div className="stat-value" style={{ color: DIFF_COLORS[maxDiff - 1] || "var(--text)" }}>
              {"★".repeat(maxDiff)}
            </div>
            <div className="stat-label">Peak Difficulty</div>
          </div>
        </div>

        <div className="grid-2 mb-3" style={{ gap: "0.75rem" }}>
          {avgResp !== null && (
            <div className="stat-card">
              <div className="stat-value" style={{ color: "var(--warning)" }}>{avgResp}s</div>
              <div className="stat-label">Avg Response Time</div>
            </div>
          )}
          <div className="stat-card">
            <div className="stat-value" style={{ color: "var(--text-dim)" }}>{hintsUsed}</div>
            <div className="stat-label">Hints Used</div>
          </div>
        </div>

        <div className="flex gap-2" style={{ justifyContent: "center" }}>
          <button className="btn btn-primary" onClick={() => setView("exams")}>Try Another →</button>
          <button className="btn btn-secondary" onClick={() => setView("results")}>All Results</button>
        </div>
      </div>

      {/* Difficulty journey chart */}
      {result.difficultyPath?.length > 0 && (
        <div className="card mt-3">
          <h3 style={{ fontFamily: "Syne", fontWeight: 700, marginBottom: "0.5rem" }}>📈 Difficulty Journey</h3>
          <p className="text-muted text-sm mb-3">How the exam adapted to your answers — taller bars = harder questions.</p>
          <div className="ability-timeline" style={{ height: 100 }}>
            {result.difficultyPath.map((d, i) => (
              <div key={i} className="ability-bar-item"
                data-label={["","Beginner","Easy","Medium","Hard","Expert"][d]}
                style={{ height: `${(d / 5) * 100}%`, background: DIFF_COLORS[d - 1] }}>
                <div style={{ position: "absolute", bottom: -18, left: "50%", transform: "translateX(-50%)", fontSize: "0.6rem", color: "var(--text-muted)" }}>{i + 1}</div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: "1.5rem", fontSize: "0.72rem", color: "var(--text-muted)" }}>
            {result.difficultyPath.map((_, i) => null).filter((_, i) => i === 0 || i === result.difficultyPath.length - 1 || i % 3 === 0)}
            <span>Q1</span><span>Q{result.difficultyPath.length}</span>
          </div>

          {/* Difficulty breakdown */}
          <div style={{ marginTop: "1.25rem", display: "flex", gap: 8, flexWrap: "wrap" }}>
            {[1,2,3,4,5].map(d => {
              const count = result.difficultyPath.filter(x => x === d).length;
              if (!count) return null;
              return (
                <span key={d} style={{ background: `${DIFF_COLORS[d-1]}18`, border: `1px solid ${DIFF_COLORS[d-1]}44`, color: DIFF_COLORS[d-1], padding: "3px 10px", borderRadius: 20, fontSize: "0.75rem", fontWeight: 600 }}>
                  {"★".repeat(d)} {["","Beginner","Easy","Medium","Hard","Expert"][d]}: {count}
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* Response time chart */}
      {result.responseTimes?.length > 0 && (
        <div className="card mt-3">
          <h3 style={{ fontFamily: "Syne", fontWeight: 700, marginBottom: "0.5rem" }}>⏱ Response Times</h3>
          <p className="text-muted text-sm mb-3">How long you spent on each question (seconds).</p>
          <div className="ability-timeline" style={{ height: 80, alignItems: "flex-end" }}>
            {result.responseTimes.map((ms, i) => {
              const secs = Math.round(ms / 1000);
              const maxSecs = Math.max(...result.responseTimes) / 1000;
              const heightPct = Math.max(8, (secs / maxSecs) * 100);
              return (
                <div key={i} style={{
                  flex: 1, height: `${heightPct}%`, borderRadius: "3px 3px 0 0",
                  background: secs < 5 ? "var(--accent3)" : secs < 15 ? "var(--accent)" : "var(--warning)",
                  minWidth: 8, position: "relative",
                }}>
                  <div style={{ position: "absolute", bottom: -18, left: "50%", transform: "translateX(-50%)", fontSize: "0.6rem", color: "var(--text-muted)" }}>{i+1}</div>
                </div>
              );
            })}
          </div>
          <div style={{ marginTop: "1.5rem", display: "flex", gap: 12, fontSize: "0.75rem" }}>
            <span style={{ color: "var(--accent3)" }}>■ Fast (&lt;5s)</span>
            <span style={{ color: "var(--accent)" }}>■ Normal (5–15s)</span>
            <span style={{ color: "var(--warning)" }}>■ Slow (&gt;15s)</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── RESULTS PAGE ─────────────────────────────────────────────────────────────
function ResultsPage({ results, user, exams }) {
  const myResults = user.role === "admin" ? results : results.filter(r => r.userId === user.id);
  const flagged   = user.role === "admin" ? myResults.filter(r => r.cheatFlags?.flagged) : [];

  return (
    <div className="container">
      <div className="page-title">📈 {user.role === "admin" ? "All Results" : "My Results"}</div>
      <div className="page-subtitle">{myResults.length} total submissions{flagged.length > 0 ? ` · ⚠️ ${flagged.length} flagged` : ""}</div>

      {/* Admin cheat summary banner */}
      {flagged.length > 0 && (
        <div style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.25)", borderRadius: 10, padding: "12px 16px", marginBottom: "1rem", fontSize: "0.85rem" }}>
          <strong style={{ color: "var(--danger)" }}>⚠️ {flagged.length} submission{flagged.length > 1 ? "s" : ""} flagged by cheat detector.</strong>
          {" "}Review the Integrity column below. High severity results should be investigated.
        </div>
      )}

      {myResults.length === 0 ? (
        <div className="empty"><div className="empty-icon">📊</div><div>No results yet</div></div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                {user.role === "admin" && <th>Student</th>}
                <th>Exam</th>
                <th>Score</th>
                <th>Correct</th>
                <th>Grade</th>
                <th>Status</th>
                {user.role === "student" && <th>XP</th>}
                {user.role === "admin"   && <th>Integrity</th>}
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {[...myResults].reverse().map(r => {
                const pct   = r.percentage;
                const grade = pct >= 90 ? "A+" : pct >= 80 ? "A" : pct >= 70 ? "B" : pct >= 60 ? "C" : "F";
                const cf    = r.cheatFlags || {};
                const sev   = cf.severity || "none";
                return (
                  <tr key={r.id}>
                    {user.role === "admin" && <td>{r.userName}</td>}
                    <td style={{ fontWeight: 500 }}>
                      {r.adaptive && <span className="adaptive-badge" style={{ fontSize: "0.65rem", padding: "2px 6px", marginRight: 6 }}>⚡</span>}
                      {r.examTitle}
                    </td>
                    <td><span className={pct >= 60 ? "text-success" : "text-danger"} style={{ fontFamily: "Syne", fontWeight: 700 }}>{pct}%</span></td>
                    <td className="text-muted">{r.correct}/{r.total}</td>
                    <td>
                      {r.adaptive
                        ? <span className="badge" style={{ background: "rgba(124,58,237,0.15)", color: "#a78bfa" }}>{r.abilityLabel || "Done"}</span>
                        : <span className={`badge ${pct >= 60 ? "badge-green" : "badge-red"}`}>{grade}</span>}
                    </td>
                    <td><span className={`badge ${pct >= 60 ? "badge-green" : "badge-red"}`}>{pct >= 60 ? "Pass" : "Fail"}</span></td>
                    {/* XP earned + multiplier for student view */}
                    {user.role === "student" && (
                      <td>
                        {r.xpEarned > 0 && (
                          <span style={{ color: "#c4b5fd", fontSize: "0.82rem", fontWeight: 600 }}>
                            +{r.xpEarned}
                            {r.xpMultiplier > 1 && <span style={{ color: "var(--warning)", marginLeft: 3 }}>×{r.xpMultiplier}</span>}
                          </span>
                        )}
                      </td>
                    )}
                    {/* Integrity / cheat flag for admin view */}
                    {user.role === "admin" && (
                      <td>
                        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                          <span className={`cheat-flag-badge cheat-flag-${sev}`}>
                            {sev === "none" ? "✓ Clean" : sev === "low" ? "⚠ Low" : sev === "medium" ? "🔶 Medium" : "🚨 High"}
                          </span>
                          {cf.tabSwitches > 0     && <span style={{ fontSize: "0.68rem", color: "var(--text-muted)" }}>Tab: {cf.tabSwitches}×</span>}
                          {cf.copyPasteCount > 0  && <span style={{ fontSize: "0.68rem", color: "var(--text-muted)" }}>Copy: {cf.copyPasteCount}×</span>}
                          {cf.tooFastAnswers > 0  && <span style={{ fontSize: "0.68rem", color: "var(--text-muted)" }}>Fast: {cf.tooFastAnswers}q</span>}
                        </div>
                      </td>
                    )}
                    <td className="text-muted text-sm">{r.completedAt}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── USERS PAGE ───────────────────────────────────────────────────────────────
function UsersPage({ users, setUsers, showToast }) {
  const [showModal, setShowModal] = useState(false);

  const handleDelete = async (id) => {
    try {
      await apiDeleteUser(id);
      setUsers(prev => prev.filter(u => u.id !== id && u._id !== id));
      showToast("User deleted");
    } catch (err) { showToast("Delete failed: " + err.message, "error"); }
  };

  const handleAddUser = async (u) => {
    try {
      const created = await apiAddUser(u);
      setUsers(prev => [...prev, { ...created.user, id: created.user._id }]);
      setShowModal(false);
      showToast("User added!");
    } catch (err) { showToast("Add failed: " + err.message, "error"); }
  };

  return (
    <div className="container">
      <div className="flex-between mb-3">
        <div>
          <div className="page-title">👥 User Management</div>
          <div className="page-subtitle">{users.length} registered users</div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Add User</button>
      </div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Role</th><th>Actions</th></tr></thead>
          <tbody>
            {users.map((u, i) => (
              <tr key={u.id}>
                <td className="text-muted">{i + 1}</td>
                <td style={{ fontWeight: 500 }}>{u.name}</td>
                <td className="text-muted">{u.email}</td>
                <td><span className={`badge ${u.role === "admin" ? "badge-purple" : "badge-blue"}`}>{u.role}</span></td>
                <td><button className="btn btn-danger btn-sm" onClick={() => handleDelete(u.id || u._id)} disabled={u.role === "admin"}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showModal && <UserModal onClose={() => setShowModal(false)} onSave={handleAddUser} />}
    </div>
  );
}

function UserModal({ onClose, onSave }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("student");
  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-title">➕ Add New User</div>
        <div className="form-group"><label className="form-label">Full Name</label><input className="form-input" value={name} onChange={e => setName(e.target.value)} placeholder="John Doe" /></div>
        <div className="form-group"><label className="form-label">Email</label><input className="form-input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="john@example.com" /></div>
        <div className="form-group"><label className="form-label">Password</label><input className="form-input" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" /></div>
        <div className="form-group"><label className="form-label">Role</label>
          <select className="form-input form-select" value={role} onChange={e => setRole(e.target.value)}>
            <option value="student">Student</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <div className="flex gap-2">
          <button className="btn btn-primary" disabled={!name || !email || !password} onClick={() => onSave({ name, email, password, role })}>Add User</button>
          <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}

// ─── CERTIFICATES PAGE ────────────────────────────────────────────────────────
function CertificatesPage({ results, user }) {
  const [selected, setSelected] = useState(null);
  const myPassed = results.filter(r => r.userId === user.id && r.percentage >= 60);

  if (selected) return <CertificateView result={selected} user={user} onBack={() => setSelected(null)} />;

  return (
    <div className="container">
      <div className="page-title">🎓 My Certificates</div>
      <div className="page-subtitle">{myPassed.length} certificate{myPassed.length !== 1 ? "s" : ""} earned (score ≥ 60%)</div>

      {myPassed.length === 0 ? (
        <div className="empty">
          <div className="empty-icon">🎓</div>
          <div style={{ marginBottom: "0.5rem" }}>No certificates yet</div>
          <div className="text-muted text-sm">Complete an exam with ≥ 60% to earn a certificate</div>
        </div>
      ) : (
        <div className="grid-2">
          {[...myPassed].reverse().map(r => {
            const grade = r.percentage >= 90 ? "A+" : r.percentage >= 80 ? "A" : r.percentage >= 70 ? "B" : "C";
            return (
              <div key={r.id} className="cert-card" onClick={() => setSelected(r)}>
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "0.75rem" }}>
                  <div>
                    <div className="cert-card-title">{r.examTitle}</div>
                    <div className="text-muted text-sm">📅 {r.completedAt}</div>
                  </div>
                  <div style={{ textAlign: "center" }}>
                    <div style={{ fontFamily: "Syne", fontWeight: 800, fontSize: "1.5rem", color: "var(--accent3)" }}>{r.percentage}%</div>
                    <span className="badge badge-green">{grade}</span>
                  </div>
                </div>
                <div className="flex gap-2" style={{ marginBottom: "0.75rem" }}>
                  <span className="badge badge-blue">✅ {r.correct}/{r.total} Correct</span>
                  <span className="badge badge-green">Pass</span>
                </div>
                <button className="btn btn-primary btn-sm">🎓 View Certificate →</button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── CERTIFICATE VIEW ─────────────────────────────────────────────────────────
function CertificateView({ result, user, onBack }) {
  const certRef = useRef(null);
  const [downloading, setDownloading] = useState(false);

  const grade = result.percentage >= 90 ? "A+" : result.percentage >= 80 ? "A" : result.percentage >= 70 ? "B" : "C";
  const certId = `EP-${result.examId}-${result.userId}-${String(result.id).slice(-4)}`;
  const level = result.percentage >= 90 ? "Excellence" : result.percentage >= 80 ? "Merit" : result.percentage >= 70 ? "Distinction" : "Completion";
  const fileName = `Certificate_${user.name.replace(/\s+/g, "_")}_${result.examTitle.replace(/\s+/g, "_")}.png`;

  const handleDownload = async () => {
    if (!certRef.current || downloading) return;
    setDownloading(true);
    try {
      // Dynamically load html2canvas from CDN
      if (!window.html2canvas) {
        await new Promise((resolve, reject) => {
          const s = document.createElement("script");
          s.src = "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js";
          s.onload = resolve;
          s.onerror = reject;
          document.head.appendChild(s);
        });
      }
      const canvas = await window.html2canvas(certRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: "#0a0e1a",
        logging: false,
      });
      const link = document.createElement("a");
      link.download = fileName;
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch (e) {
      alert("Download failed. Please try again.");
    } finally {
      setDownloading(false);
    }
  };

  // Inline styles so html2canvas can capture them accurately (no CSS class dependency issues)
  const S = {
    wrapper: { background: "linear-gradient(135deg,#0a0e1a 0%,#0f1f3d 100%)", border: "2px solid #00d4ff", borderRadius: 20, padding: "3rem", textAlign: "center", position: "relative", overflow: "hidden", maxWidth: 700, margin: "0 auto", fontFamily: "'DM Sans',sans-serif" },
    innerBorder: { position: "absolute", inset: 8, border: "1px solid rgba(0,212,255,0.2)", borderRadius: 14, pointerEvents: "none" },
    corner: (pos) => { const base = { position: "absolute", width: 60, height: 60, borderColor: "#00d4ff", borderStyle: "solid", opacity: 0.5 }; const m = { tl: { top:16,left:16,borderWidth:"2px 0 0 2px",borderRadius:"4px 0 0 0" }, tr: { top:16,right:16,borderWidth:"2px 2px 0 0",borderRadius:"0 4px 0 0" }, bl: { bottom:16,left:16,borderWidth:"0 0 2px 2px",borderRadius:"0 0 0 4px" }, br: { bottom:16,right:16,borderWidth:"0 2px 2px 0",borderRadius:"0 0 4px 0" } }; return { ...base, ...m[pos] }; },
    logo: { fontFamily: "'Syne',sans-serif", fontSize: "1.1rem", fontWeight: 800, color: "#00d4ff", letterSpacing: 2, textTransform: "uppercase", marginBottom: "0.5rem" },
    subtitle: { fontSize: "0.75rem", color: "#64748b", letterSpacing: 4, textTransform: "uppercase", marginBottom: "1.5rem" },
    headline: { fontFamily: "'Syne',sans-serif", fontSize: "0.8rem", color: "#94a3b8", letterSpacing: 2, textTransform: "uppercase", marginBottom: "0.5rem" },
    name: { fontFamily: "'Syne',sans-serif", fontSize: "2.2rem", fontWeight: 800, color: "#00d4ff", marginBottom: "1rem", textShadow: "0 0 30px rgba(0,212,255,0.3)" },
    divider: { width: 80, height: 2, background: "linear-gradient(90deg,transparent,#00d4ff,transparent)", margin: "1.5rem auto" },
    body: { color: "#94a3b8", fontSize: "0.9rem", lineHeight: 1.8, marginBottom: "1.5rem" },
    examName: { fontFamily: "'Syne',sans-serif", fontSize: "1.2rem", fontWeight: 700, color: "#e2e8f0" },
    meta: { display: "flex", justifyContent: "space-around", marginTop: "1.5rem", paddingTop: "1.5rem", borderTop: "1px solid #1e2d45" },
    metaVal: { fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: "1.1rem", color: "#10b981" },
    metaLbl: { fontSize: "0.7rem", color: "#64748b", textTransform: "uppercase", letterSpacing: 1, marginTop: 2 },
    seal: { width: 70, height: 70, borderRadius: "50%", border: "2px solid #00d4ff", display: "flex", alignItems: "center", justifyContent: "center", margin: "1.5rem auto 0", fontSize: "1.8rem", background: "rgba(0,212,255,0.05)" },
    certId: { marginTop: "1rem", fontSize: "0.7rem", color: "#64748b", letterSpacing: 1 },
    sigRow: { display: "flex", justifyContent: "space-around", marginTop: "2rem", paddingTop: "1rem", borderTop: "1px solid #1e2d45" },
    sigLine: { width: 100, height: 1, background: "#1e2d45", margin: "0 auto 6px" },
    sigLabel: { fontSize: "0.7rem", color: "#64748b", letterSpacing: 0.5 },
  };

  return (
    <div className="container" style={{ maxWidth: 780 }}>
      {/* Toolbar — NOT captured by html2canvas (outside certRef) */}
      <div className="flex-between mb-3">
        <button className="btn btn-secondary" onClick={onBack}>← Back to Certificates</button>
        <button className="btn btn-primary" onClick={handleDownload} disabled={downloading}>
          {downloading ? "⏳ Generating..." : "⬇️ Download Certificate"}
        </button>
      </div>

      {/* Certificate element — only this div is captured */}
      <div ref={certRef} style={S.wrapper}>
        <div style={S.innerBorder} />
        <div style={S.corner("tl")} />
        <div style={S.corner("tr")} />
        <div style={S.corner("bl")} />
        <div style={S.corner("br")} />

        <div style={{ marginBottom: "0.25rem" }}>
          <div style={{ fontSize: "2rem", marginBottom: "0.5rem" }}>⚡</div>
          <div style={S.logo}>ExamPortal</div>
          <div style={S.subtitle}>Department of Information Technology</div>
        </div>

        <div style={S.divider} />

        <div style={S.headline}>Certificate of {level}</div>
        <div style={{ fontSize: "0.8rem", color: "#64748b", marginBottom: "0.75rem" }}>This is to certify that</div>
        <div style={S.name}>{user.name}</div>
        {user.rollNo && <div style={{ color: "#94a3b8", fontSize: "0.85rem", marginBottom: "0.5rem" }}>Roll No: {user.rollNo}</div>}
        {user.dept && <div style={{ color: "#94a3b8", fontSize: "0.85rem", marginBottom: "1rem" }}>{user.dept}</div>}

        <div style={S.body}>
          has successfully completed the online examination on<br />
          <span style={S.examName}>"{result.examTitle}"</span><br />
          conducted through the MERN Stack Online Examination Platform
        </div>

        <div style={S.divider} />

        <div style={S.meta}>
          {[["Score", `${result.percentage}%`], ["Correct", `${result.correct}/${result.total}`], ["Grade", grade], ["Date", result.completedAt?.split(",")[0]]].map(([lbl, val]) => (
            <div key={lbl} style={{ textAlign: "center" }}>
              <div style={S.metaVal}>{val}</div>
              <div style={S.metaLbl}>{lbl}</div>
            </div>
          ))}
        </div>

        <div style={{ ...S.seal, display: "flex" }}>🏆</div>
        <div style={S.certId}>CERTIFICATE ID: {certId}</div>

        <div style={S.sigRow}>
          {["Course Coordinator", "Head of Department", "Principal"].map(r => (
            <div key={r} style={{ textAlign: "center" }}>
              <div style={S.sigLine} />
              <div style={S.sigLabel}>{r}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ textAlign: "center", marginTop: "1rem", fontSize: "0.8rem", color: "var(--text-muted)" }}>
        📁 Downloads as a <strong style={{ color: "var(--text-dim)" }}>PNG image</strong> — only the certificate, nothing else
      </div>
    </div>
  );
}

// ─── TIME-LOCK OVERLAY ────────────────────────────────────────────────────────
function TimeLockOverlay({ msg, onClose }) {
  const [timeNow, setTimeNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setTimeNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const pad = n => String(n).padStart(2, "0");
  const cur = `${pad(timeNow.getHours())}:${pad(timeNow.getMinutes())}:${pad(timeNow.getSeconds())}`;

  // Compute time until window opens
  const [tH, tM] = (msg.availableFrom || "00:00").split(":").map(Number);
  const targetMins = tH * 60 + tM;
  const nowMins    = timeNow.getHours() * 60 + timeNow.getMinutes();
  let diffMins     = targetMins - nowMins;
  if (diffMins <= 0) diffMins += 24 * 60; // wraps to next day
  const hrs  = Math.floor(diffMins / 60);
  const mins = diffMins % 60;
  const countdown = hrs > 0 ? `${hrs}h ${mins}m` : `${mins}m`;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="time-lock-card" style={{ maxWidth: 420, width: "90%", margin: "0 auto" }} onClick={e => e.stopPropagation()}>
        <div style={{ fontSize: "3rem", marginBottom: "0.5rem" }}>🔒</div>
        <h2 style={{ fontFamily: "Syne", fontWeight: 800, fontSize: "1.4rem", marginBottom: "0.5rem" }}>
          Exam Locked
        </h2>
        <p style={{ color: "var(--text-muted)", marginBottom: "1.25rem", fontSize: "0.9rem" }}>
          <strong style={{ color: "var(--text)" }}>{msg.examTitle}</strong> is only accessible during a specific time window.
        </p>

        <div style={{ display: "flex", justifyContent: "center", gap: "1.5rem", marginBottom: "1.25rem", flexWrap: "wrap" }}>
          <div style={{ textAlign: "center" }}>
            <div className="time-window-pill">🟢 Opens at {msg.availableFrom || "00:00"}</div>
          </div>
          <div style={{ textAlign: "center" }}>
            <div className="time-window-pill" style={{ background: "rgba(239,68,68,0.1)", borderColor: "rgba(239,68,68,0.25)", color: "var(--danger)" }}>
              🔴 Closes at {msg.availableTo || "23:59"}
            </div>
          </div>
        </div>

        <div style={{ color: "var(--text-muted)", fontSize: "0.85rem", marginBottom: "0.5rem" }}>Current time</div>
        <div className="time-lock-countdown">{cur}</div>

        <div style={{ color: "var(--text-muted)", fontSize: "0.82rem", marginTop: "0.5rem" }}>
          ⏳ Window opens in approximately <strong style={{ color: "var(--accent)" }}>{countdown}</strong>
        </div>

        <button className="btn btn-secondary" style={{ marginTop: "1.5rem" }} onClick={onClose}>Go Back</button>
      </div>
    </div>
  );
}

// ─── XP CELEBRATION POPUP ─────────────────────────────────────────────────────
function XpCelebrationPopup({ popup, onClose }) {
  const { xpEarned, xpBase, xpMultiplier, pointsEarned, newBadges, newLevel, streak, percentage } = popup;
  useEffect(() => {
    const t = setTimeout(onClose, 6000);
    return () => clearTimeout(t);
  }, [onClose]);

  return (
    <div className="xp-popup-overlay" onClick={onClose}>
      <div className="xp-popup" onClick={e => e.stopPropagation()}>
        <div className="xp-popup-ring">
          {percentage === 100 ? "💯" : percentage >= 80 ? "🔥" : percentage >= 60 ? "⭐" : "📚"}
        </div>

        <h2 style={{ fontFamily: "Syne", fontWeight: 800, marginBottom: "0.25rem" }}>
          {percentage === 100 ? "Perfect Score!" : percentage >= 60 ? "Well Done!" : "Keep Going!"}
        </h2>
        <p className="text-muted mb-3" style={{ fontSize: "0.9rem" }}>Exam complete — here's what you earned</p>

        {/* XP breakdown with multiplier */}
        <div style={{ marginBottom: "1rem" }}>
          {xpMultiplier > 1 ? (
            <div style={{ marginBottom: 6 }}>
              <div style={{ fontSize: "0.82rem", color: "var(--text-muted)" }}>
                Base: {xpBase} XP
                <span style={{ margin: "0 6px", color: "var(--warning)" }}>× {xpMultiplier}</span>
                streak multiplier
              </div>
              <div className={`multiplier-badge ${xpMultiplier >= 2 ? "x2" : ""}`} style={{ margin: "4px auto", width: "fit-content" }}>
                🔥 {streak}-day streak = {xpMultiplier}× XP!
              </div>
            </div>
          ) : null}
          <div className="xp-number">+{xpEarned} XP</div>
          <div style={{ fontSize: "0.8rem", color: "var(--text-muted)", marginTop: 2 }}>
            +{pointsEarned} achievement points
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginBottom: "1rem" }}>
          <div className="level-badge" style={{ width: 44, height: 44, fontSize: "1rem" }}>{newLevel}</div>
          <span style={{ fontFamily: "Syne", fontWeight: 700, fontSize: "1rem" }}>Level {newLevel}</span>
        </div>

        {newBadges.length > 0 && (
          <div style={{ marginBottom: "1rem" }}>
            <div style={{ fontSize: "0.75rem", color: "var(--text-muted)", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.5px" }}>
              🎉 New Badges Unlocked!
            </div>
            <div className="new-badge-list">
              {newBadges.map(b => {
                const meta = ALL_BADGES_META[b];
                return meta ? (
                  <div key={b} className="badge-chip earned" title={meta.desc}>
                    {meta.icon} {meta.name}
                  </div>
                ) : null;
              })}
            </div>
          </div>
        )}

        <button className="btn btn-primary" onClick={onClose} style={{ marginTop: "0.5rem" }}>
          Awesome! →
        </button>
        <div style={{ fontSize: "0.72rem", color: "var(--text-muted)", marginTop: 8 }}>
          Auto-closes in 6 seconds
        </div>
      </div>
    </div>
  );
}

// ─── GAMIFICATION PAGE ────────────────────────────────────────────────────────
function GamificationPage({ gamification, results, user }) {
  const gam = gamification || {};
  const level = gam.level || 1;
  const xp = gam.xp || 0;
  const nextXp = LEVEL_XP[Math.min(level, 9)] || 7500;
  const prevXp = LEVEL_XP[Math.max(level - 1, 0)] || 0;
  const xpPct = Math.min(100, Math.round(((xp - prevXp) / (nextXp - prevXp)) * 100));
  const earnedBadges = new Set(gam.badges || []);
  const [downloading, setDownloading] = useState(null); // badge id being downloaded

  // ── Download a single badge as a PNG image ──────────────────────────────────
  const downloadBadge = async (badgeId) => {
    const meta = ALL_BADGES_META[badgeId];
    if (!meta) return;
    setDownloading(badgeId);
    try {
      // Build a canvas badge card
      const canvas = document.createElement("canvas");
      canvas.width  = 600;
      canvas.height = 400;
      const ctx = canvas.getContext("2d");

      // Background gradient
      const bg = ctx.createLinearGradient(0, 0, 600, 400);
      bg.addColorStop(0, "#0a0e1a");
      bg.addColorStop(1, "#1a1040");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, 600, 400);

      // Glowing border ring
      ctx.beginPath();
      ctx.arc(300, 155, 85, 0, Math.PI * 2);
      ctx.strokeStyle = "rgba(124,58,237,0.6)";
      ctx.lineWidth = 3;
      ctx.stroke();

      // Outer glow circle
      const glow = ctx.createRadialGradient(300, 155, 50, 300, 155, 100);
      glow.addColorStop(0, "rgba(124,58,237,0.25)");
      glow.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(300, 155, 100, 0, Math.PI * 2);
      ctx.fill();

      // Badge icon (emoji rendered via fillText)
      ctx.font = "72px serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(meta.icon, 300, 155);

      // Badge name
      ctx.font = "bold 28px 'Arial', sans-serif";
      ctx.fillStyle = "#c4b5fd";
      ctx.textAlign = "center";
      ctx.textBaseline = "alphabetic";
      ctx.fillText(meta.name, 300, 268);

      // Badge description
      ctx.font = "16px 'Arial', sans-serif";
      ctx.fillStyle = "#64748b";
      ctx.fillText(meta.desc, 300, 300);

      // Divider line
      ctx.beginPath();
      ctx.moveTo(160, 322); ctx.lineTo(440, 322);
      const divGrad = ctx.createLinearGradient(160, 0, 440, 0);
      divGrad.addColorStop(0, "transparent");
      divGrad.addColorStop(0.5, "rgba(0,212,255,0.5)");
      divGrad.addColorStop(1, "transparent");
      ctx.strokeStyle = divGrad;
      ctx.lineWidth = 1;
      ctx.stroke();

      // Student name
      ctx.font = "bold 18px 'Arial', sans-serif";
      ctx.fillStyle = "#00d4ff";
      ctx.fillText(`Awarded to: ${user?.name || "Student"}`, 300, 348);

      // Watermark
      ctx.font = "13px 'Arial', sans-serif";
      ctx.fillStyle = "rgba(100,116,139,0.5)";
      ctx.fillText("⚡ ExamPortal", 300, 378);

      // Download
      const link = document.createElement("a");
      link.download = `badge_${meta.name.replace(/\s+/g,"_")}_${user?.name?.replace(/\s+/g,"_") || "student"}.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch (err) {
      alert("Download failed. Please try again.");
    } finally {
      setDownloading(null);
    }
  };

  // ── Download ALL earned badges as a single badge sheet ──────────────────────
  const downloadAllBadges = async () => {
    const earned = Object.entries(ALL_BADGES_META).filter(([id]) => earnedBadges.has(id));
    if (earned.length === 0) return;
    setDownloading("all");
    try {
      const cols = Math.min(4, earned.length);
      const rows = Math.ceil(earned.length / cols);
      const CW = 160, CH = 180, PAD = 20;
      const canvas = document.createElement("canvas");
      canvas.width  = cols * CW + PAD * 2;
      canvas.height = rows * CH + PAD * 2 + 60;
      const ctx = canvas.getContext("2d");

      // Background
      ctx.fillStyle = "#0a0e1a";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Title
      ctx.font = "bold 22px Arial";
      ctx.fillStyle = "#c4b5fd";
      ctx.textAlign = "center";
      ctx.fillText(`${user?.name || "Student"}'s Badges`, canvas.width / 2, 36);

      // Draw each badge
      earned.forEach(([id, meta], i) => {
        const col = i % cols;
        const row = Math.floor(i / cols);
        const x = PAD + col * CW + CW / 2;
        const y = 60 + PAD + row * CH;

        // Badge background circle
        const cGlow = ctx.createRadialGradient(x, y + 36, 10, x, y + 36, 46);
        cGlow.addColorStop(0, "rgba(124,58,237,0.2)");
        cGlow.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = cGlow;
        ctx.beginPath(); ctx.arc(x, y + 36, 46, 0, Math.PI * 2); ctx.fill();

        ctx.beginPath(); ctx.arc(x, y + 36, 40, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(124,58,237,0.4)"; ctx.lineWidth = 1.5; ctx.stroke();

        // Icon
        ctx.font = "36px serif";
        ctx.textAlign = "center"; ctx.textBaseline = "middle";
        ctx.fillText(meta.icon, x, y + 36);

        // Name
        ctx.font = "bold 12px Arial";
        ctx.fillStyle = "#c4b5fd";
        ctx.textBaseline = "alphabetic";
        ctx.fillText(meta.name, x, y + 92);

        // Desc (truncate)
        ctx.font = "10px Arial";
        ctx.fillStyle = "#475569";
        const desc = meta.desc.length > 28 ? meta.desc.slice(0, 25) + "…" : meta.desc;
        ctx.fillText(desc, x, y + 110);
      });

      // Footer watermark
      ctx.font = "12px Arial";
      ctx.fillStyle = "rgba(100,116,139,0.4)";
      ctx.fillText("⚡ ExamPortal", canvas.width / 2, canvas.height - 8);

      const link = document.createElement("a");
      link.download = `all_badges_${user?.name?.replace(/\s+/g,"_") || "student"}.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch (err) {
      alert("Download failed. Please try again.");
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div className="container" style={{ maxWidth: 860 }}>
      <div className="page-title">🎮 Achievements</div>
      <div className="page-subtitle">Track your progress, badges, and level</div>

      {/* ── Level + XP card ── */}
      <div className="card mb-3" style={{ background: "linear-gradient(135deg, rgba(124,58,237,0.15), rgba(0,212,255,0.08))", border: "1px solid rgba(124,58,237,0.35)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "2rem", flexWrap: "wrap" }}>
          <div style={{ textAlign: "center" }}>
            <div className="level-badge" style={{ width: 72, height: 72, fontSize: "1.8rem", margin: "0 auto 6px" }}>{level}</div>
            <div style={{ fontFamily: "Syne", fontWeight: 700, color: "#c4b5fd" }}>
              {level < 10 ? `Level ${level}` : "MAX LEVEL 👑"}
            </div>
          </div>
          <div style={{ flex: 1, minWidth: 200 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <span style={{ fontFamily: "Syne", fontWeight: 700, color: "#c4b5fd" }}>⭐ {xp.toLocaleString()} XP</span>
              {level < 10 && (
                <span style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>
                  {(xp - prevXp).toLocaleString()} / {(nextXp - prevXp).toLocaleString()} to Level {level + 1}
                </span>
              )}
            </div>
            <div className="xp-bar-track" style={{ height: 14, borderRadius: 7 }}>
              <div className="xp-bar-fill" style={{ width: `${xpPct}%`, borderRadius: 7 }} />
            </div>
            <div style={{ marginTop: 8, display: "flex", gap: "1.5rem", flexWrap: "wrap" }}>
              <span style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>
                🏅 <strong style={{ color: "var(--accent)" }}>{(gam.totalPoints||0).toLocaleString()}</strong> achievement points
              </span>
              <span className="streak-pill">🔥 {gam.streak || 0} day streak</span>
            </div>
          </div>
        </div>
      </div>

      {/* ── Stats row ── */}
      <div className="grid-4 mb-3">
        {[
          { icon:"📝", value: results.length,                               label:"Total Attempts",  color:"var(--accent)" },
          { icon:"✅", value: results.filter(r=>r.percentage>=60).length,   label:"Exams Passed",    color:"var(--accent3)" },
          { icon:"🏅", value: earnedBadges.size,                            label:"Badges Earned",   color:"#c4b5fd" },
          { icon:"💯", value: results.filter(r=>r.percentage===100).length, label:"Perfect Scores",  color:"var(--warning)" },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div className="stat-icon">{s.icon}</div>
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      {/* ── Badges grid with download buttons ── */}
      <div className="card mb-3">
        <div className="flex-between" style={{ marginBottom: "1.25rem" }}>
          <h3 style={{ fontFamily: "Syne", fontWeight: 700 }}>
            🏅 Badges ({earnedBadges.size}/{Object.keys(ALL_BADGES_META).length})
          </h3>
          {earnedBadges.size > 0 && (
            <button
              className="badge-download-btn"
              onClick={downloadAllBadges}
              disabled={downloading === "all"}
              title="Download all earned badges as one image"
            >
              {downloading === "all" ? "⏳ Generating…" : "⬇ Download All Badges"}
            </button>
          )}
        </div>
        <div className="badge-grid">
          {Object.entries(ALL_BADGES_META).map(([id, meta]) => {
            const has = earnedBadges.has(id);
            return (
              <div key={id} style={{ position: "relative" }}>
                <div className={`badge-chip ${has ? "earned" : "unearned"}`} title={meta.desc}
                  style={{ flexDirection: "column", alignItems: "flex-start", padding: "10px 14px", gap: 4, minWidth: 160 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, width: "100%" }}>
                    <span style={{ fontSize: "1.4rem" }}>{meta.icon}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, lineHeight: 1.2 }}>{meta.name}</div>
                      <div style={{ fontSize: "0.68rem", opacity: 0.75, lineHeight: 1.3 }}>{meta.desc}</div>
                    </div>
                    {has && <span style={{ color: "var(--accent3)", fontSize: "0.9rem" }}>✓</span>}
                  </div>
                  {has && (
                    <button
                      className="badge-download-btn"
                      style={{ marginTop: 6, fontSize: "0.68rem", padding: "2px 8px", alignSelf: "flex-end" }}
                      onClick={e => { e.stopPropagation(); downloadBadge(id); }}
                      disabled={downloading === id}
                    >
                      {downloading === id ? "⏳" : "⬇ Download"}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Achievement history ── */}
      {gam.achievements?.length > 0 && (
        <div className="card">
          <h3 style={{ fontFamily: "Syne", fontWeight: 700, marginBottom: "1rem" }}>🏆 Achievement History</h3>
          {[...gam.achievements].reverse().map((a, i) => (
            <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start", marginBottom: 14, paddingBottom: 14, borderBottom: "1px solid var(--border)" }}>
              <span style={{ fontSize: "1.5rem", minWidth: 32 }}>{a.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, marginBottom: 2 }}>{a.name}</div>
                <div style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>{a.desc}</div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
                <div style={{ fontSize: "0.72rem", color: "var(--text-muted)", whiteSpace: "nowrap" }}>{a.earnedAt}</div>
                <button
                  className="badge-download-btn"
                  style={{ fontSize: "0.65rem", padding: "1px 7px" }}
                  onClick={() => downloadBadge(a.id)}
                  disabled={downloading === a.id}
                >
                  {downloading === a.id ? "⏳" : "⬇ Download"}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {(!gam.achievements || gam.achievements.length === 0) && (
        <div className="card text-center" style={{ padding: "3rem" }}>
          <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>🎯</div>
          <div style={{ fontFamily: "Syne", fontWeight: 700, marginBottom: "0.5rem" }}>No achievements yet</div>
          <div className="text-muted text-sm">Complete exams to earn badges and level up!</div>
        </div>
      )}
    </div>
  );
}

// ─── POINTS PAGE ──────────────────────────────────────────────────────────────
function PointsPage({ gamification, results, user }) {
  const gam = gamification || {};
  const totalPoints  = gam.totalPoints || 0;
  const xp           = gam.xp         || 0;
  const level        = gam.level       || 1;
  const streak       = gam.streak      || 0;

  // Only student's own results with points data
  const myResults = results.filter(r => r.pointsEarned > 0);
  const sortedRecent = [...myResults].reverse().slice(0, 20);

  // Total XP breakdown
  const totalXpEarned = myResults.reduce((s, r) => s + (r.xpEarned || 0), 0);
  const totalBaseXp   = myResults.reduce((s, r) => s + (r.xpBase   || r.xpEarned || 0), 0);
  const bonusXp       = totalXpEarned - totalBaseXp;
  const highestSingle = myResults.length ? Math.max(...myResults.map(r => r.pointsEarned || 0)) : 0;
  const avgPoints     = myResults.length ? Math.round(totalPoints / myResults.length) : 0;

  // Bar chart data — last 10 results
  const chartData = sortedRecent.slice(0, 10).reverse();
  const maxPts    = chartData.length ? Math.max(...chartData.map(r => r.pointsEarned || 0), 1) : 1;

  // Multiplier breakdown by streak tier
  const multiplierTiers = [
    { min: 1,  max: 2,  mult: "1.0×", color: "var(--text-muted)" },
    { min: 3,  max: 6,  mult: "1.25×", color: "var(--accent3)" },
    { min: 7,  max: 13, mult: "1.5×",  color: "var(--accent)" },
    { min: 14, max: 29, mult: "1.75×", color: "#8b5cf6" },
    { min: 30, max: "∞",mult: "2.0×",  color: "var(--warning)" },
  ];
  const currentMult = streak >= 30 ? 2.0 : streak >= 14 ? 1.75 : streak >= 7 ? 1.5 : streak >= 3 ? 1.25 : 1.0;

  return (
    <div className="container" style={{ maxWidth: 820 }}>
      <div className="page-title">💰 My Points</div>
      <div className="page-subtitle">Your achievement points, XP, and earning history</div>

      {/* ── Hero: total points ── */}
      <div className="points-hero mb-3">
        <div style={{ display: "flex", alignItems: "center", gap: "2.5rem", flexWrap: "wrap" }}>
          <div>
            <div style={{ fontSize: "0.75rem", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 4 }}>
              Total Achievement Points
            </div>
            <div className="points-big">{totalPoints.toLocaleString()}</div>
            <div style={{ fontSize: "0.8rem", color: "var(--text-muted)", marginTop: 4 }}>
              from {myResults.length} exam{myResults.length !== 1 ? "s" : ""}
            </div>
          </div>

          <div style={{ flex: 1, minWidth: 180 }}>
            {[
              { label: "Total XP Earned",    value: `${xp.toLocaleString()} XP`,           color: "#c4b5fd" },
              { label: "Bonus XP (streak)",  value: `+${bonusXp.toLocaleString()} XP`,      color: "var(--warning)" },
              { label: "Current Level",      value: `Level ${level}`,                        color: "var(--accent)" },
              { label: "Best Single Exam",   value: `${highestSingle.toLocaleString()} pts`, color: "var(--accent3)" },
              { label: "Avg per Exam",       value: `${avgPoints.toLocaleString()} pts`,     color: "var(--text-dim)" },
            ].map(row => (
              <div key={row.label} className="flex-between" style={{ marginBottom: 6 }}>
                <span style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>{row.label}</span>
                <span style={{ fontSize: "0.85rem", fontWeight: 700, color: row.color }}>{row.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Stats grid ── */}
      <div className="grid-4 mb-3">
        {[
          { icon: "💰", value: totalPoints.toLocaleString(),  label: "Total Points",   color: "var(--accent)" },
          { icon: "⭐", value: `${xp.toLocaleString()} XP`,  label: "Total XP",       color: "#c4b5fd" },
          { icon: "🔥", value: `${streak} days`,              label: "Study Streak",   color: "var(--warning)" },
          { icon: "📈", value: `${currentMult}×`,             label: "XP Multiplier",  color: "var(--accent3)" },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div className="stat-icon">{s.icon}</div>
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      {/* ── Points bar chart ── */}
      {chartData.length > 0 && (
        <div className="card mb-3">
          <h3 style={{ fontFamily: "Syne", fontWeight: 700, marginBottom: "0.5rem" }}>📊 Points per Exam (last {chartData.length})</h3>
          <p className="text-muted text-sm mb-3">Higher scores + longer streaks = more points per exam.</p>
          <div className="points-history-bar">
            {chartData.map((r, i) => {
              const h = Math.max(8, Math.round((r.pointsEarned / maxPts) * 100));
              const color = r.percentage >= 80 ? "var(--accent3)" : r.percentage >= 60 ? "var(--accent)" : "var(--warning)";
              return (
                <div key={i} className="points-bar-item"
                  data-tip={`${r.examTitle?.slice(0,20)}…: ${r.pointsEarned} pts (${r.percentage}%)`}
                  style={{ height: `${h}%`, background: color, opacity: 0.85 }}
                />
              );
            })}
          </div>
          <div style={{ display: "flex", gap: 16, marginTop: "1rem", fontSize: "0.72rem" }}>
            <span style={{ color: "var(--accent3)" }}>■ ≥80%</span>
            <span style={{ color: "var(--accent)" }}>■ 60–79%</span>
            <span style={{ color: "var(--warning)" }}>■ &lt;60%</span>
          </div>
        </div>
      )}

      {/* ── Streak multiplier info ── */}
      <div className="card mb-3">
        <h3 style={{ fontFamily: "Syne", fontWeight: 700, marginBottom: "1rem" }}>🔥 Streak Multiplier Tiers</h3>
        <p className="text-muted text-sm mb-3">Study every day to boost your XP earnings. Your current streak is <strong style={{ color: "var(--warning)" }}>{streak} days</strong>.</p>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {multiplierTiers.map(t => {
            const active = currentMult === parseFloat(t.mult);
            return (
              <div key={t.mult} style={{
                display: "flex", alignItems: "center", gap: 12,
                padding: "10px 14px", borderRadius: 10,
                background: active ? "rgba(0,212,255,0.06)" : "transparent",
                border: active ? "1px solid rgba(0,212,255,0.2)" : "1px solid transparent",
                transition: "all 0.2s",
              }}>
                <div style={{ minWidth: 52, fontFamily: "Syne", fontWeight: 800, fontSize: "1rem", color: t.color }}>
                  {t.mult}
                </div>
                <div style={{ flex: 1, fontSize: "0.85rem", color: "var(--text-dim)" }}>
                  {t.min}–{t.max} day streak
                </div>
                {active && (
                  <span style={{ fontSize: "0.72rem", background: "rgba(0,212,255,0.15)", border: "1px solid rgba(0,212,255,0.3)", color: "var(--accent)", borderRadius: 20, padding: "2px 10px", fontWeight: 700 }}>
                    ← YOU ARE HERE
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* ── How points are calculated ── */}
      <div className="card mb-3">
        <h3 style={{ fontFamily: "Syne", fontWeight: 700, marginBottom: "1rem" }}>📐 How Points Are Calculated</h3>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>
          {[
            { action: "Attempt any exam",      pts: "+10 base XP" },
            { action: "Each correct answer",   pts: "+5 XP" },
            { action: "Pass (≥60%)",           pts: "+20 XP" },
            { action: "High score (≥80%)",     pts: "+20 XP" },
            { action: "Perfect score (100%)",  pts: "+50 XP" },
            { action: "Adaptive exam",         pts: "+15 XP" },
            { action: "3-day streak",          pts: "1.25× multiplier" },
            { action: "7-day streak",          pts: "1.5× multiplier" },
            { action: "14-day streak",         pts: "1.75× multiplier" },
            { action: "30-day streak",         pts: "2.0× multiplier" },
          ].map(row => (
            <div key={row.action} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 12px", background: "var(--surface2)", borderRadius: 8, fontSize: "0.83rem" }}>
              <span style={{ color: "var(--text-dim)" }}>{row.action}</span>
              <span style={{ fontWeight: 700, color: "var(--accent3)", whiteSpace: "nowrap", marginLeft: 8 }}>{row.pts}</span>
            </div>
          ))}
        </div>
        <div style={{ marginTop: "1rem", padding: "10px 14px", background: "rgba(0,212,255,0.06)", borderRadius: 8, fontSize: "0.82rem", color: "var(--text-muted)" }}>
          <strong style={{ color: "var(--accent)" }}>Formula:</strong> Points = (Base XP × Streak Multiplier) × (1 + Score% ÷ 200)
        </div>
      </div>

      {/* ── Points history table ── */}
      <div className="card">
        <h3 style={{ fontFamily: "Syne", fontWeight: 700, marginBottom: "1rem" }}>📋 Points History</h3>
        {sortedRecent.length === 0 ? (
          <div className="empty" style={{ padding: "2rem" }}>
            <div className="empty-icon">💰</div>
            <div>No points earned yet — complete an exam to start!</div>
          </div>
        ) : (
          <>
            {/* Column headers */}
            <div className="points-row" style={{ fontWeight: 700, fontSize: "0.72rem", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px", borderBottom: "1px solid var(--border)", paddingBottom: 8, marginBottom: 4 }}>
              <div style={{ flex: 3 }}>Exam</div>
              <div style={{ flex: 1, textAlign: "center" }}>Score</div>
              <div style={{ flex: 1, textAlign: "center" }}>XP</div>
              <div style={{ flex: 1, textAlign: "right" }}>Points</div>
            </div>
            {sortedRecent.map((r, i) => (
              <div key={r.id || i} className="points-row">
                <div style={{ flex: 3 }}>
                  <div style={{ fontWeight: 500, fontSize: "0.88rem" }}>
                    {r.adaptive && <span className="adaptive-badge" style={{ fontSize: "0.6rem", padding: "1px 5px", marginRight: 5 }}>⚡</span>}
                    {r.examTitle}
                  </div>
                  <div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>{r.completedAt}</div>
                </div>
                <div style={{ flex: 1, textAlign: "center" }}>
                  <span style={{ fontWeight: 700, color: r.percentage >= 60 ? "var(--accent3)" : "var(--danger)", fontSize: "0.88rem" }}>
                    {r.percentage}%
                  </span>
                </div>
                <div style={{ flex: 1, textAlign: "center" }}>
                  <span style={{ color: "#c4b5fd", fontSize: "0.85rem", fontWeight: 600 }}>
                    +{r.xpEarned || 0}
                    {r.xpMultiplier > 1 && (
                      <span style={{ color: "var(--warning)", fontSize: "0.7rem", marginLeft: 3 }}>×{r.xpMultiplier}</span>
                    )}
                  </span>
                </div>
                <div style={{ flex: 1, textAlign: "right" }}>
                  <span style={{ fontFamily: "Syne", fontWeight: 700, color: "var(--accent)", fontSize: "0.95rem" }}>
                    +{(r.pointsEarned || 0).toLocaleString()}
                  </span>
                </div>
              </div>
            ))}

            {/* Running total row */}
            <div style={{ borderTop: "1px solid var(--border)", marginTop: 8, paddingTop: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: "0.82rem", color: "var(--text-muted)" }}>Total from {myResults.length} exam{myResults.length !== 1 ? "s" : ""}</span>
              <span style={{ fontFamily: "Syne", fontWeight: 800, fontSize: "1.1rem", color: "var(--accent)" }}>
                {totalPoints.toLocaleString()} pts
              </span>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ─── LEADERBOARD PAGE ─────────────────────────────────────────────────────────
function LeaderboardPage({ user, leaderboard, setLeaderboard }) {
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded]   = useState(false);

  useEffect(() => {
    if (loaded) return;
    setLoading(true);
    apiGetLeaderboard()
      .then(data => { setLeaderboard(data); setLoaded(true); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [loaded, setLeaderboard]);

  const RANK_MEDALS = ["🥇", "🥈", "🥉"];

  return (
    <div className="container" style={{ maxWidth: 700 }}>
      <div className="page-title">🏅 Leaderboard</div>
      <div className="page-subtitle">Top students ranked by achievement points</div>

      {loading ? (
        <div className="empty"><div className="empty-icon" style={{ fontSize: "2rem" }}>⏳</div><div>Loading rankings…</div></div>
      ) : leaderboard.length === 0 ? (
        <div className="empty"><div className="empty-icon">🏅</div><div>No data yet — complete exams to appear here!</div></div>
      ) : (
        <>
          {/* Top 3 podium */}
          {leaderboard.length >= 3 && (
            <div style={{ display: "flex", justifyContent: "center", alignItems: "flex-end", gap: "1rem", marginBottom: "2rem" }}>
              {[leaderboard[1], leaderboard[0], leaderboard[2]].map((s, podiumIdx) => {
                if (!s) return null;
                const heights = [120, 150, 100];
                const colors = ["#94a3b8", "#fbbf24", "#b45309"];
                const isMe = s._id?.toString() === user.id?.toString();
                return (
                  <div key={s._id} style={{ textAlign: "center", flex: 1, maxWidth: 160 }}>
                    <div style={{ fontSize: "2rem", marginBottom: 4 }}>{podiumIdx === 1 ? "🥇" : podiumIdx === 0 ? "🥈" : "🥉"}</div>
                    <div style={{ fontWeight: 700, fontSize: "0.85rem", marginBottom: 4, color: isMe ? "var(--accent)" : "var(--text)" }}>
                      {s.name}{isMe ? " (You)" : ""}
                    </div>
                    <div style={{ fontSize: "0.75rem", color: "#c4b5fd", marginBottom: 8 }}>
                      {(s.totalPoints || 0).toLocaleString()} pts
                    </div>
                    <div style={{
                      height: heights[podiumIdx],
                      background: `linear-gradient(to top, ${colors[podiumIdx]}44, ${colors[podiumIdx]}22)`,
                      border: `2px solid ${colors[podiumIdx]}66`,
                      borderRadius: "10px 10px 0 0",
                      display: "flex", alignItems: "center", justifyContent: "center",
                    }}>
                      <div className="level-badge" style={{ width: 40, height: 40, fontSize: "0.9rem" }}>{s.level || 1}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Full ranked list */}
          <div className="card">
            {/* Header */}
            <div className="leaderboard-row" style={{ paddingBottom: 8, marginBottom: 4, borderBottom: "1px solid var(--border)", fontWeight: 600, fontSize: "0.75rem", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px" }}>
              <div>Rank</div>
              <div>Student</div>
              <div style={{ textAlign: "right" }}>Level</div>
              <div style={{ textAlign: "right" }}>Points</div>
            </div>
            {leaderboard.map((s, i) => {
              const isMe = s._id?.toString() === user.id?.toString();
              return (
                <div key={s._id} className={`leaderboard-row ${isMe ? "me" : ""}`}>
                  {/* Rank */}
                  <div className={`rank-num rank-${i + 1}`} style={{ color: i < 3 ? undefined : "var(--text-muted)" }}>
                    {i < 3 ? RANK_MEDALS[i] : `#${i + 1}`}
                  </div>
                  {/* Student info */}
                  <div>
                    <div style={{ fontWeight: isMe ? 700 : 500, color: isMe ? "var(--accent)" : "var(--text)" }}>
                      {s.name}{isMe ? " 👈 You" : ""}
                    </div>
                    <div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>
                      {s.badges?.length || 0} badges · 🔥 {s.streak || 0} streak
                      {s.dept ? ` · ${s.dept}` : ""}
                    </div>
                  </div>
                  {/* Level */}
                  <div style={{ textAlign: "right" }}>
                    <div className="level-badge" style={{ width: 28, height: 28, fontSize: "0.75rem", marginLeft: "auto" }}>
                      {s.level || 1}
                    </div>
                  </div>
                  {/* Points */}
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontFamily: "Syne", fontWeight: 700, color: isMe ? "var(--accent)" : "var(--text)" }}>
                      {(s.totalPoints || 0).toLocaleString()}
                    </div>
                    <div style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>{(s.xp||0).toLocaleString()} XP</div>
                  </div>
                </div>
              );
            })}
          </div>

          <div style={{ textAlign: "center", marginTop: "1rem", fontSize: "0.78rem", color: "var(--text-muted)" }}>
            Points = XP × (1 + score%) per exam · Updated after every submission
          </div>
        </>
      )}
    </div>
  );
}
