const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const https = require("https");
require("dotenv").config();

const app = express();
app.use(cors({ origin: "http://localhost:3000", credentials: true }));
app.use(express.json());

const JWT_SECRET    = process.env.JWT_SECRET    || "examportal_secret_key";
const MONGO_URI     = process.env.MONGO_URI     || "mongodb://localhost:27017/examportal";
const PORT          = process.env.PORT          || 5000;
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || "";  // Set in .env

mongoose.connect(MONGO_URI)
  .then(() => console.log("✅  MongoDB connected →", MONGO_URI))
  .catch((err) => { console.error("❌  MongoDB error:", err.message); process.exit(1); });

// ═══════════════════════════════════════════════════════════════════════════════
//  SCHEMAS
// ═══════════════════════════════════════════════════════════════════════════════
const userSchema = new mongoose.Schema({
  name:     { type: String, required: true, trim: true },
  email:    { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true },
  role:     { type: String, enum: ["admin", "student"], default: "student" },
  rollNo:   { type: String, default: null },
  dept:     { type: String, default: null },
  googleId:    { type: String, default: null },
  googlePhoto: { type: String, default: null },
  xp:           { type: Number, default: 0 },
  level:        { type: Number, default: 1 },
  totalPoints:  { type: Number, default: 0 },
  badges:       { type: [String], default: [] },
  achievements: { type: [{ id: String, name: String, desc: String, icon: String, earnedAt: String }], default: [] },
  streak:       { type: Number, default: 0 },
  lastActiveDate: { type: String, default: null },
}, { timestamps: true });

const questionSchema = new mongoose.Schema({
  subject:       { type: String, required: true, trim: true },
  text:          { type: String, required: true },
  options:       { type: [String], validate: [(v) => v.length === 4, "Exactly 4 options required"] },
  answer:        { type: Number, required: true, min: 0, max: 3 },
  explanation:   { type: String, default: null },
  difficulty:    { type: Number, default: 3, min: 1, max: 5 },
  hint:          { type: String, default: null },
  timesShown:    { type: Number, default: 0 },
  timesCorrect:  { type: Number, default: 0 },
  avgResponseMs: { type: Number, default: 0 },
}, { timestamps: true });

const examSchema = new mongoose.Schema({
  title:           { type: String, required: true },
  duration:        { type: Number, required: true },
  timePerQuestion: { type: Number, default: 30 },
  questionIds:     [{ type: mongoose.Schema.Types.ObjectId, ref: "Question" }],
  adaptive:        { type: Boolean, default: false },
  adaptiveCount:   { type: Number, default: 10 },
  shuffleQuestions:{ type: Boolean, default: false },
  shuffleOptions:  { type: Boolean, default: false },
  availableFrom:   { type: String, default: null },  // "HH:MM" 24h — null = no lock
  availableTo:     { type: String, default: null },  // "HH:MM" 24h — null = no lock
  createdAt:       { type: String, default: () => new Date().toISOString().split("T")[0] },
});

const resultSchema = new mongoose.Schema({
  userId:        { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  userName:      { type: String, required: true },
  examId:        { type: mongoose.Schema.Types.ObjectId, ref: "Exam", required: true },
  examTitle:     { type: String, required: true },
  correct:       { type: Number, required: true },
  total:         { type: Number, required: true },
  percentage:    { type: Number, required: true },
  answers:       { type: Map, of: Number },
  autoSubmitted: { type: Boolean, default: false },
  completedAt:   { type: String, default: () => new Date().toLocaleString() },
  // Adaptive extras
  adaptive:       { type: Boolean, default: false },
  finalAbility:   { type: Number, default: null },
  abilityLabel:   { type: String, default: null },
  difficultyPath: { type: [Number], default: [] },
  responseTimes:  { type: [Number], default: [] },
  hintUsed:       { type: [Boolean], default: [] },
  // Gamification
  xpEarned:     { type: Number, default: 0 },
  xpBase:       { type: Number, default: 0 },
  xpMultiplier: { type: Number, default: 1 },
  pointsEarned: { type: Number, default: 0 },
  newBadges:    { type: [String], default: [] },
  // Cheat detection
  cheatFlags: {
    type: {
      tabSwitches:    { type: Number, default: 0 },
      copyPasteCount: { type: Number, default: 0 },
      tooFastAnswers: { type: Number, default: 0 },
      suspiciousScore:{ type: Boolean, default: false },
      flagged:        { type: Boolean, default: false },
      severity:       { type: String, default: "none" }, // none / low / medium / high
    },
    default: () => ({}),
  },
}, { timestamps: true });

const User     = mongoose.model("User",     userSchema);
const Question = mongoose.model("Question", questionSchema);
const Exam     = mongoose.model("Exam",     examSchema);
const Result   = mongoose.model("Result",   resultSchema);

// ═══════════════════════════════════════════════════════════════════════════════
//  AUTH MIDDLEWARE
// ═══════════════════════════════════════════════════════════════════════════════
const auth = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "No token" });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: "Invalid or expired token" }); }
};
const adminOnly = (req, res, next) => {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Admin access required" });
  next();
};

app.get("/api/health", (req, res) => res.json({ status: "ok" }));

// ═══════════════════════════════════════════════════════════════════════════════
//  GAMIFICATION ENGINE  (Streak Multiplier integrated)
// ═══════════════════════════════════════════════════════════════════════════════
const LEVEL_THRESHOLDS = [0,100,250,500,900,1400,2100,3000,4200,5600,7500];
function xpToLevel(xp) {
  let lvl = 1;
  for (let i = 1; i < LEVEL_THRESHOLDS.length; i++) { if (xp >= LEVEL_THRESHOLDS[i]) lvl = i+1; else break; }
  return Math.min(lvl, 10);
}

// Streak → XP multiplier table
function streakToMultiplier(streak) {
  if (streak >= 30) return 3.0;
  if (streak >= 14) return 2.5;
  if (streak >= 7)  return 2.0;
  if (streak >= 3)  return 1.5;
  if (streak >= 1)  return 1.2;
  return 1.0;
}

const ALL_BADGES = {
  "first_blood":    { name:"First Blood",    icon:"🩸", desc:"Complete your first exam" },
  "perfect_score":  { name:"Perfect Score",  icon:"💯", desc:"Score 100% on any exam" },
  "speed_demon":    { name:"Speed Demon",     icon:"⚡", desc:"Finish exam in under half the time" },
  "scholar":        { name:"Scholar",         icon:"🎓", desc:"Pass 5 exams" },
  "expert":         { name:"Expert",          icon:"🏆", desc:"Pass 10 exams" },
  "streak_3":       { name:"On Fire",         icon:"🔥", desc:"3-day study streak" },
  "streak_7":       { name:"Weekly Warrior",  icon:"📅", desc:"7-day study streak" },
  "streak_14":      { name:"Fortnight Grind", icon:"🔋", desc:"14-day study streak" },
  "streak_30":      { name:"Unstoppable",     icon:"🚀", desc:"30-day study streak" },
  "high_scorer":    { name:"High Scorer",     icon:"⭐", desc:"Score 90%+ on any exam" },
  "persistent":     { name:"Persistent",      icon:"💪", desc:"Attempt the same exam 3 times" },
  "adaptive_ace":   { name:"Adaptive Ace",    icon:"🧠", desc:"Complete an adaptive exam" },
  "subject_master": { name:"Subject Master",  icon:"📚", desc:"Pass all exams in one subject" },
  "night_owl":      { name:"Night Owl",       icon:"🦉", desc:"Complete an exam after midnight" },
  "level_5":        { name:"Rising Star",     icon:"🌟", desc:"Reach Level 5" },
  "level_10":       { name:"Legend",          icon:"👑", desc:"Reach Level 10" },
  "multiplier_2x":  { name:"Double XP",       icon:"✨", desc:"Achieve a 2× streak multiplier" },
};

async function processGamification(userId, result, allResults) {
  const user = await User.findById(userId);
  if (!user || user.role !== "student") return { xpEarned:0, xpBase:0, xpMultiplier:1, pointsEarned:0, newBadges:[], newAchievements:[] };

  const { correct, percentage, adaptive, examTitle } = result;
  const userResults = allResults.filter(r => r.userId.toString() === userId.toString());

  // ── Streak update ────────────────────────────────────────────────────────────
  const today     = new Date().toISOString().split("T")[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0];
  let newStreak = user.streak || 0;
  if (user.lastActiveDate === yesterday) newStreak++;
  else if (user.lastActiveDate !== today) newStreak = 1;
  // (keep streak if same day — already counted)

  // ── Streak multiplier ────────────────────────────────────────────────────────
  const multiplier = streakToMultiplier(newStreak);

  // ── Base XP (before multiplier) ──────────────────────────────────────────────
  let baseXp = 10;
  baseXp += Math.round(correct * 5);
  if (percentage >= 60)   baseXp += 20;
  if (percentage >= 80)   baseXp += 20;
  if (percentage === 100) baseXp += 50;
  if (adaptive)           baseXp += 15;

  // ── Apply streak multiplier ──────────────────────────────────────────────────
  const xp = Math.round(baseXp * multiplier);
  const points = Math.round(xp * (1 + (percentage / 200)));

  // ── Badges ───────────────────────────────────────────────────────────────────
  const earnedBadges = new Set(user.badges);
  const newBadges = [], newAchievements = [];
  const checkBadge = (id) => {
    if (!earnedBadges.has(id)) {
      earnedBadges.add(id);
      newBadges.push(id);
      const b = ALL_BADGES[id];
      newAchievements.push({ id, name:b.name, desc:b.desc, icon:b.icon, earnedAt:new Date().toLocaleString() });
    }
  };

  const passedCount  = userResults.filter(r => r.percentage >= 60).length + (percentage >= 60 ? 1 : 0);
  const totalAttempts = userResults.length + 1;

  if (totalAttempts === 1)     checkBadge("first_blood");
  if (percentage === 100)      checkBadge("perfect_score");
  if (percentage >= 90)        checkBadge("high_scorer");
  if (passedCount >= 5)        checkBadge("scholar");
  if (passedCount >= 10)       checkBadge("expert");
  if (newStreak >= 3)          checkBadge("streak_3");
  if (newStreak >= 7)          checkBadge("streak_7");
  if (newStreak >= 14)         checkBadge("streak_14");
  if (newStreak >= 30)         checkBadge("streak_30");
  if (adaptive)                checkBadge("adaptive_ace");
  if (multiplier >= 2.0)       checkBadge("multiplier_2x");
  const retakes = userResults.filter(r => r.examTitle === examTitle).length;
  if (retakes >= 2)            checkBadge("persistent");
  const hour = new Date().getHours();
  if (hour >= 0 && hour < 5)   checkBadge("night_owl");

  const newXp    = (user.xp || 0) + xp;
  const newLevel = xpToLevel(newXp);
  if (newLevel >= 5)  checkBadge("level_5");
  if (newLevel >= 10) checkBadge("level_10");

  await User.findByIdAndUpdate(userId, {
    xp: newXp, level: newLevel,
    totalPoints: (user.totalPoints || 0) + points,
    badges: [...earnedBadges],
    achievements: [...(user.achievements || []), ...newAchievements],
    streak: newStreak, lastActiveDate: today,
  });

  return { xpEarned:xp, xpBase:baseXp, xpMultiplier:multiplier, pointsEarned:points, newBadges, newAchievements };
}

// ═══════════════════════════════════════════════════════════════════════════════
//  AUTH ROUTES
// ═══════════════════════════════════════════════════════════════════════════════
app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password, role="student", rollNo, dept, adminCode } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error:"Name, email and password required" });
    if (role === "admin" && adminCode !== "ADMIN2024") return res.status(400).json({ error:"Invalid admin code" });
    if (await User.findOne({ email })) return res.status(400).json({ error:"Email already registered" });
    const user = await User.create({ name, email, password:await bcrypt.hash(password,10), role, rollNo, dept });
    res.status(201).json({ message:"Registered successfully", userId:user._id });
  } catch(err){ res.status(500).json({ error:err.message }); }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password, role } = req.body;
    const user = await User.findOne({ email, role });
    if (!user || !await bcrypt.compare(password, user.password))
      return res.status(400).json({ error:"Invalid credentials" });
    const token = jwt.sign(
      { id:user._id, name:user.name, email:user.email, role:user.role, rollNo:user.rollNo, dept:user.dept },
      JWT_SECRET, { expiresIn:"24h" }
    );
    res.json({ token, user:{ id:user._id, name:user.name, email:user.email, role:user.role, rollNo:user.rollNo, dept:user.dept, xp:user.xp, level:user.level, totalPoints:user.totalPoints, badges:user.badges, achievements:user.achievements, streak:user.streak } });
  } catch(err){ res.status(500).json({ error:err.message }); }
});

app.post("/api/auth/check-email", async (req, res) => {
  try {
    const user = await User.findOne({ email:req.body.email });
    if (!user) return res.status(404).json({ error:"No account found" });
    res.json({ message:"Email found", name:user.name });
  } catch(err){ res.status(500).json({ error:err.message }); }
});

app.post("/api/auth/forgot-password", async (req, res) => {
  try {
    const { email, newPassword } = req.body;
    if (!newPassword || newPassword.length < 6) return res.status(400).json({ error:"Password must be at least 6 characters" });
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ error:"No account found" });
    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();
    res.json({ message:"Password updated successfully" });
  } catch(err){ res.status(500).json({ error:err.message }); }
});

// ─── GOOGLE OAUTH ──────────────────────────────────────────────────────────────
// Decode a Google ID token payload (base64url part 1). We trust it because it
// arrives from Google's secure OAuth popup — not from an open user field.
function decodeGoogleToken(token) {
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Invalid JWT format");
  const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
  if (!payload.email) throw new Error("No email in token");
  if (GOOGLE_CLIENT_ID && payload.aud !== GOOGLE_CLIENT_ID) throw new Error("Token audience mismatch");
  if (payload.exp && payload.exp * 1000 < Date.now()) throw new Error("Google token expired");
  return payload;
}

app.post("/api/auth/google", async (req, res) => {
  try {
    const { credential } = req.body;
    if (!credential) return res.status(400).json({ error: "Google credential required" });

    const payload = decodeGoogleToken(credential);
    const { email, name, picture, sub: googleId } = payload;
    if (!email) return res.status(400).json({ error: "No email from Google account" });

    let user = await User.findOne({ email });
    if (user) {
      // Link Google ID if this is first Google sign-in for existing account
      if (!user.googleId) { user.googleId = googleId; user.googlePhoto = picture || null; await user.save(); }
    } else {
      // Auto-create student account from Google profile
      user = await User.create({
        name:        name || email.split("@")[0],
        email,
        password:    await bcrypt.hash(googleId + JWT_SECRET, 10),
        role:        "student",
        googleId,
        googlePhoto: picture || null,
      });
    }

    const token = jwt.sign(
      { id: user._id, name: user.name, email: user.email, role: user.role, rollNo: user.rollNo, dept: user.dept },
      JWT_SECRET, { expiresIn: "24h" }
    );
    res.json({
      token,
      user: {
        id: user._id, name: user.name, email: user.email, role: user.role,
        rollNo: user.rollNo, dept: user.dept, googlePhoto: user.googlePhoto,
        xp: user.xp, level: user.level, totalPoints: user.totalPoints,
        badges: user.badges, achievements: user.achievements, streak: user.streak,
      },
    });
  } catch (err) {
    console.error("Google auth error:", err.message);
    res.status(400).json({ error: "Google sign-in failed: " + err.message });
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
//  USER ROUTES
// ═══════════════════════════════════════════════════════════════════════════════
app.get("/api/users",        auth, adminOnly, async (req,res) => { try { res.json(await User.find().select("-password").sort({ createdAt:-1 })); } catch(e){ res.status(500).json({error:e.message}); } });
app.post("/api/users",       auth, adminOnly, async (req,res) => { try { const {name,email,password,role="student"} = req.body; if(await User.findOne({email})) return res.status(400).json({error:"Email exists"}); const user=await User.create({name,email,password:await bcrypt.hash(password,10),role}); res.status(201).json({message:"Created",user:{id:user._id,name:user.name,email:user.email,role:user.role}}); } catch(e){ res.status(500).json({error:e.message}); } });
app.delete("/api/users/:id", auth, adminOnly, async (req,res) => { try { await User.findByIdAndDelete(req.params.id); res.json({message:"User deleted"}); } catch(e){ res.status(500).json({error:e.message}); } });
app.get("/api/profile",      auth, async (req,res) => { try { res.json(await User.findById(req.user.id).select("-password")); } catch(e){ res.status(500).json({error:e.message}); } });
app.get("/api/leaderboard",  auth, async (req,res) => { try { res.json(await User.find({role:"student"}).select("name xp level totalPoints badges streak dept rollNo").sort({totalPoints:-1}).limit(20)); } catch(e){ res.status(500).json({error:e.message}); } });

// ═══════════════════════════════════════════════════════════════════════════════
//  QUESTION ROUTES
// ═══════════════════════════════════════════════════════════════════════════════
app.get("/api/questions",       auth, async (req,res)=>{ try { res.json(await Question.find().sort({subject:1})); } catch(e){ res.status(500).json({error:e.message}); } });
app.post("/api/questions",      auth, adminOnly, async (req,res)=>{ try { res.status(201).json(await Question.create(req.body)); } catch(e){ res.status(500).json({error:e.message}); } });
app.put("/api/questions/:id",   auth, adminOnly, async (req,res)=>{ try { const q=await Question.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true}); if(!q) return res.status(404).json({error:"Not found"}); res.json(q); } catch(e){ res.status(500).json({error:e.message}); } });
app.delete("/api/questions/:id",auth, adminOnly, async (req,res)=>{ try { await Question.findByIdAndDelete(req.params.id); res.json({message:"Deleted"}); } catch(e){ res.status(500).json({error:e.message}); } });

// ═══════════════════════════════════════════════════════════════════════════════
//  EXAM ROUTES
// ═══════════════════════════════════════════════════════════════════════════════
app.get("/api/exams",      auth, async (req,res)=>{ try { res.json(await Exam.find().populate("questionIds")); } catch(e){ res.status(500).json({error:e.message}); } });
app.post("/api/exams",     auth, adminOnly, async (req,res)=>{ try { const exam=await Exam.create(req.body); res.status(201).json(await exam.populate("questionIds")); } catch(e){ res.status(500).json({error:e.message}); } });
app.put("/api/exams/:id",  auth, adminOnly, async (req,res)=>{ try { const exam=await Exam.findByIdAndUpdate(req.params.id,req.body,{new:true}).populate("questionIds"); if(!exam) return res.status(404).json({error:"Not found"}); res.json(exam); } catch(e){ res.status(500).json({error:e.message}); } });
app.delete("/api/exams/:id",auth,adminOnly, async (req,res)=>{ try { await Exam.findByIdAndDelete(req.params.id); res.json({message:"Deleted"}); } catch(e){ res.status(500).json({error:e.message}); } });

// ── TIME-OF-DAY ACCESS CHECK ──────────────────────────────────────────────────
app.get("/api/exams/:id/access-check", auth, async (req, res) => {
  try {
    const exam = await Exam.findById(req.params.id);
    if (!exam) return res.status(404).json({ error:"Exam not found" });

    if (!exam.availableFrom && !exam.availableTo) {
      return res.json({ allowed:true, reason:"No time restriction" });
    }
    const now = new Date();
    const cur = now.getHours() * 60 + now.getMinutes();
    const [fH, fM] = (exam.availableFrom || "00:00").split(":").map(Number);
    const [tH, tM] = (exam.availableTo   || "23:59").split(":").map(Number);
    const from = fH * 60 + fM;
    const to   = tH * 60 + tM;
    const ok   = from <= to ? (cur >= from && cur <= to) : (cur >= from || cur <= to);

    if (!ok) {
      return res.json({
        allowed: false,
        reason: `This exam is only available from ${exam.availableFrom} to ${exam.availableTo}`,
        availableFrom: exam.availableFrom,
        availableTo:   exam.availableTo,
      });
    }
    res.json({ allowed:true });
  } catch(err){ res.status(500).json({ error:err.message }); }
});

// ═══════════════════════════════════════════════════════════════════════════════
//  RESULT ROUTES
// ═══════════════════════════════════════════════════════════════════════════════
app.get("/api/results", auth, async (req,res) => {
  try {
    const filter = req.user.role === "admin" ? {} : { userId:req.user.id };
    res.json(await Result.find(filter).sort({createdAt:-1}));
  } catch(e){ res.status(500).json({error:e.message}); }
});

app.post("/api/results", auth, async (req,res) => {
  try {
    const body = req.body;

    // ── Time-of-Day Lock server-side validation ────────────────────────────────
    const exam = await Exam.findById(body.examId);
    if (exam && (exam.availableFrom || exam.availableTo)) {
      const now = new Date();
      const cur = now.getHours() * 60 + now.getMinutes();
      const [fH, fM] = (exam.availableFrom || "00:00").split(":").map(Number);
      const [tH, tM] = (exam.availableTo   || "23:59").split(":").map(Number);
      const from = fH * 60 + fM;
      const to   = tH * 60 + tM;
      const ok   = from <= to ? (cur >= from && cur <= to) : (cur >= from || cur <= to);
      if (!ok) return res.status(403).json({ error:`This exam is only available from ${exam.availableFrom} to ${exam.availableTo}` });
    }

    // ── Cheat flag analysis ────────────────────────────────────────────────────
    const cf = body.cheatData || {};
    const tabSwitches    = cf.tabSwitches    || 0;
    const copyPasteCount = cf.copyPasteCount || 0;
    const responseTimes  = body.responseTimes || [];
    const tooFastAnswers = responseTimes.filter(ms => ms < 1500).length;
    const avgResp = responseTimes.length ? responseTimes.reduce((a,b)=>a+b,0)/responseTimes.length : 99999;
    const suspiciousScore = body.percentage >= 90 && avgResp < 5000 && responseTimes.length >= 5;
    let score = 0;
    if (tabSwitches >= 3) score += 2; else if (tabSwitches >= 1) score += 1;
    if (copyPasteCount >= 2) score += 2; else if (copyPasteCount >= 1) score += 1;
    if (tooFastAnswers >= 5) score += 3; else if (tooFastAnswers >= 3) score += 2; else if (tooFastAnswers >= 1) score += 1;
    if (suspiciousScore) score += 2;
    const severity = score >= 5 ? "high" : score >= 3 ? "medium" : score >= 1 ? "low" : "none";
    const cheatFlags = { tabSwitches, copyPasteCount, tooFastAnswers, suspiciousScore, flagged: score >= 3, severity };

    const allResults   = await Result.find({ userId:req.user.id });
    const gamification = await processGamification(req.user.id, body, allResults);

    const result = await Result.create({
      ...body,
      userId:      req.user.id,
      userName:    req.user.name,
      cheatFlags,
      xpMultiplier: gamification.xpMultiplier || 1,
      ...gamification,
    });
    res.status(201).json({ ...result.toObject(), ...gamification });
  } catch(e){ res.status(500).json({error:e.message}); }
});

// GET /api/admin/cheat-reports — flagged results for admin review
app.get("/api/admin/cheat-reports", auth, adminOnly, async (req,res) => {
  try {
    const results = await Result.find({ "cheatFlags.flagged": true })
      .sort({ createdAt:-1 }).limit(100)
      .select("userName examTitle cheatFlags percentage completedAt");
    res.json(results);
  } catch(e){ res.status(500).json({error:e.message}); }
});

// ═══════════════════════════════════════════════════════════════════════════════
//  ADAPTIVE ENGINE
// ═══════════════════════════════════════════════════════════════════════════════
function abilityToLabel(t){ if(t<-1.5)return"Beginner";if(t<-0.5)return"Elementary";if(t<0.5)return"Intermediate";if(t<1.5)return"Advanced";return"Expert"; }
function thetaToDifficulty(t){ return Math.min(5,Math.max(1,Math.round(((t+3)/6)*4+1))); }
function updateTheta(theta,isCorrect,responseMs,timePerQMs){ const fast=responseMs<timePerQMs*0.5; let d=isCorrect?(fast?0.6:0.3):(fast?-0.5:-0.2); return Math.min(3,Math.max(-3,theta+d)); }

app.post("/api/adaptive/next", auth, async (req,res) => {
  try {
    const {examId,seenIds=[],theta=0,timePerQuestion=30} = req.body;
    const exam = await Exam.findById(examId);
    if (!exam) return res.status(404).json({error:"Exam not found"});
    const targetDifficulty = thetaToDifficulty(theta);
    const seenOIds = seenIds.map(id=>{try{return new mongoose.Types.ObjectId(id)}catch{return null}}).filter(Boolean);
    const base = {_id:{$in:exam.questionIds,$nin:seenOIds}};
    let q = await Question.findOne({...base,difficulty:targetDifficulty});
    if (!q){ const nearby=[targetDifficulty-1,targetDifficulty+1].filter(d=>d>=1&&d<=5); q=await Question.findOne({...base,difficulty:{$in:nearby}}); }
    if (!q) q = await Question.findOne(base);
    if (!q) return res.json({question:null,done:true});
    res.json({ question:{_id:q._id,id:q._id,subject:q.subject,text:q.text,options:q.options,answer:q.answer,difficulty:q.difficulty,hint:q.hint}, targetDifficulty,abilityLabel:abilityToLabel(theta),theta });
  } catch(e){ res.status(500).json({error:e.message}); }
});

app.post("/api/adaptive/answer", auth, async (req,res) => {
  try {
    const {questionId,isCorrect,responseMs,theta=0,timePerQuestion=30} = req.body;
    const newTheta = updateTheta(theta,isCorrect,responseMs,timePerQuestion*1000);
    Question.findById(questionId).then(q=>{if(q){const n=q.timesShown+1;q.timesShown=n;q.timesCorrect=q.timesCorrect+(isCorrect?1:0);q.avgResponseMs=Math.round(((q.avgResponseMs*(n-1))+responseMs)/n);q.save().catch(()=>{});}});
    res.json({newTheta,abilityLabel:abilityToLabel(newTheta),targetDifficulty:thetaToDifficulty(newTheta)});
  } catch(e){ res.status(500).json({error:e.message}); }
});

// ═══════════════════════════════════════════════════════════════════════════════
//  SEED
// ═══════════════════════════════════════════════════════════════════════════════
app.post("/api/seed", async (req,res) => {
  try {
    await Promise.all([User.deleteMany(),Question.deleteMany(),Exam.deleteMany(),Result.deleteMany()]);
    const adminPass=await bcrypt.hash("admin123",10), studentPass=await bcrypt.hash("student123",10);
    await User.insertMany([
      {name:"Admin User",   email:"admin@exam.com",    password:adminPass,   role:"admin"},
      {name:"Mani Samhitha",email:"mani@student.com",  password:studentPass, role:"student",rollNo:"24B11IT080",dept:"IT"},
      {name:"Abdul Waseef", email:"waseef@student.com",password:studentPass, role:"student",rollNo:"24B11IT001",dept:"IT"},
    ]);

    const Q=(subject,difficulty,text,options,answer,hint,explanation)=>({subject,difficulty,text,options,answer,hint:hint||null,explanation:explanation||null});
    const questionData=[
      Q("JavaScript",1,"Which method parses a JSON string?",["JSON.stringify()","JSON.parse()","JSON.convert()","JSON.decode()"],1,"Opposite of stringify","JSON.parse() converts a JSON string back into a JavaScript object. JSON.stringify() does the reverse."),
      Q("JavaScript",1,"What does '===' check?",["Value only","Type only","Value and Type","Neither"],2,"Stricter than ==","=== is strict equality: checks both value AND type. So 1 === '1' is false. == only checks value after coercion."),
      Q("JavaScript",2,"Block-scoped variable keyword?",["var","let","both","none"],1,"Introduced in ES6","let is block-scoped. var is function-scoped and can leak out of blocks."),
      Q("JavaScript",2,"typeof null returns?",["null","undefined","object","boolean"],2,"Famous JS quirk","This is a historical bug in JS. typeof null returns 'object'. Never fixed to preserve backward compatibility."),
      Q("JavaScript",2,"Which creates a filtered array?",["map()","forEach()","filter()","reduce()"],2,"It filters elements","filter() returns a new array with elements passing the test. map() transforms, forEach() iterates without returning."),
      Q("JavaScript",3,"What is a closure?",["A loop","Function with access to outer scope","An error handler","A CSS class"],1,"Inner functions remember outer vars","A closure retains access to variables from its outer scope, even after the outer function has returned."),
      Q("JavaScript",3,"Spread operator (...) does?",["Closes function","Expands iterables","Declares variables","Imports modules"],1,"Spreads elements","Spread expands an iterable into individual elements. [...arr1,...arr2] merges arrays."),
      Q("JavaScript",3,"Output of '2' + 2?",["4","22","NaN","Error"],1,"String + number","When you add a string and number, JS coerces number to string: '2' + 2 = '22'."),
      Q("JavaScript",4,"What does 'use strict' prevent?",["Type checking","Undeclared variables","Speeding code","ES6 features"],1,"Stricter declarations","'use strict' prevents using undeclared variables, deleting variables, duplicate parameters."),
      Q("JavaScript",4,"async/await handles?",["CSS animations","Async operations","DOM manipulation","Variable scoping"],1,"Syntactic sugar over Promises","async/await is syntactic sugar over Promises. An async function always returns a Promise."),
      Q("JavaScript",4,"What is event delegation?",["Events on children","One event on parent for all children","Remove listeners","Prevent bubbling"],1,"Uses event bubbling","Instead of adding listeners to each child, add one to parent. Events bubble up so parent catches them all."),
      Q("JavaScript",5,"typeof arguments in function?",["undefined","object","arguments","array"],1,"arguments is array-like","The arguments object is array-like (has length, indexable) but is NOT an Array. Arrow functions don't have arguments."),
      Q("JavaScript",5,"Object.freeze() does?",["Copies object","Makes object immutable","Freezes variable","Stops execution"],1,"Prevents modifications","Object.freeze() prevents adding, removing, or modifying properties. It's shallow — nested objects are not frozen."),
      Q("JavaScript",3,"'this' in a method refers to?",["Global object","Current object","Parent class","undefined"],1,"Context-dependent","In a method, 'this' refers to the object the method belongs to. Arrow functions inherit 'this' from enclosing scope."),
      Q("JavaScript",2,"Removes last array element?",["push()","pop()","shift()","splice()"],1,"Like a stack pop","pop() removes and returns the last element. push() adds to end."),
      Q("JavaScript",1,"Adds element to end of array?",["push()","pop()","shift()","unshift()"],0,"Opposite of pop","push() appends one or more elements to end of an array and returns the new length."),
      Q("JavaScript",3,"What is the DOM?",["Document Object Model","Data Object Method","Dynamic Object Manager","Display Module"],0,"Tree of HTML","DOM is a tree-like representation of HTML. JavaScript can read and modify it to change page content."),
      Q("JavaScript",2,"Select element by ID?",["querySelector()","getElement()","getElementById()","selectById()"],2,"Name says it","getElementById() selects one element by its id. querySelector('#id') also works but getElementById() is faster."),
      Q("JavaScript",4,"Promise.all() does?",["Sequential","All in parallel wait for all","Returns first resolved","Cancels on reject"],1,"ALL must resolve","Promise.all() resolves when ALL promises resolve. If any rejects, the whole rejects."),
      Q("JavaScript",5,"Prototype chain purpose?",["Memory management","Inheritance via parent lookup","Type conversion","Event handling"],1,"How JS implements inheritance","JS looks up properties on the object, then its prototype, then prototype's prototype up to Object.prototype."),
      Q("React",1,"State hook in functional components?",["useEffect","useContext","useState","useRef"],2,"Starts with useState","useState returns [value, setter]. Calling setter triggers a re-render."),
      Q("React",1,"What is JSX?",["A JS library","Syntax extension for JS","A CSS framework","A DB language"],1,"HTML-like in JavaScript","JSX lets you write HTML-like code in JavaScript. Babel compiles it to React.createElement() calls."),
      Q("React",2,"useEffect empty array runs?",["Every render","Once on mount","On unmount","Never"],1,"Empty deps = once","Empty dependency array [] means the effect runs only once after initial render."),
      Q("React",2,"Pass data parent to child?",["State","Props","Context","Redux"],1,"Short for properties","Props flow down. They are read-only in the child."),
      Q("React",2,"Virtual DOM is?",["Real DOM copy","Lightweight copy of real DOM","Server-side DOM","CSS structure"],1,"React's in-memory representation","React keeps a virtual copy of the DOM and diffs it to only update what changed."),
      Q("React",3,"React.Fragment does?",["Creates component","Wraps without extra DOM nodes","Deletes component","Imports module"],1,"Empty wrapper","Fragment groups elements without adding an extra div to the DOM."),
      Q("React",3,"Key prop in lists used for?",["Styling","Identify changed items","Create IDs","Pass data"],1,"Helps React diffing","Keys help React identify which items changed, were added, or removed."),
      Q("React",3,"Controlled component?",["Has internal state","Form data via React state","Stateless","Pure component"],1,"React controls the input","In controlled component, form input value is driven by React state."),
      Q("React",3,"useMemo does?",["Stores DOM reference","Memoizes computed value","Manages state","Handles effects"],1,"Memoize = remember result","useMemo caches the result of a computation. Recalculates only when dependencies change."),
      Q("React",4,"Prop drilling?",["Passing props through many layers","React optimization","State pattern","CSS method"],0,"Passing deep through layers","Prop drilling: passing props through many intermediate components to reach a deeply nested child."),
      Q("React",4,"useContext solves?",["Local state","Context without prop drilling","DOM ops","API calls"],1,"Avoids prop drilling","useContext lets any component consume context values without prop drilling."),
      Q("React",4,"Higher-Order Component?",["Renders another","Function taking/returning component","Class component","Styled component"],1,"HOC wraps a component","A HOC is a function that takes a component and returns a new enhanced component."),
      Q("React",4,"useRef returns?",["State","Effect","Mutable ref object","Context"],2,"Persists without re-render","useRef returns { current: value } that persists between renders without triggering re-render."),
      Q("React",5,"React 18 batches updates?",["Never","Only in event handlers","Everywhere in React 18","Only with useReducer"],2,"React 18 automatic batching","React 18 batches multiple setState calls everywhere into a single re-render."),
      Q("React",5,"React.memo() purpose?",["Memoize value","Prevent re-render if props unchanged","Cache API","Freeze component"],1,"Wraps to skip re-renders","React.memo memoizes rendered output. Skips re-rendering if props haven't changed."),
      Q("React",2,"Lifting state up means?",["State to child","State to common ancestor","Delete state","Use Redux"],1,"Move state higher","When siblings need shared state, lift it to their closest common ancestor."),
      Q("React",3,"Lazy loading in React?",["Load only when needed","Preload all","Disable rendering","Cache responses"],0,"React.lazy() splits bundles","React.lazy() + Suspense enable code splitting — bundle loaded only when first rendered."),
      Q("React",1,"Side effects hook?",["useState","useEffect","useContext","useReducer"],1,"Effect = side effect","useEffect handles side effects: data fetching, subscriptions, manual DOM changes."),
      Q("React",4,"React.StrictMode does?",["Prevents errors","Highlights problems in dev","Makes faster","Disables warnings"],1,"Dev double-invoke","StrictMode double-invokes certain functions in development to detect side effects."),
      Q("React",5,"Fiber algorithm?",["Rendering engine","React's incremental rendering algorithm","CSS engine","State manager"],1,"Introduced in React 16","React Fiber enables async rendering, pausing and prioritizing rendering work."),
      Q("MongoDB",1,"MongoDB stores data as?",["Tables","BSON documents","XML","CSV"],1,"Binary JSON","MongoDB stores BSON documents. Similar to JSON with additional types like Date, Binary, ObjectId."),
      Q("MongoDB",1,"Insert one document?",["db.insert()","db.collection.insertOne()","db.add()","db.push()"],1,"insertOne inserts ONE","insertOne() inserts a single document. insertMany() for multiple."),
      Q("MongoDB",2,"What is a collection?",["Group of databases","Group of documents","Group of fields","Group of indexes"],1,"Like a table","A collection groups MongoDB documents, like a SQL table but schema-flexible."),
      Q("MongoDB",2,"Operator for field > value?",["$gt","$lt","$eq","$ne"],0,"$gt = greater than","MongoDB uses $gt, $gte, $lt, $lte, $eq, $ne for comparisons."),
      Q("MongoDB",2,"Default field in every document?",["id","_id","docId","objectId"],1,"MongoDB auto-generates","Every document has _id as primary key. Default is ObjectId — 12-byte BSON type."),
      Q("MongoDB",3,"$set operator does?",["Deletes field","Creates collection","Updates field value","Indexes field"],2,"Sets a new value","$set updates specific fields without replacing the whole document."),
      Q("MongoDB",3,"What is Mongoose?",["A GUI","ODM for MongoDB and Node.js","A cloud service","A query language"],1,"ODM = Object Document Mapper","Mongoose provides schema validation, type casting, and query building for MongoDB in Node.js."),
      Q("MongoDB",3,"$in operator matches?",["Any value in array","All values","Regex match","Field existence"],0,"Are values IN this array?","$in selects documents where field equals any value in the specified array."),
      Q("MongoDB",3,"Aggregation stage that filters?",["$group","$match","$sort","$project"],1,"Like WHERE in SQL","$match filters documents in the aggregation pipeline, like SQL WHERE."),
      Q("MongoDB",4,"What is a replica set?",["Set of indexes","Servers maintaining same data","Backup file","Sharding strategy"],1,"Copies for HA","A replica set maintains same dataset across multiple servers. One primary, others secondaries."),
      Q("MongoDB",4,"Sharding is?",["Splitting data across servers","Encrypting data","Creating indexes","Backing up"],0,"Horizontal scaling","Sharding distributes data across multiple machines using a shard key."),
      Q("MongoDB",4,"$exists operator?",["$has","$exists","$contains","$field"],1,"The name says it","{ field: { $exists: true } } returns documents where the field exists."),
      Q("MongoDB",4,"db.collection.drop() does?",["Deletes one doc","Removes entire collection","Drops index","Disconnects"],1,"Drops everything","drop() removes the entire collection including all documents and indexes."),
      Q("MongoDB",5,"$lookup does?",["Filters docs","Left outer join with another collection","Sorts results","Counts docs"],1,"Like SQL JOIN","$lookup performs a left outer join to another collection in aggregation."),
      Q("MongoDB",5,"$facet allows?",["Multiple pipelines in one stage","Joining collections","Indexing fields","Encrypting"],0,"Multiple parallel sub-pipelines","$facet runs multiple aggregation pipelines on the same input documents."),
      Q("MongoDB",2,"find() returns?",["A single doc","A cursor","Array of all docs","A count"],1,"You iterate over a cursor","find() returns a cursor. Use findOne() for a single document."),
      Q("MongoDB",3,"limit() does?",["Limits DB size","Limits documents returned","Limits access","Limits field values"],1,"Controls result count","limit(n) restricts the number of documents returned."),
      Q("MongoDB",1,"MongoDB is what type?",["Relational","NoSQL","Graph","Columnar"],1,"Not SQL","MongoDB is a NoSQL document database. Schema-flexible and horizontally scalable."),
      Q("MongoDB",5,"WiredTiger is?",["Query optimizer","Default storage engine since v3.2 with MVCC","Sharding mechanism","Replication protocol"],1,"Replaced MMAPv1","WiredTiger is MongoDB's default storage engine since v3.2, supporting document-level concurrency."),
      Q("MongoDB",4,"MongoDB Atlas is?",["A local server","A CLI tool","A cloud-hosted MongoDB service","A GUI"],2,"Cloud = Atlas","MongoDB Atlas is a fully managed cloud database service on AWS, Azure, and GCP."),
      Q("Node.js",1,"Module to create HTTP server?",["fs","path","http","os"],2,"Named after protocol","The 'http' module provides HTTP server and client functionality."),
      Q("Node.js",1,"What is npm?",["Node Package Manager","New Project Module","Node Process Monitor","None"],0,"Manages packages","npm is the default package manager for Node.js with over 2 million packages."),
      Q("Node.js",2,"require() does?",["Exports modules","Imports modules","Installs packages","Defines variables"],1,"CommonJS import","require() loads and caches a CommonJS module."),
      Q("Node.js",2,"Event loop is?",["DOM loop","Async callback mechanism","Timer module","DB pool"],1,"Core to non-blocking I/O","The event loop allows Node.js non-blocking I/O despite being single-threaded."),
      Q("Node.js",2,"module.exports does?",["Imports packages","Exports code from module","Runs module","Deletes module"],1,"Other side of require()","module.exports defines what a module exposes to require() callers."),
      Q("Node.js",3,"True about Node.js?",["Multi-threaded","Blocking I/O","Single-threaded non-blocking I/O","Runs in browser"],2,"One thread, async I/O","Node.js is single-threaded but uses non-blocking I/O for efficiency."),
      Q("Node.js",3,"What is a stream?",["Real-time channel","Data read/written asynchronously","Type of variable","DB connection"],1,"Handle large data","Streams process data in chunks rather than loading everything into memory."),
      Q("Node.js",3,"'os' module provides?",["OS information","File operations","Network utilities","DB access"],0,"Operating System info","os module provides system info: cpus, freemem, hostname, platform, arch."),
      Q("Node.js",3,"Callback function?",["Calls itself","Passed as arg executed later","Built-in function","Sync function"],1,"Called back when done","A callback is passed as argument and called when async operation completes."),
      Q("Node.js",4,"process.nextTick vs setImmediate?",["Identical","nextTick before I/O setImmediate after","setImmediate before nextTick","Only setImmediate async"],1,"nextTick fires in current iteration","process.nextTick fires before any I/O in current iteration. setImmediate fires in next."),
      Q("Node.js",4,"cluster module does?",["Manages DBs","Creates child processes sharing ports","HTTP routing","File management"],1,"Multi-core usage","cluster creates worker processes sharing the same server port."),
      Q("Node.js",4,"File runs with 'node .'?",["app.js","server.js","index.js","main.js"],2,"Conventional entry point","'node .' looks at package.json 'main' field, defaults to index.js."),
      Q("Node.js",4,"Worker Threads?",["Sub-processes","True threads sharing memory for CPU tasks","HTTP workers","DB connections"],1,"CPU parallelism","Worker threads enable true parallel execution for CPU-intensive tasks."),
      Q("Node.js",5,"What is libuv?",["A logging library","C library providing event loop and async I/O","A package manager","An HTTP framework"],1,"C layer under Node","libuv handles Node's event loop, async I/O, timers, and threading."),
      Q("Node.js",5,"Back-pressure in streams?",["Compression","Writable can't keep up with readable","Memory overflow","Event loop block"],1,"Slow consumer fast producer","Back-pressure: writable stream can't keep up with readable. stream.pipe() handles it automatically."),
      Q("Node.js",2,"Initialize Node project?",["npm start","npm init","node init","npm create"],1,"Creates package.json","npm init creates a package.json file. npm init -y skips prompts."),
      Q("Node.js",1,"package.json purpose?",["DB credentials","Metadata and dependencies","Web server config","Env vars"],1,"The project manifest","package.json stores project name, version, scripts, and dependencies."),
      Q("Node.js",2,"Install package globally?",["npm install pkg","npm install -g pkg","npm global pkg","npm add -g pkg"],1,"-g flag","npm install -g installs globally, making CLI available system-wide."),
      Q("Node.js",3,"Method to end HTTP response?",["res.write()","res.send()","res.end()","res.respond()"],2,"Finishes response","res.end() signals all response data has been sent."),
      Q("Node.js",4,"Purpose of Buffer class?",["Cache HTTP responses","Handle binary data outside V8 heap","Buffer DB queries","Store env vars"],1,"Raw binary data","Buffer handles binary data like images, file contents, and network packets."),
      Q("Express.js",1,"Define a GET route?",["app.post()","app.get()","app.put()","app.route()"],1,"Named after HTTP method","app.get(path, handler) defines a GET handler."),
      Q("Express.js",1,"Middleware does?",["Renders HTML","Connects to DB","Processes requests between server and route","Creates routes"],2,"Runs in the middle","Middleware functions have access to req, res, and next."),
      Q("Express.js",2,"Parse JSON bodies?",["express.text()","express.urlencoded()","express.json()","express.body()"],2,"Matches data format","express.json() parses incoming JSON request bodies."),
      Q("Express.js",2,"URL parameter syntax?",["/:id with curly","/user/:id","[id]","<id>"],1,"Colon prefix","In Express, :paramName defines a URL parameter. Access via req.params."),
      Q("Express.js",2,"Request body is in?",["req.params","req.query","req.body","req.data"],2,"req.body = POST data","req.body contains request body data (POST/PUT)."),
      Q("Express.js",3,"app.use() does?",["Mounts middleware","Creates route","Starts server","Connects DB"],0,"Registers for all routes","app.use(path, middleware) registers middleware."),
      Q("Express.js",3,"Express Router?",["DB routing","Modular mini-app for routes","Style responses","Session manager"],1,"Splits routes into files","express.Router() creates a mini-app for organizing routes."),
      Q("Express.js",3,"'next' in middleware?",["Next loop iteration","Passes to next middleware","Ends response","Redirects"],1,"Without next chain stops","next() passes control to next middleware. next(err) skips to error handler."),
      Q("Express.js",3,"URL query params in?",["req.body","req.params","req.query","req.url"],2,"?key=value part","req.query contains key-value pairs from URL query string."),
      Q("Express.js",4,"What is CORS?",["Middleware type","Cross-Origin Resource Sharing","DB connector","Routing technique"],1,"Controls cross-origin","CORS restricts web pages from making requests to different domains."),
      Q("Express.js",4,"helmet does?",["Compresses responses","Adds security HTTP headers","Handles uploads","Manages sessions"],1,"Security headers","helmet sets HTTP headers to protect against XSS, clickjacking, MIME sniffing."),
      Q("Express.js",4,"JWT used for?",["DB queries","Auth and authorization","Static files","Template rendering"],1,"JSON Web Token","JWT is compact stateless authentication. Header.Payload.Signature format."),
      Q("Express.js",4,"Serve static files?",["express.static()","express.serve()","express.files()","express.public()"],0,"Serves from public folder","express.static(folder) serves static files from that directory."),
      Q("Express.js",5,"app.use() vs app.get()?",["No difference","app.use all methods partial paths app.get only GET exact","app.use faster","app.get handles all"],1,"app.use is flexible","app.use('/api') matches any method starting with /api. app.get only matches GET exactly."),
      Q("Express.js",5,"Rate limiting?",["Limiting file sizes","Restrict requests per IP per window","Limit middleware count","Throttle DB"],1,"Prevents abuse","Rate limiting restricts requests per IP per time window. Prevents brute force."),
      Q("Express.js",2,"Start on port 3000?",["app.run(3000)","app.start(3000)","app.listen(3000)","app.open(3000)"],2,"listen = start","app.listen(port, callback) binds and listens on the port."),
      Q("Express.js",1,"Status 404 means?",["Success","Unauthorized","Not Found","Server Error"],2,"Famous 404","404 Not Found means server cannot find the requested resource."),
      Q("Express.js",3,"Partially update resource?",["PUT","POST","PATCH","DELETE"],2,"PUT full replace PATCH partial","PATCH partially updates only specified fields. PUT replaces entire resource."),
      Q("Express.js",4,"res.status(201).json() means?",["201 error","Created response with JSON body","Create route","Parse request"],1,"201 = Created","201 Created is returned when a new resource is created. Usually for POST success."),
      Q("Express.js",5,"Error middleware signature?",["(req,res,next)","(err,req,res)","(err,req,res,next)","(err,next,res)"],2,"4 params err is first","Error middleware must have exactly 4 parameters. Express identifies it by 4-argument signature."),
      Q("Java",1,"Create object keyword?",["create","new","object","make"],1,"Before constructor","'new' allocates memory and calls constructor to initialize the object."),
      Q("Java",1,"Default int value?",["null","undefined","0","-1"],2,"Numeric defaults are zero","Instance variables: int=0, boolean=false, char='\\0'. Local variables have no default."),
      Q("Java",1,"JVM stands for?",["Java Virtual Machine","Java Variable Method","Java Verified Module","Java Value Manager"],0,"V = Virtual","JVM executes Java bytecode. Compile once, run anywhere on any JVM."),
      Q("Java",2,"Java entry point?",["start()","run()","init()","main()"],3,"Every program starts here","public static void main(String[] args) is the entry point."),
      Q("Java",2,"NOT a primitive type?",["int","boolean","String","char"],2,"Uppercase = class","Java primitives: byte,short,int,long,float,double,char,boolean. String is a class, not primitive."),
      Q("Java",2,"Prevent subclassing?",["static","final","private","abstract"],1,"final = no extension","final class cannot be subclassed. final method cannot be overridden."),
      Q("Java",2,"Implements interface keyword?",["extends","implements","inherits","uses"],1,"implements for interfaces","'implements' for interfaces, 'extends' for classes. A class can implement multiple interfaces."),
      Q("Java",3,"Method overloading?",["Redefine parent method","Same name different params","Hide method","Recursive call"],1,"Same name different signatures","Overloading: same method name, different parameter types/count. Compile-time polymorphism."),
      Q("Java",3,"Exception on divide by zero?",["NullPointerException","ArithmeticException","ArrayIndexOutOfBounds","NumberFormatException"],1,"Division is arithmetic","ArithmeticException is thrown for integer division by zero. Float division returns Infinity."),
      Q("Java",3,"'static' means?",["Changes at runtime","Belongs to class not instance","Private method","No inheritance"],1,"Shared across instances","Static members belong to the class, not any instance. All objects share one static variable."),
      Q("Java",3,"Autoboxing?",["Auto memory","Auto primitive to wrapper","Auto GC","Auto cast"],1,"int → Integer auto","Autoboxing converts primitives to wrappers (int→Integer) automatically."),
      Q("Java",3,"Parent constructor call?",["this()","parent()","super()","base()"],2,"super = parent","super() calls parent constructor. Must be first statement."),
      Q("Java",4,"Collection maintaining insertion order?",["HashSet","TreeSet","LinkedList","HashMap"],2,"Linked = ordered","LinkedList maintains insertion order. HashSet has no order. TreeSet sorts."),
      Q("Java",4,"'finally' block?",["On exception only","No exception only","Always runs","Skips on error"],2,"ALWAYS executes","finally always runs regardless of exception. Use for cleanup code."),
      Q("Java",4,"Java package?",["Compressed archive","Namespace to organize classes","Variable type","Build tool"],1,"Groups related classes","Packages namespace related classes. Prevent naming conflicts."),
      Q("Java",4,"Most restrictive modifier?",["public","protected","default","private"],3,"private = class only","private: class only. protected: package+subclasses. public: everywhere."),
      Q("Java",5,"Diamond problem?",["Memory issue","Ambiguity in multiple interface inheritance","JVM error","Concurrency bug"],1,"Solved via default methods","When a class implements two interfaces with same default method, class must override to resolve."),
      Q("Java",5,"FunctionalInterface?",["Class with one method","Interface with exactly one abstract method","Lambda expression","Generic interface"],1,"Used with lambdas","FunctionalInterface has exactly one abstract method. Used with lambda expressions."),
      Q("Java",5,"volatile keyword?",["Makes constant","Variable read from main memory in multithreading","Speeds access","Prevents GC"],1,"Visibility across threads","volatile ensures reads/writes go to main memory. Guarantees visibility but not atomicity."),
      Q("Java",2,"What is an interface?",["Only static methods","Blueprint with abstract methods and constants","Concrete class","Enum type"],1,"A contract","Interface defines what a class must do. A class 'implements' it."),
      Q("Python",1,"Comment symbol?",["//","/*","#","--"],2,"The hashtag","# starts a single-line comment in Python."),
      Q("Python",1,"Get list length?",["size()","count()","len()","length()"],2,"Short for length","len() returns the number of items in any sequence."),
      Q("Python",1,"Define function keyword?",["function","def","func","define"],1,"Short for define","def keyword defines a function. Uses indentation not braces."),
      Q("Python",2,"Create a dictionary?",["[]","()","{}","<>"],2,"Same as JSON","{}  creates a dict literal: {'key': value}. [] is a list. () is a tuple."),
      Q("Python",2,"Immutable data structure?",["List","Dictionary","Set","Tuple"],3,"Cannot be changed","Tuples are immutable — cannot be modified after creation."),
      Q("Python",2,"range(5) generates?",["[1,2,3,4,5]","[0,1,2,3,4]","[0,1,2,3,4,5]","[1,2,3,4]"],1,"Starts at 0","range(n) generates 0 to n-1."),
      Q("Python",2,"Lambda function?",["Recursive function","Anonymous single-expression function","Class method","Imported function"],1,"One-liner anonymous","lambda args: expression creates an anonymous function."),
      Q("Python",3,"Inheritance declaration?",["extends","inherits","class Child(Parent):","implements"],2,"Parent in parentheses","class Child(Parent): Multiple inheritance: class C(A, B)."),
      Q("Python",3,"'self' refers to?",["The class","Current instance","Parent class","Global var"],1,"Like 'this' in Java","self is the first parameter of instance methods, referring to the calling object."),
      Q("Python",3,"List comprehension?",["Sort lists","Compact list creation with for loop","Copy lists","Recursive list"],1,"[x for x in iterable]","[expression for item in iterable if condition]. Compact list creation."),
      Q("Python",3,"pip stands for?",["Python Import Package","Pip Installs Packages","Python Integrated Platform","Package Index Pip"],1,"Recursive acronym","pip = Pip Installs Packages. Package installer for Python."),
      Q("Python",3,"'Hello'[::-1] result?",["Hello","olleH","H","Error"],1,"Negative step reverses","[::-1] starts from end, goes backwards. 'Hello'[::-1] = 'olleH'."),
      Q("Python",4,"*args does?",["Multiplies args","Variable positional args","Unpacks list","Defines keyword args"],1,"Collects positional args","*args collects extra positional arguments into a tuple."),
      Q("Python",4,"What is a decorator?",["CSS class","Function wrapping another function","Comment syntax","A module"],1,"@syntax","Decorators wrap a function to extend its behavior without modifying it."),
      Q("Python",4,"What is a generator?",["Random number function","Function using yield returning iterator","List creator","Class factory"],1,"Uses yield","Generators produce values lazily using yield. Memory-efficient for large sequences."),
      Q("Python",5,"GIL?",["Garbage collector","Global Interpreter Lock preventing thread parallelism","A library","Linting tool"],1,"CPython limitation","GIL prevents multiple threads executing Python bytecode simultaneously. Workaround: multiprocessing."),
      Q("Python",5,"Metaclass?",["Parent class","Class of a class controlling class creation","Abstract class","A mixin"],1,"type is default metaclass","Metaclass controls how classes are created. type is the default metaclass."),
      Q("Python",2,"Handle exceptions?",["catch","error","except","handle"],2,"try: ... except:","Python uses try/except/else/finally. Unlike Java/JS which use try/catch."),
      Q("Python",1,"bool(0) is?",["True","False","0","None"],1,"0 is falsy","Falsy values: 0, '', [], {}, None, False. Everything else is truthy."),
      Q("Python",4,"__init__ is?",["Import statement","Class constructor on object creation","Global variable","Module initializer"],1,"Python constructor","__init__ is called automatically when creating an instance."),
      Q("C",1,"Header for printf()?",["<stdlib.h>","<string.h>","<stdio.h>","<math.h>"],2,"stdio = standard I/O","<stdio.h> provides printf, scanf, fprintf, fgets, puts."),
      Q("C",1,"Pointer syntax?",["int &p","int *p","pointer int p","int ptr p"],1,"Asterisk = pointer","int *p declares a pointer to int. *p dereferences. &variable gives address."),
      Q("C",2,"sizeof() returns?",["Value","Address","Size in bytes","Element count"],2,"How many bytes?","sizeof() returns size in bytes at compile time."),
      Q("C",2,"Loop runs at least once?",["for","while","do-while","foreach"],2,"Condition after body","do { body } while(condition) — body executes first, then condition checked."),
      Q("C",2,"Return type of main()?",["void","int","char","float"],1,"Returns exit code","main() returns int: 0 for success, non-zero for failure."),
      Q("C",2,"Dynamic memory allocation?",["new()","alloc()","malloc()","create()"],2,"Memory ALLOCation","malloc(size) allocates bytes and returns void*. Pair with free()."),
      Q("C",2,"'\\n' represents?",["Null char","New line","Tab","Backslash"],1,"n = newline","Escape sequences: \\n=newline, \\t=tab, \\0=null, \\\\=backslash."),
      Q("C",3,"Access struct via pointer?",[".",  "->","::","*"],1,"Arrow operator","ptr->member is shorthand for (*ptr).member."),
      Q("C",3,"Structure in C?",["Collection of functions","User-defined type grouping variables","A loop type","Memory technique"],1,"Groups related data","struct groups variables of different types."),
      Q("C",3,"Free memory?",["delete()","free()","release()","dealloc()"],1,"Pair with malloc","free(ptr) releases malloc'd memory. Not calling free causes leaks."),
      Q("C",3,"Address-of & does?",["Dereferences pointer","Returns address of variable","Bitwise AND","Declares reference"],1,"&x gives address","& returns memory address. Used to get pointers: int *p = &x."),
      Q("C",3,"String copy?",["strdup()","strcpy()","strcat()","strlen()"],1,"String COPY","strcpy(dest,src) copies src to dest including null terminator."),
      Q("C",4,"NULL pointer?",["Pointer to address 0","Uninitialised pointer","String pointer","Function pointer"],0,"Points to nothing","NULL pointer has value 0 and doesn't point to valid memory."),
      Q("C",4,"#define does?",["Declares variable","Creates macro/constant","Defines function","Includes header"],1,"Preprocessor directive","#define NAME value creates a macro. Preprocessor replaces all occurrences before compilation."),
      Q("C",4,"Storage class visible only in function?",["extern","static","register","auto"],3,"Default local","auto is the default storage class for local variables."),
      Q("C",4,"Recursive function?",["Called by another","Calls itself","No return value","Library function"],1,"Calls itself","Recursive function calls itself with a base case to stop."),
      Q("C",5,"Dangling pointer?",["Null pointer","Pointer to freed/out-of-scope memory","Void pointer","Double pointer"],1,"Points to released memory","Dangling pointer points to freed memory. Dereferencing causes undefined behavior."),
      Q("C",5,"Memory leak?",["Stack overflow","Allocated memory never freed","Null dereference","Buffer overrun"],1,"malloc without free","Memory leak: dynamically allocated memory never freed. Accumulates over time."),
      Q("C",2,"'break' in loop?",["Pauses execution","Exits current loop/switch","Skips iteration","Terminates program"],1,"Breaks out immediately","break exits the nearest enclosing loop or switch immediately."),
      Q("C",5,"Pointer arithmetic?",["Math with addresses","Operations on pointers to traverse arrays","Multiplying pointers","Converting types"],1,"p++ moves to next element","p++ on pointer moves forward by sizeof(*p) bytes — to next element."),
      Q("C++",1,"Same name different params?",["Inheritance","Encapsulation","Polymorphism","Function Overloading"],3,"Overloading = multiple versions","Function overloading: same name, different parameter types/count. Compile-time polymorphism."),
      Q("C++",1,"Correct class declaration?",["class MyClass {}","Class MyClass {}","object MyClass {}","struct MyClass {}"],0,"Lowercase class keyword","class keyword (lowercase). Default access is private."),
      Q("C++",2,"Header for cout/cin?",["<stdio.h>","<conio.h>","<iostream>","<stream.h>"],2,"iostream = i/o stream","<iostream> provides cin and cout."),
      Q("C++",2,"Scope resolution operator?",[".",  "->","::","#"],2,"Double colon",":: for namespace and class member access."),
      Q("C++",2,"Constructor?",["Destroys objects","Called on object creation","Static method","Virtual function"],1,"Constructs = creates","Constructor: same name as class, no return type. Called on object creation."),
      Q("C++",2,"STL stands for?",["Standard Type Library","Standard Template Library","System Template Library","Static Type List"],1,"T = Template","STL provides containers, algorithms, iterators, and functors."),
      Q("C++",3,"Destructor?",["Creates objects","Called when object destroyed","Virtual constructor","Copy function"],1,"~ClassName() tears down","Destructor called when object goes out of scope or delete is called."),
      Q("C++",3,"Operator overloading?",["Redefine built-in operators","Call many times","Type of inheritance","Create new operators"],0,"+ for your class","Operator overloading lets you define how operators work for user-defined types."),
      Q("C++",3,"Dynamic memory?",["malloc()","alloc()","new","create"],2,"new in C++","new allocates and calls constructor. delete frees and calls destructor."),
      Q("C++",3,"Virtual function?",["Declared not defined","Overridden in derived via runtime polymorphism","Static member","Template function"],1,"Runtime polymorphism","Virtual functions enable runtime polymorphism via vtable lookup."),
      Q("C++",3,"STL FIFO container?",["stack","queue","vector","map"],1,"First In First Out","queue<T> is FIFO: push() back, pop() front."),
      Q("C++",4,"Multiple inheritance?",["Inherit from 2+ base classes","Inherit multiple times","Override multiple","Multiple constructors"],0,"C++ allows it","Multiple inheritance: class C : public A, public B. Can cause diamond problem."),
      Q("C++",4,"delete does?",["Remove class","Deallocate new memory","Destroy file","Remove method"],1,"Pair with new","delete frees heap memory and calls destructor. Set pointer to nullptr after."),
      Q("C++",4,"Copy constructor?",["Default constructor","Parameterised constructor","Copies another object","Move constructor"],2,"Called on copy-init","Copy constructor: ClassName(const ClassName& other). Default does shallow copy."),
      Q("C++",4,"Abstract class?",["No methods","Has at least one pure virtual function","Final class","No objects"],1,"Pure virtual = 0 syntax","Class with pure virtual function (virtual void f() = 0) is abstract. Cannot be instantiated."),
      Q("C++",5,"RAII?",["A design pattern","Resource Acquisition Is Initialisation tie resource to object lifetime","Template technique","Memory allocator"],1,"Smart pointers use RAII","RAII: acquire in constructors, release in destructors. Object lifetime manages resource lifetime."),
      Q("C++",5,"Move constructor?",["Copies an object","Transfers ownership without copying","Creates a new object","Destroys an object"],1,"C++11 avoids deep copies","Move constructor transfers resources from temporary objects instead of copying."),
      Q("C++",5,"Template specialisation?",["Creating generic template","Specific implementation for particular type","Inheriting from template","Overloading template"],1,"Specific type behavior","Template specialisation provides custom implementation for a specific type."),
      Q("C++",2,"Prevent overriding?",["static","const","final","override"],2,"final keyword","'final' on virtual function prevents further overriding."),
      Q("C++",3,"Access in derived not outside?",["public","private","protected","internal"],2,"Between public and private","protected: class + derived classes. private: class only. public: everywhere."),
    ];

    const questions = await Question.insertMany(questionData);
    const bySubject = {};
    questions.forEach(q => { if (!bySubject[q.subject]) bySubject[q.subject]=[]; bySubject[q.subject].push(q._id); });

    const now = new Date().getHours();
    await Exam.insertMany([
      { title:"JavaScript Mastery",    duration:25, timePerQuestion:30, adaptive:false, shuffleQuestions:true, shuffleOptions:true, questionIds:bySubject["JavaScript"],  createdAt:"2025-01-10" },
      { title:"React Deep Dive",       duration:25, timePerQuestion:30, adaptive:false, shuffleQuestions:true, shuffleOptions:true, questionIds:bySubject["React"],       createdAt:"2025-01-11" },
      { title:"MongoDB Complete",      duration:25, timePerQuestion:30, adaptive:false, shuffleQuestions:true, shuffleOptions:true, questionIds:bySubject["MongoDB"],     createdAt:"2025-01-12" },
      { title:"Node.js Fundamentals",  duration:25, timePerQuestion:30, adaptive:false, shuffleQuestions:true, shuffleOptions:true, questionIds:bySubject["Node.js"],     createdAt:"2025-01-13" },
      { title:"Express.js Essentials", duration:25, timePerQuestion:30, adaptive:false, shuffleQuestions:true, shuffleOptions:true, questionIds:bySubject["Express.js"],  createdAt:"2025-01-14" },
      { title:"Java Programming",      duration:25, timePerQuestion:30, adaptive:false, shuffleQuestions:true, shuffleOptions:true, questionIds:bySubject["Java"],        createdAt:"2025-01-15" },
      { title:"Python Essentials",     duration:25, timePerQuestion:30, adaptive:false, shuffleQuestions:true, shuffleOptions:true, questionIds:bySubject["Python"],      createdAt:"2025-01-16" },
      { title:"C Programming",         duration:25, timePerQuestion:30, adaptive:false, shuffleQuestions:true, shuffleOptions:true, questionIds:bySubject["C"],           createdAt:"2025-01-17" },
      { title:"C++ OOP",               duration:25, timePerQuestion:30, adaptive:false, shuffleQuestions:true, shuffleOptions:true, questionIds:bySubject["C++"],         createdAt:"2025-01-18" },
      { title:"MERN Stack Full",       duration:20, timePerQuestion:30, adaptive:false, shuffleQuestions:true, shuffleOptions:true,
        questionIds:[...bySubject["JavaScript"].slice(0,4),...bySubject["React"].slice(0,4),...bySubject["MongoDB"].slice(0,4),...bySubject["Node.js"].slice(0,4),...bySubject["Express.js"].slice(0,4)],
        createdAt:"2025-01-19" },
      { title:"🔒 Timed: JavaScript (9AM–6PM)", duration:20, timePerQuestion:30, adaptive:false, shuffleQuestions:true, shuffleOptions:true, availableFrom:"09:00", availableTo:"18:00", questionIds:bySubject["JavaScript"], createdAt:"2025-01-20" },
      { title:"⚡ Adaptive: JavaScript", duration:15, timePerQuestion:45, adaptive:true, adaptiveCount:10, questionIds:bySubject["JavaScript"], createdAt:"2025-01-21" },
      { title:"⚡ Adaptive: Java",       duration:15, timePerQuestion:45, adaptive:true, adaptiveCount:10, questionIds:bySubject["Java"],       createdAt:"2025-01-22" },
      { title:"⚡ Adaptive: Python",     duration:15, timePerQuestion:45, adaptive:true, adaptiveCount:10, questionIds:bySubject["Python"],     createdAt:"2025-01-23" },
      { title:"⚡ Adaptive: C++",        duration:15, timePerQuestion:45, adaptive:true, adaptiveCount:10, questionIds:bySubject["C++"],        createdAt:"2025-01-24" },
      { title:"⚡ Adaptive: Full Stack", duration:20, timePerQuestion:45, adaptive:true, adaptiveCount:15,
        questionIds:[...bySubject["JavaScript"],...bySubject["React"],...bySubject["Node.js"],...bySubject["Express.js"],...bySubject["MongoDB"]],
        createdAt:"2025-01-25" },
    ]);

    res.json({ message:"✅ Seeded!", counts:{ users:3, questions:questions.length, exams:16 } });
  } catch(err){ console.error(err); res.status(500).json({error:err.message}); }
});

app.listen(PORT, () => {
  console.log(`\n🚀  ExamPortal → http://localhost:${PORT}`);
  console.log(`🎮  Gamification + Streak Multiplier: /api/profile | /api/leaderboard`);
  console.log(`🔒  Time Lock: GET /api/exams/:id/access-check`);
  console.log(`🕵️   Cheat Log: POST /api/cheat-log | GET /api/admin/cheat-reports\n`);
});
